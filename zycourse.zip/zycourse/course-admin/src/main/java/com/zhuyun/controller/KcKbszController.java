package com.zhuyun.controller;

import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhuyun.entity.KcKbszEntity;
import com.zhuyun.service.KcKbszService;
import com.zhuyun.utils.PageUtils;
import com.zhuyun.utils.Query;
import com.zhuyun.utils.R;

/**
 * 课表设置Controller
 *
 * @author ZHUYUN
 * @email zhuyun@163.com
 * @date 2018-07-11 17:22:00
 */
@Controller
@RequestMapping("kckbsz")
public class KcKbszController {
    @Autowired
    private KcKbszService kcKbszService;

    /**
     * 查看列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("kckbsz:list")
    @ResponseBody
    public R list(@RequestParam Map<String, Object> params) {
        //查询列表数据
        Query query = new Query(params);

        List<KcKbszEntity> kcKbszList = kcKbszService.queryList(query);
        int total = kcKbszService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(kcKbszList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    /**
     * 查看信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("kckbsz:info")
    @ResponseBody
    public R info(@PathVariable("id") Integer id) {
        KcKbszEntity kcKbsz = kcKbszService.queryObject(id);

        return R.ok().put("kcKbsz", kcKbsz);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("kckbsz:save")
    @ResponseBody
    public R save(@RequestBody KcKbszEntity kcKbsz) {
        kcKbszService.save(kcKbsz);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("kckbsz:update")
    @ResponseBody
    public R update(@RequestBody KcKbszEntity kcKbsz) {
        kcKbszService.update(kcKbsz);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("kckbsz:delete")
    @ResponseBody
    public R delete(@RequestBody Integer[]ids) {
        kcKbszService.deleteBatch(ids);

        return R.ok();
    }

    /**
     * 查看所有列表
     */
    @RequestMapping("/queryAll")
    @ResponseBody
    public R queryAll(@RequestParam Map<String, Object> params) {

        List<KcKbszEntity> list = kcKbszService.queryList(params);

        return R.ok().put("list", list);
    }
}
