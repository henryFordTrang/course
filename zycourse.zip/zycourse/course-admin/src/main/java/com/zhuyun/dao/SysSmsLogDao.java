package com.zhuyun.dao;

import com.zhuyun.dao.BaseDao;
import com.zhuyun.entity.SysSmsLogEntity;

/**
 * Dao
 *
 * @author ZhuYun
 * @date 2017-12-16 23:38:05
 */
public interface SysSmsLogDao extends BaseDao<SysSmsLogEntity> {

}
