package com.zhuyun.controller;

import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhuyun.entity.KcXnxqEntity;
import com.zhuyun.service.KcXnxqService;
import com.zhuyun.utils.PageUtils;
import com.zhuyun.utils.Query;
import com.zhuyun.utils.R;

/**
 * 学年学期表Controller
 *
 * @author ZHUYUN
 * @email zhuyun@163.com
 * @date 2018-07-11 17:22:00
 */
@Controller
@RequestMapping("kcxnxq")
public class KcXnxqController {
    @Autowired
    private KcXnxqService kcXnxqService;

    /**
     * 查看列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("kcxnxq:list")
    @ResponseBody
    public R list(@RequestParam Map<String, Object> params) {
        //查询列表数据
        Query query = new Query(params);

        List<KcXnxqEntity> kcXnxqList = kcXnxqService.queryList(query);
        int total = kcXnxqService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(kcXnxqList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    /**
     * 查看信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("kcxnxq:info")
    @ResponseBody
    public R info(@PathVariable("id") Integer id) {
        KcXnxqEntity kcXnxq = kcXnxqService.queryObject(id);

        return R.ok().put("kcXnxq", kcXnxq);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("kcxnxq:save")
    @ResponseBody
    public R save(@RequestBody KcXnxqEntity kcXnxq) {
        kcXnxqService.save(kcXnxq);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("kcxnxq:update")
    @ResponseBody
    public R update(@RequestBody KcXnxqEntity kcXnxq) {
        kcXnxqService.update(kcXnxq);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("kcxnxq:delete")
    @ResponseBody
    public R delete(@RequestBody Integer[]ids) {
        kcXnxqService.deleteBatch(ids);

        return R.ok();
    }

    /**
     * 查看所有列表
     */
    @RequestMapping("/queryAll")
    @ResponseBody
    public R queryAll(@RequestParam Map<String, Object> params) {

        List<KcXnxqEntity> list = kcXnxqService.queryList(params);

        return R.ok().put("list", list);
    }
}
