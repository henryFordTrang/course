package com.zhuyun.controller;

import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhuyun.entity.SchoolInfoEntity;
import com.zhuyun.service.SchoolInfoService;
import com.zhuyun.utils.PageUtils;
import com.zhuyun.utils.Query;
import com.zhuyun.utils.R;

/**
 * 学校信息Controller
 *
 * @author ZHUYUN
 * @email zhuyun@163.com
 * @date 2018-07-11 17:21:59
 */
@Controller
@RequestMapping("schoolinfo")
public class SchoolInfoController {
    @Autowired
    private SchoolInfoService schoolInfoService;

    /**
     * 查看列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("schoolinfo:list")
    @ResponseBody
    public R list(@RequestParam Map<String, Object> params) {
        //查询列表数据
        Query query = new Query(params);

        List<SchoolInfoEntity> schoolInfoList = schoolInfoService.queryList(query);
        int total = schoolInfoService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(schoolInfoList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    /**
     * 查看信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("schoolinfo:info")
    @ResponseBody
    public R info(@PathVariable("id") Integer id) {
        SchoolInfoEntity schoolInfo = schoolInfoService.queryObject(id);

        return R.ok().put("schoolInfo", schoolInfo);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("schoolinfo:save")
    @ResponseBody
    public R save(@RequestBody SchoolInfoEntity schoolInfo) {
        schoolInfoService.save(schoolInfo);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("schoolinfo:update")
    @ResponseBody
    public R update(@RequestBody SchoolInfoEntity schoolInfo) {
        schoolInfoService.update(schoolInfo);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("schoolinfo:delete")
    @ResponseBody
    public R delete(@RequestBody Integer[]ids) {
        schoolInfoService.deleteBatch(ids);

        return R.ok();
    }

    /**
     * 查看所有列表
     */
    @RequestMapping("/queryAll")
    @ResponseBody
    public R queryAll(@RequestParam Map<String, Object> params) {

        List<SchoolInfoEntity> list = schoolInfoService.queryList(params);

        return R.ok().put("list", list);
    }
}
