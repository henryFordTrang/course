package com.zhuyun.controller;

import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhuyun.entity.KcJcsjEntity;
import com.zhuyun.service.KcJcsjService;
import com.zhuyun.utils.PageUtils;
import com.zhuyun.utils.Query;
import com.zhuyun.utils.R;

/**
 * 节次时间Controller
 *
 * @author ZHUYUN
 * @email zhuyun@163.com
 * @date 2018-07-11 17:21:59
 */
@Controller
@RequestMapping("kcjcsj")
public class KcJcsjController {
    @Autowired
    private KcJcsjService kcJcsjService;

    /**
     * 查看列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("kcjcsj:list")
    @ResponseBody
    public R list(@RequestParam Map<String, Object> params) {
        //查询列表数据
        Query query = new Query(params);

        List<KcJcsjEntity> kcJcsjList = kcJcsjService.queryList(query);
        int total = kcJcsjService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(kcJcsjList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    /**
     * 查看信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("kcjcsj:info")
    @ResponseBody
    public R info(@PathVariable("id") Integer id) {
        KcJcsjEntity kcJcsj = kcJcsjService.queryObject(id);

        return R.ok().put("kcJcsj", kcJcsj);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("kcjcsj:save")
    @ResponseBody
    public R save(@RequestBody KcJcsjEntity kcJcsj) {
        kcJcsjService.save(kcJcsj);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("kcjcsj:update")
    @ResponseBody
    public R update(@RequestBody KcJcsjEntity kcJcsj) {
        kcJcsjService.update(kcJcsj);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("kcjcsj:delete")
    @ResponseBody
    public R delete(@RequestBody Integer[]ids) {
        kcJcsjService.deleteBatch(ids);

        return R.ok();
    }

    /**
     * 查看所有列表
     */
    @RequestMapping("/queryAll")
    @ResponseBody
    public R queryAll(@RequestParam Map<String, Object> params) {

        List<KcJcsjEntity> list = kcJcsjService.queryList(params);

        return R.ok().put("list", list);
    }
}
