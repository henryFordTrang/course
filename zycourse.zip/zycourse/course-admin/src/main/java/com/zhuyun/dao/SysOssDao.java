package com.zhuyun.dao;

import com.zhuyun.dao.BaseDao;
import com.zhuyun.entity.SysOssEntity;

/**
 * 文件上传
 *
 * @author ZhuYun
 * @email ZhuYun@163.com
 * @date 2017-03-25 12:13:26
 */
public interface SysOssDao extends BaseDao<SysOssEntity> {

}
