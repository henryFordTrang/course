package com.zhuyun.controller;

import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhuyun.entity.CourseInfoEntity;
import com.zhuyun.service.CourseInfoService;
import com.zhuyun.utils.PageUtils;
import com.zhuyun.utils.Query;
import com.zhuyun.utils.R;

/**
 * 课程Controller
 *
 * @author ZHUYUN
 * @email zhuyun@163.com
 * @date 2018-07-11 17:21:59
 */
@Controller
@RequestMapping("courseinfo")
public class CourseInfoController {
    @Autowired
    private CourseInfoService courseInfoService;

    /**
     * 查看列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("courseinfo:list")
    @ResponseBody
    public R list(@RequestParam Map<String, Object> params) {
        //查询列表数据
        Query query = new Query(params);

        List<CourseInfoEntity> courseInfoList = courseInfoService.queryList(query);
        int total = courseInfoService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(courseInfoList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    /**
     * 查看信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("courseinfo:info")
    @ResponseBody
    public R info(@PathVariable("id") Integer id) {
        CourseInfoEntity courseInfo = courseInfoService.queryObject(id);

        return R.ok().put("courseInfo", courseInfo);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("courseinfo:save")
    @ResponseBody
    public R save(@RequestBody CourseInfoEntity courseInfo) {
        courseInfoService.save(courseInfo);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("courseinfo:update")
    @ResponseBody
    public R update(@RequestBody CourseInfoEntity courseInfo) {
        courseInfoService.update(courseInfo);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("courseinfo:delete")
    @ResponseBody
    public R delete(@RequestBody Integer[]ids) {
        courseInfoService.deleteBatch(ids);

        return R.ok();
    }

    /**
     * 查看所有列表
     */
    @RequestMapping("/queryAll")
    @ResponseBody
    public R queryAll(@RequestParam Map<String, Object> params) {

        List<CourseInfoEntity> list = courseInfoService.queryList(params);

        return R.ok().put("list", list);
    }
}
