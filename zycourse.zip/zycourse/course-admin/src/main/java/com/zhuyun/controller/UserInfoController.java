package com.zhuyun.controller;

import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhuyun.entity.UserInfoEntity;
import com.zhuyun.service.UserInfoService;
import com.zhuyun.utils.PageUtils;
import com.zhuyun.utils.Query;
import com.zhuyun.utils.R;

/**
 * 用户表Controller
 *
 * @author ZHUYUN
 * @email zhuyun@163.com
 * @date 2018-07-11 17:22:00
 */
@Controller
@RequestMapping("userinfo")
public class UserInfoController {
    @Autowired
    private UserInfoService userInfoService;

    /**
     * 查看列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("userinfo:list")
    @ResponseBody
    public R list(@RequestParam Map<String, Object> params) {
        //查询列表数据
        Query query = new Query(params);

        List<UserInfoEntity> userInfoList = userInfoService.queryList(query);
        int total = userInfoService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(userInfoList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    /**
     * 查看信息
     */
    @RequestMapping("/info/{id}")
    @RequiresPermissions("userinfo:info")
    @ResponseBody
    public R info(@PathVariable("id") Integer id) {
        UserInfoEntity userInfo = userInfoService.queryObject(id);

        return R.ok().put("userInfo", userInfo);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("userinfo:save")
    @ResponseBody
    public R save(@RequestBody UserInfoEntity userInfo) {
        userInfoService.save(userInfo);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("userinfo:update")
    @ResponseBody
    public R update(@RequestBody UserInfoEntity userInfo) {
        userInfoService.update(userInfo);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("userinfo:delete")
    @ResponseBody
    public R delete(@RequestBody Integer[]ids) {
        userInfoService.deleteBatch(ids);

        return R.ok();
    }

    /**
     * 查看所有列表
     */
    @RequestMapping("/queryAll")
    @ResponseBody
    public R queryAll(@RequestParam Map<String, Object> params) {

        List<UserInfoEntity> list = userInfoService.queryList(params);

        return R.ok().put("list", list);
    }
}
