var series=null;

//设置日期格式
Date.prototype.Format = function (fmt) { 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}


 $(function(){
	 var userId=localStorage.userId;
	 series=0;
	 var bgettime=true;
	 
	 
	 var revealchooser=function(courseFigureArr,entering){
		 
	 	  var courseArr=['','','','',''];
	 	  var spaceArr=[' ',' ',' ',' ',' ',' ',' '];	  
	 	  var hourFigureArr=['第一学期','第二学期']; 	  
	 	  var mobileSelect3 = new MobileSelect({
	 				
	 			    trigger: '#addTime',
	 			    type:'newterm',
	 			    org:'yes',
	 			    title: entering,
	 			    wheels: [
	 			              
	 			                {data: courseFigureArr},
	 			                {data: courseArr},
	 			                {data: spaceArr},
	 			                {data: hourFigureArr}
	 			               
	 			              
	 			            ],
	 			    position:[5, 4, 2, 0, 2], 
	 			    transitionEnd:function(indexArr, data){
	 			        console.log(data);
	 			    },
	 			    callback:function(indexArr, data){

	 			    	var reg =/[\u4e00-\u9fa5]/g;
	 			    	var year=data[0].replace(reg,"");
	 			    	year=year.replace(/(^\s*)|(\s*$)/g, "");
	 			    	var yt=data[1]+' '+year;			    
	 			        console.log(data);
	 			        var sbterm='';
	 			       var starttime='';
	 			        if(data[3]=='第一学期'){
	 			        	sbterm=1;
	 			        	starttime=year.substring(0,4);
	 			        	starttime=starttime+'-09-01';
	 			        }else if(data[3]=='第二学期'){
	 			        	sbterm=2;
	 			        	starttime=year.substring(5,9);
	 			        	starttime=starttime+'-03-01';
	 			        }
	 			       var userId=localStorage.userId;			       
	 			       var mes='{"userId":"'+userId+'","xn":"'+year+'","xq":"'+sbterm+'","kxsj":"'+starttime+'"}';
	 			       
	 			       firsttime=commiting(mes,data[0],data[3]);
	 			       
	 			       //createterm(data[0],data[3]);
	 			        
	 			    }
	 			});
	 }

	 $.ajax({
  		"dataType": 'json',
  		"type": "GET",
  		"async":false,
 		"url": cutUrl()+"/api/course/getUserCourseInfo",
  		"data": {"userId":userId},
  		"contentType":"application/json;charset=utf-8",
  		"success": function (data, textStatus, jqXHR){
  			var raw=JSON.stringify(data);
  			console.log(raw);
  			raw=$.parseJSON(raw);
  			if(raw.error.id=='0000'&&raw.rxny!=null){
  					$('#termSt').children('em').text='';
  					var forshow=raw.rxny;
  					forshow=forshow.split('-');
  					var yearshow=forshow[0]+'年-'+forshow[1]+'月';
  					
  					$('#termSt1').children('em').text(yearshow);
  					$('#termSt').val(raw.rxny);
  	  				//...
  	  				
  	  				$('.mobileSelect').remove();
  	  		        var theSelectData=raw.rxny;
  	  		        var entering='入学时间'+theSelectData;
  	  		        starttime=raw.rxny;
  	  		        starttime=starttime.substring(0,4);        
  	  		        starttime=parseInt(starttime)-6;
  	  		        numArr=[];
  	  		        courseFigureArr=[];
  	  		        for(var i=0;i<15;i++){
  	  		        	if(i>=5&&i<10){
  	  		        		starttime++;
  	  		        		var grading=i-4;
  	  		        		var grade='';
  	  		        		if(grading==1){
  	  		        			grade='一';
  	  		        		}
  	  		        		if(grading==2){
  	  		        			grade='二';
  	  		        		}
  	  		        		if(grading==3){
  	  		        			grade='三';
  	  		        		}
  	  		        		if(grading==4){
  	  		        			grade='四';
  	  		        		}
  	  		        		if(grading==5){
  	  		        			grade='五';
  	  		        		}
  	  		            	var st=starttime+1;        	
  	  		            	var starttimeplus=starttime+'年-'+st+'年'+'       大'+grade;
  	  		            	courseFigureArr.push(starttimeplus);
  	  		        	}else{
  	  		        		starttime++;
  	  		            	var st=starttime+1;        	
  	  		            	var starttimeplus=starttime+'年-'+st+'年';
  	  		            	courseFigureArr.push(starttimeplus);
  	  		        	}
  	  		        	
  	  		        	
  	  		        }
  	  		        bgettime=false;
  	  		      //  console.log(courseFigureArr+' '+entering)
  	  		        revealchooser(courseFigureArr,entering);  
  	  				
  	  				//....
  				
  				
  			}else{
  				bgettime=true;
  				
  			}
  		}
	 })
	 
	 
	 
	
    $(".nowTermA").click(function(){
       $('.setTerm').removeClass("nowTerm");
       $('.termEm').removeClass("nowEm");
       $('.termEm').text("设为当前");
       $(this).children(".setTerm").addClass("nowTerm");
       $(this).children().children(".termEm").addClass("nowEm");
       $(this).children().children(".termEm").text("当前学期");
 
    })  
    
    var clickCtrl=false;
    $('.menu_l').click(function(){ 
    	if(clickCtrl){
    		return;
    	}
    	clickCtrl=true;
    	
    	 var reg =/[\u4e00-\u9fa5]/g;
    	 //var rxny=$('#termSt').children('em').text();
    	 var rxny=$('#termSt').val();
    	 
    	 if(rxny.replace(reg,'')==''){
    		 window.location='term.html';
    		 return;
    	 }
    	
    	var url=cutUrl()+"/api/course/insertFirstTimeOfSchool";
 		var mes='{"userId":"'+userId+'","rxny":"'+rxny+'"}';
 		
 			 $.ajax({
 		         "dataType": 'json',
 		         "type": "POST",
 		         "url": url,
 		         "data": mes,
 		         "contentType":"application/json;charset=utf-8",
 		         "success": function (data, textStatus, jqXHR){
 		        	clickCtrl=false;
 		        	 var raw=JSON.stringify(data);
 		        	
 		        	 raw=$.parseJSON(raw);
 		        	 if(raw.error.id=='0000'){
 		        		 
 		        		  
 		        		 window.location='term.html';
 		        	 }else{
 		        		 //alert(raw.error.message);
 		        		 $.MsgBox.Alert('温馨提示',raw.error.message);
 		        		
 		        	 }
 		         }
 			 })
    	
    })
    
    $('#addTime').click(function(){
    	if(bgettime){
    		swal('请先选择入学时间');
    	}
    })
    
    
 
    
   
    var numArr=[];
    var courseFigureArr=[];
    var starttime='';
    var calendar1 = new datePicker();

    calendar1.init({
    'trigger': '#termSt1', /*按钮选择器，用于触发弹出插件*/
    'type': 'ym',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
    'org':'1900-1-1',
    'minDate':'1900-1-1',/*最小日期*/
    'maxDate':'2100-12-31',/*最大日期*/
    'onSubmit':function(){/*确认时触发事件*/
    	$('.mobileSelect').remove();
        var theSelectData=calendar1.value;
        var entering='入学时间'+theSelectData;
        starttime=calendar1.value;
        starttime=starttime.substring(0,4);        
        starttime=parseInt(starttime)-6;
        numArr=[];
        courseFigureArr=[];
        for(var i=0;i<15;i++){
        	if(i>=5&&i<10){
        		starttime++;
        		var grading=i-4;
        		var grade='';
        		if(grading==1){
        			grade='一';
        		}
        		if(grading==2){
        			grade='二';
        		}
        		if(grading==3){
        			grade='三';
        		}
        		if(grading==4){
        			grade='四';
        		}
        		if(grading==5){
        			grade='五';
        		}
            	var st=starttime+1;        	
            	var starttimeplus=starttime+'年-'+st+'年'+'       大'+grade;
            	courseFigureArr.push(starttimeplus);
        	}else{
        		starttime++;
            	var st=starttime+1;        	
            	var starttimeplus=starttime+'年-'+st+'年';
            	courseFigureArr.push(starttimeplus);
        	}
        	
        	
        }
        bgettime=false;
        revealchooser(courseFigureArr,entering);  
          
        
	},
	'onClose':function(){/*取消时触发事件*/
		
	var forshow=calendar1.value;
	forshow=forshow.split('-')
	var selected=forshow[0]+'年-'+forshow[1]+'月';
 	
    $('#termSt1').children('em').text(selected);
    $('#termSt').val(calendar1.value);
    
	},
	'onClear':function(){
		
    
    }
 	 });
 
    
 
 
 var commiting=function(mes,para1,para2){
	    var url=cutUrl()+"/api/course/createXq";	 
		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "async":false,
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	
	        	 var raw=JSON.stringify(data);
	        	 raw=$.parseJSON(raw);
	        	 if(raw.error.id=='0000'){
	        		
	        		 resetCurrentWeek();
	        		 createterm(para1,para2);
	        	
	        		 
	        	 }else{
	        		 //alert(raw.error.message);
	        		 $.MsgBox.Alert('温馨提示',raw.error.message);
	        	 }
	        	 
	         }
		 })
 }
 
 
 
 var carlendar=function(id,udyear,udterm){
	
	 var orgDate=$(id).parent('.modefyDiv').siblings('.span1').text();
	 console.log(orgDate+'---'+id)
	 var calendar1 = new datePicker();
     calendar1.init({
     'trigger': id, /*按钮选择器，用于触发弹出插件*/
     'type': 'date',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
     'minDate':'1900-1-1',/*最小日期*/
     'org':orgDate,
     'maxDate':'2100-12-31',/*最大日期*/
     'onSubmit':function(){/*确认时触发事件*/
         var theSelectData=calendar1.value;
         
         
 },
 'onClose':function(){/*取消时触发事件*/
    
    $(id).parent('.modefyDiv').siblings('.span1').text(calendar1.value);
    var userId=localStorage.userId;
    var reg =/[\u4e00-\u9fa5]/g;
    udyear=udyear.replace(reg,'');
    udyear=udyear.replace(/(^\s*)|(\s*$)/g, "");
    if(udterm=='第一学期'){
    	udterm=1;
     
     }else if(udterm=='第二学期'){
    	 udterm=2;
     	
     }
    var mes='{"userId":"'+userId+'","xn":"'+udyear+'","xq":"'+udterm+'","kxsj":"'+calendar1.value+'"}';
    commitingupdate(mes);
    
 },
 'onClear':function(){
 	
     
     }
   });
 }
 
 
 var commitingupdate=function(mes){
	 var url=cutUrl()+"/api/kbsz/settingKxsj";	


	 $.ajax({
         "dataType": 'json',
         "type": "POST",
         "url": url,
         "data": mes,
         "contentType":"application/json;charset=utf-8",
         "success": function (data, textStatus, jqXHR){
        	 console.log(JSON.stringify(data));
        	 
         }
	 })
 }
 
 
 var resetCurrentWeek=function(){
	 	var userId=localStorage.userId;
		var resetUrl=cutUrl()+"/api/course/resetCurrentZs";
		var mes={"userId":userId};
		$.ajax({
	        "dataType": 'json',
	        "type": "GET",
	        "async":false,
	        "url": resetUrl,
	        "data": mes,
	        "contentType":"application/json;charset=utf-8",
	        "success": function (data, textStatus, jqXHR){
	        	var raw=JSON.stringify(data);
	        	console.log(raw);
	        	raw=$.parseJSON(raw);
	        	
	        }
		})
		
	}

 
 
 var commitingcurterm=function(mes){
	 var url=cutUrl()+"/api/kbsz/settingCurrentXq";	
	 
	 $.ajax({
         "dataType": 'json',
         "type": "POST",
         "url": url,
         "data": mes,
         "contentType":"application/json;charset=utf-8",
         "success": function (data, textStatus, jqXHR){
        	 var raw=JSON.stringify(data);
        	 raw=$.parseJSON(raw);
        	 
        	 
         }
	 })
 }
 
 var createterm=function(yt,term){
	 var reg =/[\u4e00-\u9fa5]/g;
	 
	 series++;
	 var yearshow=yt;
	 yearshow=yearshow.split('       ');
	 var forshow='';
	 if(yearshow.length==2){
		 forshow=yearshow[0].replace(reg,'')+' '+yearshow[1];
	 }else{
		 forshow=yearshow[0].replace(reg,'');
	 }
	 
	
	 var modifydateId='date'+series;
	 var carlenderId='#'+modifydateId;
	 
	 
	
	 var rawterm=yt.replace(reg,"");
	 rawterm=rawterm.split('-');
	 
	 
	 
	 if($('.termTitle').length==0){
		 var termbegin='';
		 if(term=="第一学期"){
			
			 
			 var sep=new Date();
			 sep.setDate(1);
			 sep.setMonth(8);
			 sep.setYear(rawterm[0])
			 sep=sep.Format('yyyy-MM-dd')
			 termbegin=sep;
			
			 
		 }else{
			
			 var mar=new Date();
			 mar.setDate(1);
			 mar.setMonth(2);
			 mar.setYear(rawterm[0])
			 mar=mar.Format('yyyy-MM-dd')
			 termbegin=mar;
			
			 
			 
		 }
		 /*
		 if(term=="第一学期"){
			 termbegin=rawterm[0]+'-09-01';
		 }else{
			 termbegin=rawterm[1]+'-03-01';
		 }*/
		 $('.tDiv').append("<div class='termDiv'><span class='termTitle'>"+forshow+"</span><div class='wrapper'><div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm nowTerm'><span class='termEm nowEm'>当前学期</span></div></a><span class='span1'>"+termbegin+"</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div></div></div>"); 
		
		 carlendar(carlenderId,yt,term);
		 console.log(carlenderId)
	 }else{
		 //...
		 var duplicate=false;
		 var extraterm=false;
		 var duplicateterm=false;
		 $('.termTitle').each(function(){	
			 
		 if($(this).text()==forshow){
			 
			 duplicate=true;
			 if($(this).siblings('.wrapper').children('.timeDiv').children('.span').text()==term){
				 duplicateterm=true;
				 return;
			 }
			 if($(this).siblings('.wrapper').children('.count').length<2){
				
				 if($(this).siblings('.wrapper').children('.timeDiv').children('.span').text()=="第一学期"){
					 $(this).siblings('.wrapper').append("<div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm'><span class='termEm'>设为当前</span></div></a><span class='span1'>"+rawterm[1]+"-03-01</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div>");
				 }else{			 
					 $(this).siblings('.wrapper').prepend("<div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm'><span class='termEm'>设为当前</span></div></a><span class='span1'>"+rawterm[0]+"-09-01</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div>");
				 }
				console.log(carlenderId+'\\\\\\\\\\\\\\\\\\\\\\\\\\\')
				 carlendar(carlenderId,yt,term);
			 }else{
				 extraterm=true;
				
			 }
			 
		 }
		 
	 })
	 if(duplicateterm){
		 //alert(term+'已经创建了');
		 $.MsgBox.Alert('温馨提示',term+'已经创建了');
	 }
	 if(extraterm){
		 //alert('该学年已经有两个学期了');
		 $.MsgBox.Alert('温馨提示','该学年已经有两个学期了');
	 }
	 
	 if(!duplicate){
		 var termbegin='';
		 var temp=new Date(rawterm[0]);
		
		 
		 if(term=="第一学期"){
			 temp.setMonth(8);
			 temp.setDate(1);
			 temp=temp.Format('yyyy-MM-dd')				
			 termbegin=rawterm[0]+'-09-01';
			 
			
		 }else{
			 temp.setMonth(2);
			 temp.setDate(1);
			 temp=temp.Format('yyyy-MM-dd')				
			 termbegin=rawterm[1]+'-03-01';
			 
		 }
			 $('.tDiv').append("<div class='termDiv'><span class='termTitle'>"+forshow+"</span><div class='wrapper'><div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm'><span class='termEm'>设为当前</span></div></a><span class='span1'>"+temp+"</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div></div></div>"); 
			 carlendar(carlenderId,yt,term);
	 }
		 //...
	 }
	 
	 $('.nowTermA').each(function(){
		 	
		 	$(this).click(function(){
		 		$('.nowTermA').children('.setTerm').removeClass('nowTerm');
			 	$('.nowTermA').children('.setTerm').children('.termEm').removeClass('nowEm');
			 	$('.nowTermA').children('.setTerm').children('.termEm').text('设为当前');
		 		$(this).children('.setTerm').addClass('nowTerm');
			 	$(this).children('.setTerm').children('.termEm').addClass('nowEm');			 				 	
			 	$(this).children('.setTerm').children('.termEm').text('当前学期');
			 	var reg =/[\u4e00-\u9fa5]/g;
			 	var userId=localStorage.userId;
			 	var curyear=$(this).parent('.timeDiv').parent('.wrapper').siblings('.termTitle').text();
			 	curyear=curyear.replace(reg,'').replace(/(^\s*)|(\s*$)/g, "");
			 	var curterm=$(this).siblings('.span').text();
			 	if(curterm=='第一学期'){
			 		curterm=1;
			 	}else if(curterm=='第二学期'){
			 		curterm=2;
			 	}
			 	var curstt=$(this).siblings('.span1').text();
			 	
			 	var mes='{"userId":"'+userId+'","xn":"'+curyear+'","xq":"'+curterm+'","kxsj":"'+curstt+'"}';
			 	commitingcurterm(mes);
			 	
			 	
		 	})
		 	})
		 	
	
	 
 }
 
 
 /*var createterm=function(yt,term){
	 
	 series++;
	 var reg =/[\u4e00-\u9fa5]/g;
	 var modifydateId='date'+series;
	 var carlenderId='#'+modifydateId;
	 
	 
	 
	 var rawterm=yt.replace(reg,"");
	 rawterm=rawterm.split('-');
	 
	 if($('.termTitle').length==0){
		 var termbegin='';
		 if(term=="第一学期"){
			 termbegin=rawterm[0]+'-09-01';
		 }else{
			 termbegin=rawterm[1]+'-03-01';
		 }
		 $('.tDiv').append("<div class='termDiv'><span class='termTitle'>"+yt+"</span><div class='wrapper'><div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm nowTerm'><span class='termEm nowEm'>当前学期</span></div></a><span class='span1'>"+termbegin+"</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div></div></div>"); 
		 carlendar(carlenderId,yt,term);
	 }else{
		 //...
		 var duplicate=false;
		 var extraterm=false;
		 var duplicateterm=false;
		 $('.termTitle').each(function(){	
			 
		 if($(this).text()==yt){
			 
			 duplicate=true;
			 if($(this).siblings('.wrapper').children('.timeDiv').children('.span').text()==term){
				 duplicateterm=true;
				 return;
			 }
			 if($(this).siblings('.wrapper').children('.count').length<2){
				
				 if($(this).siblings('.wrapper').children('.timeDiv').children('.span').text()=="第一学期"){
					 $(this).siblings('.wrapper').append("<div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm'><span class='termEm'>设为当前</span></div></a><span class='span1'>"+rawterm[1]+"-03-01</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div>");
				 }else{			 
					 $(this).siblings('.wrapper').prepend("<div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm'><span class='termEm'>设为当前</span></div></a><span class='span1'>"+rawterm[0]+"-09-01</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div>");
				 }
				 
				 carlendar(carlenderId,yt,term);
			 }else{
				 extraterm=true;
				
			 }
			 
		 }
		 
	 })
	 if(duplicateterm){
		 alert(term+'已经创建了');
	 }
	 if(extraterm){
		 alert('该学年已经有两个学期了');
	 }
	 
	 if(!duplicate){
		 var termbegin='';
		 var temp=new Date(rawterm[0]);
		 if(term=="第一学期"){
			 termbegin=rawterm[0]+'-09-01';
			 console.log('first term termbegin:'+termbegin);
		 }else{
			 termbegin=rawterm[1]+'-03-01';
			 console.log('second term termbegin:'+termbegin);
		 }
			 $('.tDiv').append("<div class='termDiv'><span class='termTitle'>"+yt+"</span><div class='wrapper'><div class='timeDiv count'><span class='span'>"+term+"</span><a href='javascript:;' class='nowTermA'><div class='setTerm'><span class='termEm'>设为当前</span></div></a><span class='span1'>"+termbegin+"</span><div class='modefyDiv'><img src='../image/modefy.png' alt=''><a href='javascript:;' class='mdfdate' id="+modifydateId+"><span class='modefySpan'>修改开学时间</span></a></div></div></div></div>"); 
			 carlendar(carlenderId,yt,term);
	 }
		 //...
	 }
	 
	 $('.nowTermA').each(function(){
		 	
		 	$(this).click(function(){
		 		$('.nowTermA').children('.setTerm').removeClass('nowTerm');
			 	$('.nowTermA').children('.setTerm').children('.termEm').removeClass('nowEm');
			 	$('.nowTermA').children('.setTerm').children('.termEm').text('设为当前');
		 		$(this).children('.setTerm').addClass('nowTerm');
			 	$(this).children('.setTerm').children('.termEm').addClass('nowEm');			 				 	
			 	$(this).children('.setTerm').children('.termEm').text('当前学期');
			 	var reg =/[\u4e00-\u9fa5]/g;
			 	var userId=localStorage.userId;
			 	var curyear=$(this).parent('.timeDiv').parent('.wrapper').siblings('.termTitle').text();
			 	curyear=curyear.replace(reg,'').replace(/(^\s*)|(\s*$)/g, "");
			 	var curterm=$(this).siblings('.span').text();
			 	if(curterm=='第一学期'){
			 		curterm=1;
			 	}else if(curterm=='第二学期'){
			 		curterm=2;
			 	}
			 	var curstt=$(this).siblings('.span1').text();
			 	
			 	var mes='{"userId":"'+userId+'","xn":"'+curyear+'","xq":"'+curterm+'","kxsj":"'+curstt+'"}';
			 	commitingcurterm(mes);
			 	
		 	})
		 	})
		 	
	
	 
 }*/
 
 
 	
 
 })