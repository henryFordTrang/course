var chooserOrg=function(spanset,id){
	  
	  	 var reg=/[\u4e00-\u9fa5]/g;
	     var rawFigure=$(id).text();
	     rawFigure=rawFigure.split(' ');
	     
	     var week=rawFigure[0];
	     var figureW=convertW(week)-1;
	     var sec=rawFigure[1];
	     sec=sec.split('-');
	    
	     var start=sec[0]-1;
	     
	     $('.center').css('padding-bottom','1.1rem');
	     
	     
	     
	     /*if(isIos()){
	    	 $('.center').css('padding-bottom','1.1rem');
				
				
				
			}*/
	     
	     
	     /*var end=sec[1];
	     var gap=parseInt(end)-parseInt(start);*/
	    
		 var mobileSelect3 = new MobileSelect({
				
			    trigger: id,
			    type:'1',
			    title: '设置课程时间',
			    wheels: [
			                {data:window.numArr},
			                
			              
			            ],
			    position:[figureW, start, 0], 
			    transitionEnd:function(indexArr, data){
			        
			    },
			    callback:function(indexArr, data){
			    	
			    	var dataCheckup=[];
			        dataCheckup.push(data[0].value);
			        dataCheckup.push(data[1].value.replace(reg,''));
			        dataCheckup.push(data[2].value.replace('第',''));
			        
			        
			    	var startingclass=dataCheckup[1];
			        var endingclass=dataCheckup[2];
			        endingclass=endingclass.replace(reg,'');
			        var dur=duration(spanset,startingclass,endingclass);       			        
			        //var forshow=dataCheckup[0]+' '+dataCheckup[1]+'-'+dataCheckup[2]+' '+dur;
			        var forshow=dataCheckup[0]+' '+dataCheckup[1]+'-'+dataCheckup[2];
			        $(id).text(forshow);
			        duplicateSeries(dataCheckup,id);
			        
			      
			    }
			});
  }

function set_focus(id)
{
    el=document.getElementById(id);
    
    //el=el[0];  //jquery 对象转dom对象
    el.focus();
    if($.support.msie)
    {
    	
        var range = document.selection.createRange();
        this.last = range;
        range.moveToElementText(el);
        range.select();
        document.selection.empty(); //取消选中
    }
    else
    {
    	
        var range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    }
}

$(function(){
	
		/*$('h1').each(function(){
			$(this).bind('focus',function(){
				$('.submit2').hide();
			}).bind('blur',function(){
				$('.submit2').show();
			})
		})*/
	
		/*$(document).on('focusin', function () {
		　　$('.submit2').css('display','none');
			$('.center').css('padding-bottom','0');
		});
		 
		$(document).on('focusout', function () {
		　$('.submit2').css('display','block');
		  $('.center').css('padding-bottom','1.1rem');
		});	*/
	    
	  
	   
		
		var clientHeight = document.documentElement.clientHeight || document.body.clientHeight; $(window).on('resize', function () {
		    var nowClientHeight = document.documentElement.clientHeight || document.body.clientHeight;
		    if (clientHeight > nowClientHeight) {
		       $('.submit2').css('display','none');
		       $('.center').css('padding-bottom','0');
		    }
		    else {
		    	$('.submit2').css('display','block');
		    	$('.center').css('padding-bottom','1.1rem');
		    } });
		
		//concealing();
	 	var fid=localStorage.fid;
	    var uid=localStorage.uid;
	    var userId=localStorage.userId;
	    var lesson=localStorage.lesson;
	    var paraset=[];
	    var reg=/[\u4e00-\u9fa5]/g;
	    var submiting=false;
	    
	    var weekspan=[];
	 	for(var i=1;i<26;i++){
	 		weekspan.push(i);
	 	}

	 	
	 	$('#courseName').keyup(function(){
			
			  var phoneNo=$(this).text();
			  console.log(phoneNo)
			  var rang=document.createRange();
			  if(phoneNo.length>30){		  
				  var phoneNo1=phoneNo.substring(0,30);
				  $("#courseName").text(phoneNo1);
				  	set_focus('courseName');

			  }
			  
			  
		  })
		  
		  
		  $('#teacherH1').keyup(function(){
			  var phoneNo=$(this).text();
			  var rang=document.createRange();
			  if(phoneNo.length>30){		  
				  var phoneNo1=phoneNo.substring(0,30);
				  $("#teacherH1").text(phoneNo1);
				  set_focus('teacherH1');

			  }
			  
			  
		  })
		  
		  
		  
	 	
	    
	  //...加载题目
        
        var paraset=[];
		var spanurl=cutUrl()+"/api/kbsz/qryJcTime";
	   	var spanmes='{"userId":"'+userId+'"}';
	   	var url=cutUrl()+"/api/course/qryKcDetailsByKcName";
		var mes='{"userId":"'+userId+'","courseName":"'+lesson+'","js":"","xnxqId":""}';
	   	$.ajax({
         	"dataType": 'json',
         	"type": "POST",
         	"url": spanurl,
         	"data": spanmes,
         	"contentType":"application/json;charset=utf-8",
         	"success": function (data, textStatus, jqXHR){
         		var raw=JSON.stringify(data);
         		
         		raw=$.parseJSON(raw);
         		$.each(raw.list,function(k,dom2){
         			
         			var duration=dom2.jcdm+','+dom2.jckssj+','+dom2.jcjssj;
         			paraset.push(duration);
         		})
         		
         		$.ajax({
					"dataType": 'json',
					"type": "POST",
					"url": url,
					"data": mes,
					"contentType":"application/json;charset=utf-8",
					"success": function (data, textStatus, jqXHR){
						var raw1=JSON.stringify(data);
						console.log(raw1)
						raw1=$.parseJSON(raw1);
						if(raw1.error.id=='0000'){
							$('#newColor').val(raw1.kcDetailsList[0].color);
							localStorage.termId=raw1.kcDetailsList[0].xnxqId;
							$('#courseName').text(raw1.kcDetailsList[0].courseName);
							$('#teacherH1').text(raw1.kcDetailsList[0].js);
							$.each(raw1.kcDetailsList,function(i,dom3){
								
								var index1='sub'+dom3.id+1000;
								var index2='sub'+dom3.id+2000;
								var index3='sub'+dom3.id+3000;
								var index4='sub'+dom3.id+4000;
								var index5=i+1;
								var index6='sub'+dom3.id+6000;
								var index7='sub'+dom3.id+7000;
								var index8='sub'+dom3.id+8000;
								var index9='sub'+dom3.id+9000;
								$('.center').append("<ul class='courseUl2'><li><div class='filed line cancelCon' id="+index1+"></div><div class='filed classroom' id="+index2+"></div><hr><div class='filed schedule' id="+index3+"></div><hr><div class='filed week' id="+index4+"></div><input type='hidden' class='courseId' value="+dom3.id+"></li></ul>");
								$('#'+index1).append("<span class='fileName1' id='courseSeries1'>上课时间-"+index5+"</span><a class='removeA' href='javascript:;' id="+index6+"><img src='../image/removeItem.png' alt=''></a>");
								$('#'+index2).append("<span class='fileName'><img src='../image/courseP.png' alt=''></a>教室：</span><div class='fileCon'><h1  contenteditable='true' id="+index9+" class='fileContent' id='classroom' placeholder='请输入教室位置'>"+dom3.room+"</h1></div>");
								$('#'+index3).append("<span class='fileName'><img src='../image/courseT.png' alt=''></a>时间：</span><div class='fileCon'><div class='trigger' id="+index7+" placeholder='请选择上课时间'></div><input type='hidden' class='xqs' value=''><input type='hidden' class='ksjc'  value=''><input type='hidden' class='jsjc'  value=''></div>");
								$('#'+index4).append("<span class='fileName'><img src='../image/courseW.png' alt=''></a>周数：</span><a href='javascript:;'><div class='fileCon'><input type='hidden' name='' class='dataKeep'><input type='hidden' name='' value="+dom3.color+" class='colorKeep'><div class='cherry' id="+index8+" placeholder='请填写周数'></div></div></a>");
								/*$('#'+index2).append("<hr>");
								$('#'+index3).append("<hr>");*/
								var weekspec=dom3.xqs
								weekspec=chineseW(weekspec);
								
								
								var series=dom3.jcdm;
								series=series.split(',');								
								var dura=duration(paraset,series[0],series[series.length-1]);
							    series=series[0]+'-'+series[series.length-1]+'节';							    
							    //$('#'+index7).text(weekspec+' '+series+' '+dura);
							    $('#'+index7).text(weekspec+' '+series);
							    
							    var dataset=simpleData(dom3.zc);
							    
							    
							    $('#'+index3).children('.fileCon').children('.xqs').val(weekspec);
								$('#'+index3).children('.fileCon').children('.ksjc').val(series[0]);
								$('#'+index3).children('.fileCon').children('.jsjc').val(series[series.length-1]);
							    
								
								
								if(dataset=='2,4,6,8,10,12,14,16,18,20,22,24'){
									dataset='双'
	         					}else if(dataset=='1,3,5,7,9,11,13,15,17,19,21,23,25'){
	         						dataset='单'
	         					}
								
							    $('#'+index8).text(dataset+'周');
							    $('#'+index8).siblings('.dataKeep').val(dom3.zc+'周');
							    $('#'+index7).after(function(){
					            	chooserOrg(paraset,'#'+index7);
					            	
					            })
					             $('#'+index8).after(function(){
					            	
					            	weekchooser('#'+index8);
					            	
					            }) 
					            
					            $('#'+index9).keyup(function(){
					  			  var phoneNo=$(this).text();
								  var rang=document.createRange();
								  if(phoneNo.length>30){		  
									  var phoneNo1=phoneNo.substring(0,30);
									  $('#'+index9).text(phoneNo1);
									  set_focus(index9);

								  }			  			  
					            	})
					            
					            
					            lengthCheck();
							    
								
								
							})
							
						}else{
							//alert(raw1.error.message);
							$.MsgBox.Alert('温馨提示',raw1.error.message);
						}
						
						
						
      		 			
						
						
						
					}
				})
         	}
	   	})
	    
	    
	    $('.menu_l').click(function(){
	 		window.location="courseDetail.html";
	 	})
        $("#teacherH1").keyup(function () {
          if(!($(this).text()==null||$(this).text()=="")){
            $('#cancelImg').show();
        }
        });
        $('.canA').click(function(){
          $("#teacherH1").text("");
          $('#cancelImg').hide();
        })    
	    
	   
        				var sId=3;
				        $('#addTime').click(function(){
				        	sId++; 
				        	var selectorId='triger'+sId;       	
				        	var weekSelector='cherry'+sId;
				        	var courseId='courseSeries'+sId;
				        	var contentId='content'+sId;
				           
				           // $('.center').append('<ul class="courseUl2"><li><div class="filed line cancelCon"><span class="fileName1" id="'+courseId+'">上课时间-1</span><a class="removeA" href="javascript:;"><img id="removeImg" src="../image/removeItem.png" alt=""></a></div><div class="filed line classroom"><span class="fileName"><img src="../image/courseP.png" alt=""></a>教室：</span><div class="fileCon"><h1  contenteditable="true" class="fileContent" placeholder="请输入教室位置"></h1></div></div><div class="filed line schedule"><span class="fileName"><img src="../image/courseT.png" alt=""></a>时间：</span><div class="fileCon"><div class="fixWidth"><div class="nav"></div><div class="demo"><a><div class="trigger" id="'+selectorId+'" placeholder="请选择上课时间"></div></a></div></div></div></div><div class="filed week"><span class="fileName"><img src="../image/courseW.png" alt=""></a>周数：</span><a><div class="cherry" id="'+weekSelector+'" placeholder="请填写周数"></div></a></div></div></li></ul>');

				            $('.center').append('<ul class="courseUl2"><li><div class="filed line cancelCon"><span class="fileName1" id="'+courseId+'">上课时间-1</span><a class="removeA" href="javascript:;"><img class="removeImg" src="../image/removeItem.png" alt=""></a></div><div class="filed classroom"><span class="fileName"><img src="../image/courseP.png" alt="">教室：</span><div class="fileCon"><h1 id='+contentId+' contenteditable="true" class="fileContent" placeholder="请输入教室位置"></h1></div></div><hr><div class="filed schedule"><span class="fileName"><img src="../image/courseT.png" alt="">时间：</span><div class="fileCon"><div class="trigger" id="'+selectorId+'" placeholder="请选择上课时间"></div><input type="hidden" class="xqs" value="0"><input type="hidden" class="ksjc"  value="0"><input type="hidden" class="jsjc"  value="0"></div></a></div><hr><div class="filed week"><span class="fileName"><img src="../image/courseW.png" alt="">周数：</span><a href="javascript:;"><div class="fileCon"><input type="hidden" name="" class="dataKeep"><div class="cherry" id="'+weekSelector+'" placeholder="请填写周数"></div></div></a></div></li></ul>');
				            $('#'+selectorId).after(function(){
				            	chooser('#'+selectorId,paraset);
				            	
				            })
				             $('#'+weekSelector).after(function(){
				            	
				            	$(this).siblings('.dataKeep').val(weekspan+'周');
				            	$(this).text('1-25周');
				            	weekchooser('#'+weekSelector);
				            }) 
				            
				            
				             $('#'+contentId).keyup(function(){
							  var phoneNo=$(this).text();
							  var rang=document.createRange();
							  if(phoneNo.length>30){		  
								  var phoneNo1=phoneNo.substring(0,30);
								  $('#'+contentId).text(phoneNo1);
								  set_focus(contentId);
				
							  }			  			  
				            	})
				            
				           
				            var length=0;
				            $('.fileName1').each(function(){
				            	length++;
				            	$(this).html('上课时间-'+length);
				            })
				            
				            lengthCheck();
				            $("body").scrollTop($(".center")[0].scrollHeight);//滑动条定位在底部
				           
				        });
						
			
				        
			
         
            $(document).on('click','.removeA',function() {
            	 var courseId=$(this).parents('li').children('.courseId').val();
                 var this_=$(this);
            	 $.MsgBox.Confirm("温馨提示", "确认在课表中删除此课程吗?", function () {
            		 
                   	if(courseId!=undefined&&courseId.length>0){
                   		var deleteS=[];
                   		deleteS.push(courseId);
                   		deleteS='['+deleteS+']';
               			var delurl=cutUrl()+"/api/course/deleteCourses";
               			var delmes='{"idList":'+deleteS+'}';
               	    
               			$.ajax({
               			"dataType": 'json',
               			"type": "POST",
               			"url": delurl,
               			"data": delmes,
               			"contentType":"application/json;charset=utf-8",
               			"success": function (data, textStatus, jqXHR){
               				var raw=JSON.stringify(data);
               				
               				raw=$.parseJSON(raw);
               				
               				if(raw.error.id=="0000"){
               					
               					this_.parents('ul').remove();
               					
               	                 var length=0;
               	                $('.fileName1').each(function(){
               	                	
               	                	length++;
               	                	
               	                	this_.html('上课时间-'+length);
               	                }) 
               	                
               	                if(length==1){
               	                	$('.removeA').hide();
               	                }else{
               	                	$('.removeA').show();
               	                }
               					
               				}else{
               					//alert(raw.error.message);
               					$.MsgBox.Alert('温馨提示',raw.error.message);
               				}
               			}
               			})
                   		
                   		
                   	}else{
                   		
                   		this_.parents('ul').remove();
                           var length=0;
                          $('.fileName1').each(function(){
                          	length++;
                          	this_.html('上课时间-'+length);
                          }) 
                   	}
                 	
                 	
                 	lengthCheck();
            		 
            		 
            	 },function () {
            		
            		 return;
            		 
            	 })
            		
            	
            	/* var courseId=$(this).parents('li').children('.courseId').val();
              	var this_=$(this);
              	if(courseId!=undefined&&courseId.length>0){
              		var deleteS=[];
              		deleteS.push(courseId);
              		deleteS='['+deleteS+']';
          			var delurl=cutUrl()+"/api/course/deleteCourses";
          			var delmes='{"idList":'+deleteS+'}';
          	    
          			$.ajax({
          			"dataType": 'json',
          			"type": "POST",
          			"url": delurl,
          			"data": delmes,
          			"contentType":"application/json;charset=utf-8",
          			"success": function (data, textStatus, jqXHR){
          				var raw=JSON.stringify(data);
          				console.log(raw)
          				raw=$.parseJSON(raw);
          				
          				if(raw.error.id=="0000"){
          					
          					this_.parents('li').remove();
          					
          	                 var length=0;
          	                $('.fileName1').each(function(){
          	                	
          	                	length++;
          	                	
          	                	$(this).html('上课时间-'+length);
          	                }) 
          	                
          	                if(length==1){
          	                	$('.removeA').hide();
          	                }else{
          	                	$('.removeA').show();
          	                }
          					
          				}else{
          					alert(raw.error.message);
          				}
          			}
          			})
              		
              		
              	}else{
              		console.log(999)
              		$(this).parents('li').remove();
                      var length=0;
                     $('.fileName1').each(function(){
                     	length++;
                     	$(this).html('上课时间-'+length);
                     }) 
              	}*/
            	
            	
            	//lengthCheck();
                
                
            	});  
        
       
        
        
        /* $('.trigger').each(function(){

        		 var id=$(this).attr('id');
        		 id='#'+id;
        		
        		 var mobileSelect3 = new MobileSelect({
        				
        			    trigger: id,
        			    type:'1',
        			    title: '设置课-----程时间',
        			    wheels: [
        			                {data: window.numArr},
        			                {data: courseFigureArr},
        			                {data: courseArr},
        			                 {data: hourFigureArr},
        			                {data: timerArr},
        			                {data: spaceArr},
        			                {data: hourFigureArr},
        			                {data: timerArr} 
        			              
        			            ],
        			    position:[2, 2, 2, 2, 2], 
        			    transitionEnd:function(indexArr, data){
        			        
        			    },
        			    callback:function(indexArr, data){
        			        console.log(data)
        			        duplicateSeries(data,id);
        			    }
        			});
        	
         })*/
         
       //判断全部，单双周选择个数
         var judgeSingleOrPair=function(){
        	 
             var singleTotalNum=0;
             var pairTotalNum=0;
             var totalNum=0;
             $('.flag').each(function(){//全部
                 totalNum+=parseInt($(this).val());
             })
             $('.fPair').each(function(){//双周
                 pairTotalNum+=parseInt($(this).val());
             })
             $('.fSingle').each(function(){//单周
                 singleTotalNum+=parseInt($(this).val());
             })
             $('.odder').removeClass('odder_selected');
             if(totalNum==25){
                 $('.odder1').addClass('odder_selected');
                 return 'all';
             }
             if(singleTotalNum==13&&pairTotalNum==0){
                $('.odder3').addClass('odder_selected'); 
                return 'single';
             }
             if(pairTotalNum==12&&singleTotalNum==0){
                $('.odder2').addClass('odder_selected'); 
                return 'multiple';
             }
             //console.log(totalNum+" "+singleTotalNum+" "+pairTotalNum);
         }
         //判断全部，单双周选择个数-end
         
         $('.cherry').each(function(){
          	
        	 
        	 $(this).click(function(){
        		 /*$('.seatCharts-seat').each(function(){
    					$(this).children('input[type=hidden').val('0')
    		           	

    		           })*/
        		 var selectedId=$(this).attr('id');
        		 
        		 var existContent=$(this).siblings('.dataKeep').val();
        		 var restoreVal=$(this).siblings('.dataKeep').val();
           		 var restoreFig=$(this).text();
        		 if(existContent.length>0){
        			 existContent=existContent.replace(reg,'');
        			 existContent=existContent.split(',');
        			 
        			 $.each(existContent,function(i,dom){
        				 $('.seatCharts-seat').each(function(){
        					
        		           	if($(this).text()==dom){
        		           		
        		           		$(this).addClass('selected');
        		           		$(this).children('input[type=hidden]').val('1');
        		           	}
        		           

        		           })
        		           
        		           judgeSingleOrPair();
        			 })
        		 }
        		 
        		 
        		 
        		 var chooseArr=[];
        		 materialConfirm('选择周数','how are you',function(result){
        			 if(!result){
        				 $('.seatCharts-seat').each(function(){
            					$(this).children('input[type=hidden]').val('0');
            					if($(this).hasClass('selected')){
            						$(this).removeClass('selected').addClass('available')
            					}
            				})
            				
         				return;
         			}
        			 
        			 $('.selected').each(function(){
        				 
        				 chooseArr.push($(this).text());
        				 
        			 })
        			 var groupCheck=judgeSingleOrPair();
        			 /*if(chooseArr.length==0){
        				 $('#'+selectedId).text();
        			 }else{
        				 $('#'+selectedId).text(chooseArr+'周');
        			 }*/
        			 var convertfigure=dataSet(chooseArr);
        			 
        			 if(convertfigure.length==0){
        				 $('#'+selectedId).text();
        				
        			 }else if(groupCheck=='single'){
        				 $('#'+selectedId).text('单周');
        			 }else if(groupCheck=='multiple'){
        				 $('#'+selectedId).text('双周');
        			 }else{
        				 $('#'+selectedId).text(convertfigure+'周');
        				
        				 
        			 }
        			 
        			 if(chooseArr.length==0){
        				
        				 $('#'+selectedId).siblings('input[type=hidden]').val();
        			 }else{
        				 
        				 $('#'+selectedId).siblings('input[type=hidden]').val(chooseArr+'周');
        				 
        			 }
        			
        			 $('.seatCharts-seat').addClass('available').removeClass('selected'); 
        			
        			 	duplicationWeek(selectedId,chooseArr,1,restoreVal,restoreFig); 
        			 	//duplicationWeek(selectedId,chooseArr,1);        			         			 
                	 }) 
        		 
        	 })
        	 
        	
         })
         
        
         
         $('.seatCharts-seat').each(function(){
           	 $(this).click(function(){
           	 	$(this).toggleClass('available').toggleClass('selected');
	           	 if($(this).hasClass("selected")){
	                 $(this).children('.flag').val(1);
	             }else{
	                 $(this).children('.flag').val(0);
	             }
	             judgeSingleOrPair();
           	 })
           	

           })


            $('#odder').click(function(){ 
            	$('.odder').removeClass('odder_selected');
                $(this).children('.odder').addClass('odder_selected');

            	$('.seatCharts-seat').each(function(){

            		var oddercheck=$(this).text();
            		$(this).removeClass('selected').removeClass('available');
            		if(oddercheck%2>0){
            			
            			
            			$(this).addClass('selected');
            			$(this).attr("aria-checked",true);


            		}else{

            			$(this).addClass('available');
            			$(this).attr("aria-checked",false);
            		}
            		if($(this).hasClass("selected")){
                        $(this).children('.flag').val(1);
                    }else{
                        $(this).children('.flag').val(0);
                    }
            		
            	})
            	judgeSingleOrPair();
            })

            $('#even').click(function(){
            	$('.odder').removeClass('odder_selected');
                $(this).children('.odder').addClass('odder_selected');
            	$('.seatCharts-seat').each(function(){
            		var oddercheck=$(this).text();
            		$(this).removeClass('selected').removeClass('available');
            		if(oddercheck%2==0){
            			/*$(this).removeClass('seatCharts-seat seatCharts-cell available');*/
            			$(this).addClass('selected');
            			$(this).attr("aria-checked",true);
            		}else{
            			$(this).addClass('available');
            			$(this).attr("aria-checked",false);
            		}
            		
            		if($(this).hasClass("selected")){
                        $(this).children('.flag').val(1);
                    }else{
                        $(this).children('.flag').val(0);
                    }
            		
            	})
            	judgeSingleOrPair();
            })

				var isSelected=false;
          
            
            
            $('#chooseAll').click(function(){
            	$('.seatCharts-seat').each(function(){
            		
            		if($(this).children('input[type=hidden]').val()=='0'){
            			isSelected=true;
            		}else{
            			isSelected=false;
            		}
            		
            	})
            	
            	
            	
            	if(!isSelected){
            		$('.seatCharts-seat').addClass('available').removeClass('selected');
            	}else{
            		$('.seatCharts-seat').addClass('selected').removeClass('available');
            	}
            	
            	
            	$('.seatCharts-seat').each(function(){
                    if($(this).hasClass("selected")){
                        $(this).children('.flag').val(1);
                    }else{
                        $(this).children('.flag').val(0);
                    }

                })
                judgeSingleOrPair();
            })
            
            
            
            var weekchooser=function(id){
            	$(id).click(function(){
            		
            	 var selectedId=$(this).attr('id');
            	 var restoreVal=$(this).siblings('.dataKeep').val();
              	 var restoreFig=$(this).text();
           		 var existContent=$(this).siblings('.dataKeep').val();
           		 if(existContent.length>0){
           			 existContent=existContent.replace(reg,'');
           			 existContent=existContent.split(',');
           			 
           			 $.each(existContent,function(i,dom){
           				 $('.seatCharts-seat').each(function(){
           					
           		           	if($(this).text()==dom){
           		           		
           		           		$(this).addClass('selected');
           		           		$(this).children('input[type=hidden]').val('1');
           		           	}
           		           

           		           })
           		           
           		           judgeSingleOrPair();
           			 })
           		 }
           		 
           		 
           		 
           		 var chooseArr=[];
           		 materialConfirm('请选择周数','how are you',function(result){
           			 
           			if(!result){
           				$('.seatCharts-seat').each(function(){
           					$(this).children('input[type=hidden]').val('0');
           					if($(this).hasClass('selected')){
        						$(this).removeClass('selected').addClass('available')
        					}
           				})
           				
        				return;
        			}
           			
           			 $('.selected').each(function(){
           				 chooseArr.push($(this).text());
           				 
           			 })
           			 
           			 var groupCheck=judgeSingleOrPair();
           			 var convertfigure=dataSet(chooseArr);
        			 
        			 if(convertfigure.length==0){
        				 $('#'+selectedId).text();
        				
        			 }else if(groupCheck=='single'){
        				 $('#'+selectedId).text('单周');
        			 }else if(groupCheck=='multiple'){
        				 $('#'+selectedId).text('双周');
        			 }else{
        				 $('#'+selectedId).text(convertfigure+'周');
        				
        				 
        			 }
        			 
        			 if(chooseArr.length==0){
        				
        				 $('#'+selectedId).siblings('input[type=hidden]').val();
        			 }else{
        				 
        				 $('#'+selectedId).siblings('input[type=hidden]').val(chooseArr+'周');
        				 
        			 }
           			
           			 $('.seatCharts-seat').addClass('available').removeClass('selected'); 
           			
           			 	duplicationWeek(selectedId,chooseArr,1,restoreVal,restoreFig); 
           			 	//duplicationWeek(selectedId,chooseArr,1);        			         			 
                   	 }) 
            		
            		
            	})
            	
            }
            
            
            
            
            
			
	 
	 	
            
            
            //点击完成
            
            $('.menu_r').click(function(){
            	$('[contenteditable="true"]').blur();
            	$("body").scrollTop($(".center")[0].scrollHeight);//滑动条定位在底部
            	
            	if(submiting){
            		return;
            	}
        		
            	submiting=true;
            	
            	var course=$('#courseName').text();
            	var teacher=$('#teacherH1').text();
            	var set=[];
            	
            	var bcourse=true;
            	var bteaher=true;
            	var bclassroom=true;
            	var bschedule=true;
            	var bweek=true;
            	var termId=localStorage.termId;
            	var bblankseries=true;
            	var blankseries='';
            	
            	if(course.length>0){
            		bcourse=false;
            		
            		
            	}else{
            		bcourse=true;
            		
            	}
            	
            	if(teacher.length>0){
            		bteaher=false;
            		
            	}else{
            		bteaher=true;
            		
            	}
            	
            	$('.fileName1').each(function(){
            		
            		var courseId=$(this).parents('li').children('.courseId').val();            		            		
            		var classroom=$(this).parent('.filed').siblings('.classroom').children('.fileCon').children('.fileContent').text();
            		var schedule=$(this).parent('.filed').siblings('.schedule').children('.fileCon').children('.trigger').text();
            		var week=$(this).parent('.filed').siblings('.week').children('a').children('.fileCon').children('.dataKeep').val();
            		var color=$(this).parent('.filed').siblings('.week').children('a').children('.fileCon').children('.colorKeep').val();
            		week=week.replace(reg,'');   
            		if(schedule!=''){
            			schedule1=schedule.split(' ');
                		schedule2=schedule.split('-');
                		
                		
            		}else{
            			blankseries=$(this).text();
            			
            			bblankseries=false;
            			return;
            		}
            		
            		schedule1=schedule.split(' ');           		
            		schedule2=schedule.split('-');            		
            		var startingCls=schedule2[0].replace(reg,'');
            		var secondCls=schedule2[1].replace(reg,'');
            		startingCls=parseInt(startingCls);
            		secondCls=parseInt(secondCls);
            		
            		if(startingCls==secondCls){
            			courseClass=startingCls;
            		}else{
            			var variable=startingCls;
            			courseClass=startingCls;
            			for(var q=0;q<(secondCls-startingCls);q++){
            				variable++;
            				courseClass+=','+variable;
            			}
            		}
            		var day=convertW(schedule1[0]);
            		
            		
            		
            		
					if(classroom.length>0){
						bclassroom=false;
						
            		}else{
            			
            			bclassroom=true;
            			
            		}
					
					if(schedule.length>0){
						bschedule=false;
						
            		}else{
            			bschedule=true;
            			
            		}
            		
					if(week.length>0){
						bweek=false;
						
						
					}else{
						bweek=true;
						
					}
					
					
					
					week=week.replace(reg,'');
					
					
					/*if(courseId!=undefined&&courseId.length>0){
						//unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","id":"'+courseId+'","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
						if(courseClass.length>0){
							
							courseClass=courseClass.split(',');
							for(var y=0;y<courseClass.length;y++){
								if(y==0){
									var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass[y]+'","courseName":"'+course+'","status":"1","id":"'+courseId+'","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
								}else{
									var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass[y]+'","courseName":"'+course+'","status":"1","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
								}
								
								set.push(unitmes);
							}
						}else{
							
							var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","id":"'+courseId+'","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
							set.push(unitmes);
						}
					}else{
						if(courseClass.length>0){
							courseClass=courseClass.split(',');
							for(var y=0;y<courseClass.length;y++){
								var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass[y]+'","courseName":"'+course+'","status":"1","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
								set.push(unitmes);
							}
						}else{
							var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
							set.push(unitmes);
						}
						
						
						//unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
					}*/
					
					
					if(courseId!=undefined&&courseId.length>0){
						//unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","id":"'+courseId+'","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
					
							
							var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","id":"'+courseId+'","zc":"'+week+'","color":"'+color+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
							set.push(unitmes);
						
					}else{
						
							var unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","zc":"'+week+'","color":"'+$('#newColor').val()+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
							set.push(unitmes);
						
						
						
						//unitmes='{"userId":"'+userId+'","js":"'+teacher+'","room":"'+classroom+'","jcdm":"'+courseClass+'","courseName":"'+course+'","status":"1","zc":"'+week+'","xqs":"'+day+'","xnxqId":"'+termId+'"}';
					}
					
					
            		//set.push(unitmes);
            		
            	})
            	
            	
            	
            	var submit=false;
            	
            	if(bcourse){
            		submiting=false;
            		swal('请设置课程名称');
            		return;
            	}
            	
            	//周数节次没填的情况
            	if(!bblankseries){
            		submiting=false;
            		swal('请设置具体上课时间');
            		return;
            	}
            	
            	
				if(!bcourse&&!bschedule&&!bweek){
            		
            		submit=true;
            	}else{
            		var ncourse='';
                	var nteacher='';
                	var nclassroom='';
                	var nschedule='';
                	var nweek='';
                	
                	if(bcourse){
                		ncourse='课程名,';
                	}
                	if(bteaher){
                		nteacher='教师,';
                	}
                	if(bclassroom){
                		nclassroom='教室,';
                	}
                	if(bschedule){
                		nschedule='时间,';
                	}
                	if(bweek){
                		nweek='周数,';
                	}
                	
                	
                	
                	var general=ncourse+nschedule+nweek;
                	
                	general=general.split(',');
                	general=general[0]+'还没填哦要继续吗';
            		submit=confirm(general);
            	}
				
				
				
				
				if(submit){
					   
					   var url=cutUrl()+"/api/course/editKcDetails";
					  
					 // var mes='{"userId":"'+uid+'","fid":"'+fid+'","schoolName":"'+sc+'","department":"'+dp+'"}';
					 set='['+set+']';
					 
					 
					 var mes='{"list":'+set+'}';
					 
					  
						 $.ajax({
					         "dataType": 'json',
					         "type": "POST",
					         "url": url,
					         "data": mes,
					         "contentType":"application/json;charset=utf-8",
					         "success": function (data, textStatus, jqXHR){
					        	 var raw=JSON.stringify(data);
					        	
					        	 raw=$.parseJSON(raw);
					        	 submiting=false;
					        	 
					        	 if(raw.error.id=='0000'){
					        		 localStorage.lesson=course;
					        		 window.location="courseDetail.html"; 
					        		// window.location="term.html";
					        	 }else{
					        		 alert(raw.error.message);
					        		 $.MsgBox.Alert('温馨提示','我是你妈');
					        	 }
					        	
					        	 
					        	
					        	 
					        	 
					         }
						 }) 
					
				}else{
					submiting=false;
				}
            	
            	
        	})
        	
        	
        	
        
 })
 
 	var simpleData=function(info){
	
		var infoArr=info.split(",");
	    var rres="";
	    var res=fn(infoArr);
	    for (var i = 0; i < res.length; i++) {
	        var item=res[i];
	        if(item.length==1){
	            rres+=item[0]+",";
	        }else{
	            rres+=item[0]+"-"+item[item.length-1]+",";
	        }
	        
	    }
	    rres=rres.substring(0,rres.length-1);
	    return rres;
	}
 
 
	 var fn=function(arr){
		   var result = [],
		       i = 0;
		   result[i] = [arr[0]];
		   arr.reduce(function(prev, cur){
		     cur-prev === 1 ? result[i].push(cur) : result[++i] = [cur];
		     return cur;
		   });
		  
		   return result;
		 }
 
 
 	var dataSet=function(chooseArr){
	             var arrInfo="";
	   			 for(var x=0;x<chooseArr.length;x++){
	   				 arrInfo+=chooseArr[x]+',';
	   			 }
	   			 arrInfo=arrInfo.substring(0,arrInfo.length-1);
	   			 console.log("arrInfo="+arrInfo);
	   			 var infoArr=arrInfo.split(",");
	   			    var rres="";
	   			    var res=fn(infoArr);
	   			    for (var i = 0; i < res.length; i++) {
	   			        var item=res[i];
	   			        if(item.length==1){
	   			            rres+=item[0]+",";
	   			        }else{
	   			            rres+=item[0]+"-"+item[item.length-1]+",";
	   			        }
	   			        
	   			    }
	   			    rres=rres.substring(0,rres.length-1);
	   			    return rres;
            }
 
 
  
  var chooser=function(id,spanset){
	
		 var mobileSelect3 = new MobileSelect({
				
			    trigger: id,
			    type:'1',
			    title: '设置课程时间',
			    wheels: [
			                {data: window.numArr},
			                /* {data: courseFigureArr},
			                {data: courseArr},
			                {data: hourFigureArr},
			                {data: timerArr},
			                {data: spaceArr},
			                {data: hourFigureArr},
			                {data: timerArr} */
			              
			            ],
			    position:[2, 2, 2, 2, 2], 
			    transitionEnd:function(indexArr, data){
			       
			    },
			    callback:function(indexArr, data){
			    	var reg=/[\u4e00-\u9fa5]/g;
			    	var dataCheckup=[];
			        dataCheckup.push(data[0].value);
			        dataCheckup.push(data[1].value.replace(reg,''));
			        dataCheckup.push(data[2].value.replace('第',''));
			        
			        
			    	var startingclass=dataCheckup[1];
			        var endingclass=dataCheckup[2];
			        endingclass=endingclass.replace(reg,'');
			        var dur=duration(spanset,startingclass,endingclass);       			        
			        //var forshow=dataCheckup[0]+' '+dataCheckup[1]+'-'+dataCheckup[2]+' '+dur;
			        var forshow=dataCheckup[0]+' '+dataCheckup[1]+'-'+dataCheckup[2];
			        $(id).text(forshow);
			        duplicateSeries(dataCheckup,id);
			        
			        /*console.log(data+'****');
			        var reg=/[\u4e00-\u9fa5]/g;
			    	var startingclass=data[1];
			        var endingclass=data[2];
			        endingclass=endingclass.replace(reg,'');
			        var dur=durationf(spanset,startingclass,endingclass);       			        
			        var forshow=data[0]+' '+data[1]+'-'+data[2]+' '+dur;
			        $(id).text(forshow);
			        duplicateSeries(data,id);*/
			    }
			});
  }
 
 
 var chineseW=function(val){
	  if(val==1){
		  return '周一';
	  }else if(val==2){
		  return '周二';
	  }else if(val==3){
		  return '周三';
	  }else if(val==4){
		  return '周四';
	  }else if(val==5){
		  return '周五';
	  }else if(val==6){
		  return '周六';
	  }else if(val==7){
		  return '周日';
	  }
	  
 }
 
 
 var durationf=function(spanset,start,end){
	   var starttime='';
	   var endtime='';
	   for(i=0;i<spanset.length;i++){
		   
		  
		   var spanunit=spanset[i].split(',');
		  
		  
		   if(spanunit[0]==start){
			   starttime=spanunit[1];
		   }
		   if(spanunit[0]==end){
			   endtime=spanunit[2];
		   }
		   
		   
	   }
	   
	   var returnval=starttime+'-'+endtime;
	   return returnval;
	   
 }
 
  var lengthCheck=function(){
	  	    
	  var lengthC=0
		$('.removeA').each(function(){
			lengthC++;
			
		})
     if(lengthC<2){
  	   $('.removeA').hide();
     }else{
  	   $('.removeA').show();
     }
			
  }
  
  
  var duration=function(spanset,start,end){
	   var starttime='';
	   var endtime='';
	   for(i=0;i<spanset.length;i++){
		   
		  
		   var spanunit=spanset[i].split(',');
		  
		  
		   if(spanunit[0]==start){
			   starttime=spanunit[1];
		   }
		   if(spanunit[0]==end){
			   endtime=spanunit[2];
		   }
		   
		   
	   }
	   
	   var returnval=starttime+'-'+endtime;
	   return returnval;
	   
  }
  
  var convertW=function(val){
	  if(val=='周一'){
		  return 1;
	  }else if(val=='周二'){
		  return 2;
	  }else if(val=='周三'){
		  return 3;
	  }else if(val=='周四'){
		  return 4;
	  }else if(val=='周五'){
		  return 5;
	  }else if(val=='周六'){
		  return 6;
	  }else if(val=='周日'){
		  return 7;
	  }
	  
  }
  
  var duplicationWeek=function(id,arr,varible,restoreVal,restoreFig){
      var reg=/[\u4e00-\u9fa5]/g;
	  var trueId='';
	  if(varible==1){
		  trueId=$('#'+id).closest('ul').find('.trigger').attr('id');
	  }else if(varible==2){
		  trueId=$(id).closest('ul').find('.trigger').attr('id');
	  }
	  
	  console.log(id+' '+arr)
	 
      //对比
      var dayVery=false;
      var weekVery=false;
      var seriesVery=false;
      $('#'+trueId).closest('ul').siblings('.courseUl2').each(function(){
    	 
			console.log($(this).find('.xqs').val()+' '+trueId+'  '+$('#'+trueId).siblings('.xqs').val())
         	if($(this).find('.xqs').val()==$('#'+trueId).siblings('.xqs').val()){//存在相同星期
         		//console.log("存在相同星期");
         		dayVery=true;
         		 $('#'+trueId).closest('ul').siblings('ul').each(function(){
         			 var ksjc1=$(this).find('.ksjc').val();
         			 var ksjc=$('#'+trueId).siblings('.ksjc').val();
         			 var jsjc1=$(this).find('.jsjc').val();
         			 var jsjc=$('#'+trueId).siblings('.jsjc').val();
         			// console.log(ksjc+"  "+jsjc+"=="+ksjc1+"  "+jsjc1);
         			if((ksjc<=ksjc1&&ksjc1<=jsjc)||(ksjc<=jsjc1&&jsjc1<=jsjc)){
         				// console.log("已存在相同节次");
         				seriesVery=true;
         				  var weeks=$('#'+trueId).closest('ul').find('.cherry').siblings('.dataKeep').val();
         			        weeks=weeks.replace(reg,'');
         			        weeks=weeks.split(',');
         			      //  console.log(weeks+'this is week i looking'+weeks[7]);
         			       $('#'+trueId).closest('ul').siblings('.courseUl2').each(function(){
         			        	 var weeks1=$(this).find('.cherry').siblings('.dataKeep').val();
         			        	 weeks1=weeks1.replace(reg,',');
         			        	 weeks1=","+weeks1;
         			        	// console.log(weeks1);
         			        	 for(var i=0;i<weeks.length;i++){
         			        		 if(weeks1.indexOf(","+weeks[i]+",")>-1){
         			        			// console.log('存在相同周》-1')
         			        			weekVery=true;
         			        		 }
         			        	 }
         			        	 
         			        	 
         			        })
         			 }
         			 
         		 
         		 });
         	
         		
         	}
         })
         
      
         if(dayVery&&seriesVery&&weekVery){
      	   swal('这个节次已经有课程了');
      	 
      	 if(varible==1){
			  $('#'+id).text(restoreFig);
			  $('#'+id).siblings('.dataKeep').val(restoreVal);
		  }else if(varible==2){
			  $(id).text(restoreFig);
			  $(id).siblings('.dataKeep').val(restoreVal);
		  }
      	 
      
      	   
      	  
         }
      
	  
   }  
    
    
   
   var duplicateSeries=function(data,id){
	   
	
	   
	  var reg=/[\u4e00-\u9fa5]/g;
	   $(id).siblings('.xqs').val(data[0]);
       $(id).siblings('.ksjc').val(data[1]);
       $(id).siblings('.jsjc').val(data[2].replace("节",""));
       //对比
       var dayVery=false;
       var weekVery=false;
       var seriesVery=false;
       
       $(id).closest('ul').siblings('.courseUl2').each(function(){
    	
		console.log($(this).find('.xqs').val()+'---'+$(id).siblings('.xqs').val())
       	if($(this).find('.xqs').val()==$(id).siblings('.xqs').val()){//存在相同星期
       		//console.log("存在相同星期");
       		
       		dayVery=true;
       		 $(id).closest('ul').siblings('.courseUl2').each(function(){
       			 var ksjc1=$(this).find('.ksjc').val();
       			 var ksjc=$(id).siblings('.ksjc').val();
       			 var jsjc1=$(this).find('.jsjc').val();
       			 var jsjc=$(id).siblings('.jsjc').val();
       			// console.log(ksjc+"  "+jsjc+"=="+ksjc1+"  "+jsjc1);
       			 /* if(ksjc<=jsjc1||jsjc<=ksjc1){ */
       			     console.log(ksjc1+' '+ksjc+' '+jsjc1+' '+jsjc);
       				 if((ksjc<=ksjc1&&ksjc1<=jsjc)||(ksjc<=jsjc1&&jsjc1<=jsjc)){
       				//	 console.log("已存在相同节次"+ksjc+'<='+ksjc1+'<='+jsjc+'||'+ksjc+'<= '+jsjc1+'<= '+jsjc);
       				
       				// console.log("已存在相同节次"+ksjc+'<='+jsjc1+'&&'+jsjc+'<='+ksjc1);
       				seriesVery=true;
       				  var weeks=$(id).closest('ul').find('.cherry').siblings('.dataKeep').val();
       				  console.log(weeks);
       			        weeks=weeks.replace('周','');
       			        weeks=weeks.split(',');
       			     //   console.log(weeks+'this is week i looking'+weeks[7]);
       			        
       			        
       			        
       			        $(id).closest('ul').siblings('.courseUl2').each(function(){
       			        	 var weeks1=$(this).find('.cherry').siblings('.dataKeep').val();
       			        	 console.log(weeks1)
       			        	 weeks1=weeks1.replace(reg,',');
       			        	 weeks1=","+weeks1;
       			        //	 console.log(weeks1);
       			        	 for(var i=0;i<weeks.length;i++){
       			        		 if(weeks1.indexOf(","+weeks[i]+",")>-1){
       			        	//		 console.log('存在相同周》-1')
       			        			weekVery=true;
       			        		 }
       			        	 }
       			        	 
       			        	 
       			        })
       			 }
       			 
       		 
       		 });
       	
       		
       	}
       })
      // console.log('星期：'+dayVery+' 节次： '+seriesVery+' 周数：'+weekVery+'*******************');
        console.log(dayVery+''+seriesVery+''+weekVery)
       if(dayVery&&seriesVery&&weekVery){
    	  
    	   swal('这个节次已经有课程了');
    	   $(id).text('');
    	   $(id).siblings('.xqs').val('');
	       $(id).siblings('.ksjc').val('');
	       $(id).siblings('.jsjc').val('');
       }
      
   }
  
  /*var duplicationWeek=function(id,arr,varible){
		 
	  var trueId='';
	  if(varible==1){
		  trueId=$('#'+id).closest('ul').find('.trigger').attr('id');
	  }else if(varible==2){
		  trueId=$(id).closest('ul').find('.trigger').attr('id');
	  }
	  
	  
	 
      //对比
      var dayVery=false;
      var weekVery=false;
      var seriesVery=false;
      $('#'+trueId).closest('ul').siblings('ul').each(function(){
    	 
		//	console.log($(this).find('.xqs').val()+' '+trueId+'  '+$('#'+trueId).siblings('.xqs').val())
         	if($(this).find('.xqs').val()==$('#'+trueId).siblings('.xqs').val()){//存在相同星期
         		//console.log("存在相同星期");
         		dayVery=true;
         		 $('#'+trueId).closest('ul').siblings('ul').each(function(){
         			 var ksjc1=$(this).find('.ksjc').val();
         			 var ksjc=$('#'+trueId).siblings('.ksjc').val();
         			 var jsjc1=$(this).find('.jsjc').val();
         			 var jsjc=$('#'+trueId).siblings('.jsjc').val();
         			// console.log(ksjc+"  "+jsjc+"=="+ksjc1+"  "+jsjc1);
         			if((ksjc<=ksjc1&&ksjc1<=jsjc)||(ksjc<=jsjc1&&jsjc1<=jsjc)){
         				// console.log("已存在相同节次");
         				seriesVery=true;
         				  var weeks=$('#'+trueId).closest('ul').find('.cherry').text();
         			        weeks=weeks.replace('周','');
         			        weeks=weeks.split(',');
         			      //  console.log(weeks+'this is week i looking'+weeks[7]);
         			       $('#'+trueId).closest('ul').siblings('ul').each(function(){
         			        	 var weeks1=$(this).find('.cherry').text();
         			        	 weeks1=weeks1.replace("周",',');
         			        	 weeks1=","+weeks1;
         			        	// console.log(weeks1);
         			        	 for(var i=0;i<weeks.length;i++){
         			        		 if(weeks1.indexOf(","+weeks[i]+",")>-1){
         			        			// console.log('存在相同周》-1')
         			        			weekVery=true;
         			        		 }
         			        	 }
         			        	 
         			        	 
         			        })
         			 }
         			 
         		 
         		 });
         	
         		
         	}
         })
         
       //  console.log('星期：'+dayVery+' 节次： '+seriesVery+' 周数：'+weekVery);
         if(dayVery&&seriesVery&&weekVery){
      	   alert('这个节次已经有课程了');
      	   $.MsgBox.Alert('温馨提示','我是你妈');
      	   $('#'+trueId).text('');
         }
      
	   
   } 
    
    
   
   var duplicateSeries=function(data,id){
	   
	  
	   $(id).siblings('.xqs').val(data[0]);
       $(id).siblings('.ksjc').val(data[1]);
       $(id).siblings('.jsjc').val(data[2].replace("节",""));
       //对比
       var dayVery=false;
       var weekVery=false;
       var seriesVery=false;
       
       $(id).closest('ul').siblings('ul').each(function(){
		
       	if($(this).find('.xqs').val()==$(id).siblings('.xqs').val()){//存在相同星期
       		//console.log("存在相同星期");
       		dayVery=true;
       		 $(id).closest('ul').siblings('ul').each(function(){
       			 var ksjc1=$(this).find('.ksjc').val();
       			 var ksjc=$(id).siblings('.ksjc').val();
       			 var jsjc1=$(this).find('.jsjc').val();
       			 var jsjc=$(id).siblings('.jsjc').val();
       			// console.log(ksjc+"  "+jsjc+"=="+ksjc1+"  "+jsjc1);
       			  if(ksjc<=jsjc1||jsjc<=ksjc1){ 
       				 if((ksjc<=ksjc1&&ksjc1<=jsjc)||(ksjc<=jsjc1&&jsjc1<=jsjc)){
       				//	 console.log("已存在相同节次"+ksjc+'<='+ksjc1+'<='+jsjc+'||'+ksjc+'<= '+jsjc1+'<= '+jsjc);
       				
       				// console.log("已存在相同节次"+ksjc+'<='+jsjc1+'&&'+jsjc+'<='+ksjc1);
       				seriesVery=true;
       				  var weeks=$(id).closest('ul').find('.cherry').text();
       			        weeks=weeks.replace('周','');
       			        weeks=weeks.split(',');
       			     //   console.log(weeks+'this is week i looking'+weeks[7]);
       			        $(id).closest('ul').siblings('ul').each(function(){
       			        	 var weeks1=$(this).find('.cherry').text();
       			        	 weeks1=weeks1.replace("周",',');
       			        	 weeks1=","+weeks1;
       			        //	 console.log(weeks1);
       			        	 for(var i=0;i<weeks.length;i++){
       			        		 if(weeks1.indexOf(","+weeks[i]+",")>-1){
       			        	//		 console.log('存在相同周》-1')
       			        			weekVery=true;
       			        		 }
       			        	 }
       			        	 
       			        	 
       			        })
       			 }
       			 
       		 
       		 });
       	
       		
       	}
       })
      // console.log('星期：'+dayVery+' 节次： '+seriesVery+' 周数：'+weekVery+'*******************');
       if(dayVery&&seriesVery&&weekVery){
    	   alert('这个节次已经有课程了');
    	   $.MsgBox.Alert('温馨提示','我是你妈');
    	   $(id).text('');
       }
      
   }*/