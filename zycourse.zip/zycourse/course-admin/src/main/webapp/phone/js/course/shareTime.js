	 var fid=localStorage.fid;
	 var uid=localStorage.uid;
	 var userId=localStorage.userId;
	 var userName=localStorage.userName;
	 var school=localStorage.school1;
	 var pic=localStorage.pic;
	 
	 
	 
	//设置日期格式
	 Date.prototype.Format = function (fmt) { 
 	    var o = {
 	        "M+": this.getMonth() + 1, //月份 
 	        "d+": this.getDate(), //日 
 	        "h+": this.getHours(), //小时 
 	        "m+": this.getMinutes(), //分 
 	        "s+": this.getSeconds(), //秒 
 	        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
 	        "S": this.getMilliseconds() //毫秒 
 	    };
 	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
 	    for (var k in o)
 	    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
 	    return fmt;
 	}
	 

$(function(){
	
	 $('#userName').val(userName);
	 var pic='http://photo.chaoxing.com/p/'+uid+'_80';
	 $('.shareName').text(userName);
	 $('.headIcon').attr('src',pic);
	/* var url=cutUrl()+"/api/course/getUserInfo";
	 var mes={"userId":userId};
	 
	 
		 $.ajax({
	         "dataType": 'json',
	         "type": "GET",
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	 var raw=JSON.stringify(data);
	        	 //console.log(raw);
	        	 raw=$.parseJSON(raw);
	         }
		 })*/
		 
	
	  
	 var url1=cutUrl()+"/api/course/queryCurrentXqInfo";
	 var mes1={"userId":userId};
    
		 $.ajax({
	         "dataType": 'json',
	         "type": "GET",
	         "url": url1,
	         "data": mes1,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	 var raw=JSON.stringify(data);
	        	
	        	 var host=window.location.host;
	        	 raw=$.parseJSON(raw);
	        	
	        	 var hostPath1=window.location.host;
	        	
	        	 var hostPath=window.location.pathname;
	        	
	        	 var userName1=localStorage.userName;
	        	
	        	 var school1=localStorage.school1;
	        	
	        	 userName1=encodeURIComponent(userName);
	        	
	     		 school1=encodeURIComponent(school);
	        	
	        	 
	        	 var content='http://'+host+'/zycourse/phone/html/scanCopy.html?userId='+userId+"&fid="+fid+"&uid="+uid+"&userName="+userName1+"&school="+school1;
	        	 //var content="http://"+hostPath1+"/"+cutUrl()+"/phone/html/forShare.html?userId="+userId;
	        	 //var content="http://"+hostPath1+"/"+cutUrl()+"/phone/html/barCode.html";
	        	 

	        	localStorage.c=content;
	        	
	        	
	        	
	        	 var qr = window.qr = new QRious({
	                 element: document.getElementById('qrious'),
	           
	                 value: content
	               })
	        	 
	        	 var date=new Date(raw.xnxqInfo.kxsj).Format('yyyy');
	        	 var rxny=new Date(raw.xnxqInfo.rxny).Format('yyyy');
	        	 var forshow=termCal(date,raw.xnxqInfo.rxny,raw.xnxqInfo.xq);
	        	
	        	 if(parseInt(date)-parseInt(rxny)>5){
	        		
	        		 $('#termInfo').val(raw.xnxqInfo.xn+' 第'+raw.xnxqInfo.xq+'学期');
	        	 }else{
	        		 $('#termInfo').val(forshow);
	        	 }
	        	 
	        	 
	        	
	        	
	        	 
	        	 
	        	 
	        	 
	        	 
	        	 $('.shareP').text(forshow);
	        	
	         }
		 }) 
	 
    
    $('.menu_l').click(function(){
    	window.location="term.html";
    })
    
    $('#addTime').click(function(){
    	sharing();
    	
    	
    	
    })
    
    
    $('.menu_r').click(function(){
    	sharing();
    	return;
    	
    })
    
    
	
    
 })
 
 		
 
	  var sharing=function(){
		var host=window.location.host;
		var title=$('#userName').val()+'的课表';
		var resUid=uid;
		
		userName=encodeURIComponent(userName);
		school=encodeURIComponent(school);
		var resContent=$('#termInfo').val();
		
		
		
		var iconUrl='http://'+host+'/zycourse/phone/image/rose.png';    	
		var activityUrl='http://'+host+'/zycourse/phone/html/forShare.html?userId='+userId+"&fid="+fid+"&uid="+uid+"&userName="+userName+"&school="+school;
	    var content = {
	        "resTitle": title,
	        "resUrl": activityUrl,
	        "resLogo":iconUrl,	      
	        "resUid": resUid,
	        "toolbarType": 2,
	        "showContent":1,
	        "resContent":resContent
	    };
	    if (resUid != null && resUid != '' && activityUrl != null && activityUrl != '') {
	        jsBridge.postNotification("CLIENT_TRANSFER_INFO", {"cataid": 100000015, "content": content});
	    }
	}
 
  
 

	//根据入学年月和当前时间判断学期
	var termCal=function(adyear,rgyear,series){
		
		adyear=parseInt(adyear);
		rgyear=parseInt(rgyear);
		var gap=adyear-rgyear;
		if(series==1){
			gap=gap+1;
		}
		console.log(gap)
		
		if(gap<1||gap>5){
			gap=10;
		}
		console.log(gap);
		
		var returnVal='';
		
		if(gap==10){
			returnVal='第'+series+'学期';
		}else{
			returnVal='大'+gap+' '+'第'+series+'学期';
		}
		
		gap=SectionToChinese(gap);
		series=SectionToChinese(series);
		
		
		
		
		
		return returnVal;
	}
    
  
    
    var classConvert=function(week){
		if(week=='第一节'){
			return 1;
		}else if(week=='第二节'){
			return 2;
		}else if(week=='第三节'){
			return 3;
		}else if(week=='第四节'){
			return 4;
		}else if(week=='第五节'){
			return 5;
		}else if(week=='第六节'){
			return 6;
		}else if(week=='第七节'){
			return 7;
		}else if(week=='第八节'){
			return 8;
		}else if(week=='第九节'){
			return 9;
		}else if(week=='第十节'){
			return 10;
		}else if(week=='第十一节'){
			return 11;
		}else if(week=='第十二节'){
			return 12;
		}else if(week=='第十三节'){
			return 13;
		}else if(week=='第十四节'){
			return 14;
		}else if(week=='第十五节'){
			return 15;
		}
	}
 
  //中文数字转阿拉伯数字
  	 var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
       var chnUnitSection = ["","万","亿","万亿","亿亿"];
       var chnUnitChar = ["","十","百","千"];

       function SectionToChinese(section){
           var strIns = '', chnStr = '';
           var unitPos = 0;
           var zero = true;
           while(section > 0){
               var v = section % 10;
               if(v === 0){
                   if(!zero){
                       zero = true;
                       chnStr = chnNumChar[v] + chnStr;
                   }
               }else{
                   zero = false;
                   strIns = chnNumChar[v];
                   strIns += chnUnitChar[unitPos];
                   chnStr = strIns + chnStr;
               }
               unitPos++;
               section = Math.floor(section / 10);
           }
           return chnStr;
       }
 