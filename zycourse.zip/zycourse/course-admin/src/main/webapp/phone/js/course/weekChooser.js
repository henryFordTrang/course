$(document).ready(function () {
        $(document).click(function (e) {
            $(".courseTimeList").slideUp();
            $(".setList").slideUp();
            e.stopPropagation();
        });
        $(".menu_r").click(function(e){
            $(this).next().slideToggle(500);
            e.stopPropagation();
        })
        $(".weekA").click(function(){
            $(".weekA").children(".weekP").removeClass("nowWeek");
            $(this).children(".weekP").addClass("nowWeek");
            $(".weekA").children(".nowWeekP").text("");
            $(this).children(".nowWeekP").text("当前周");
        })
    });
</script>
<script>
    $(".table").on("touchstart", function(e) {

　　　　//e.preventDefault();
　　　　startX = e.originalEvent.changedTouches[0].pageX,
　　　　startY = e.originalEvent.changedTouches[0].pageY;
　　});
　　$(".table").on("touchmove", function(e) {
　　　　//e.preventDefault();
　　　　moveEndX = e.originalEvent.changedTouches[0].pageX,
　　　　moveEndY = e.originalEvent.changedTouches[0].pageY,
　　　　X = moveEndX - startX,
　　　　Y = moveEndY - startY;
		if(Y>10||Y<-10){
			e.preventDefault();
		}
　　　　if ( Y > 10) {//下滑
　　　　　　$(".table").removeClass("swipedown");
            $(".dropdownDiv").removeClass("swipedown");
　　　　}
　　　　else if ( Y < -10 ) {//上滑
　　　　　　$(".table").addClass("swipedown");
            $(".dropdownDiv").addClass("swipedown");　
　　　　}
　　　});