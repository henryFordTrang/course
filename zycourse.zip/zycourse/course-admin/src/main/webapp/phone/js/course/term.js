var curWeek='';
var reg=/[\u4e00-\u9fa5]/g;
var clickCtrl=false;
var clickCtrol=false;

	function randomNum(minNum,maxNum){ 
    switch(arguments.length){ 
        case 1: 
            return parseInt(Math.random()*minNum+1,10); 
        break; 
        case 2: 
            return parseInt(Math.random()*(maxNum-minNum+1)+minNum,10); 
        break; 
            default: 
                return 0; 
            break; 
    } 
	} 

	function unique1(array){ 
		var n = []; //一个新的临时数组 
		//遍历当前数组 
		for(var i = 0; i < array.length; i++){ 
		//如果当前数组的第i已经保存进了临时数组，那么跳过， 
		//否则把当前项push到临时数组里面 
		if (n.indexOf(array[i]) == -1) n.push(array[i]); 
		} 
		return n; 
		}

	function compare(property){
	    return function(a,b){
	        var value1 = a[property];
	        var value2 = b[property];
	        return value1 - value2;
	    }
	}
	
	var sortting=function(timeSpan,ifAll){
		var resetArr=[];
     	var unitCheck='';
    	$.each(timeSpan,function(i,dom){
    		
    		var dating=new Date();
    		var rawspaning=dom.jckssj;
    		
    		if(rawspaning.replace(reg,'').length==0){
    			rawspaning='00:00';
    		}
    		rawspaning=rawspaning.split(':');
    		dating.setHours(rawspaning[0]);
    		dating.setMinutes(rawspaning[1]);
    		
    		var maturespan=Date.parse(dating);
    		
    		
    		unitCheck+='{'+'"'+'id'+'"'+':'+'"'+dom.id+'"'+','+'"'+'jcmc'+'"'+':'+'"'+dom.jcmc+'"'+','+'"'+'jcdm'+'"'+':'+'"'+dom.jcdm+'"'+','+'"'+'jckssj'+'"'+':'+'"'+maturespan+'"'+','+'"'+'jcjssj'+'"'+':'+'"'+dom.jcjssj+'"'+'}'+',';
    		
    		if(i<4){  			 
   			 resetArr.push(dom);    			 
   			 //console.log(dom);
   		     }else if(i==4){
    			 resetArr.push(timeSpan[timeSpan.length-1]);
    			 //console.log(timeSpan[timeSpan.length-1])
    		 }else{
    			 var reIndex=i-1;
    			 //console.log(timeSpan[reIndex])
    			 resetArr.push(timeSpan[reIndex])
    		 }
    		
    		
    	 })		
    	
    	unitCheck=unitCheck.substring(0,unitCheck.length-1);
    	unitCheck='['+unitCheck+']';   	
    	unitCheck=$.parseJSON(unitCheck);
    	
    	//集合按时间重新排序
    	unitCheck.sort(compare('jckssj'));    

    	
    	var feedback='';
    	
    	if(ifAll){
    		feedback=unitCheck;  //午休按时间排序
    	}else{
    		feedback=resetArr;  //午休固定在第四节后面
    	}
    	
    	//console.log(feedback)
    	
    	//return unitCheck;  
    	return feedback;	  
	}
	

 $(document).ready(function () {

	 concealing(); 
	 var fid=localStorage.fid;
	 var uid=localStorage.uid;
	 var userName=localStorage.userName;
	 var school=localStorage.school1;
	 var userId=localStorage.userId;	 
	 var ifNapping=false;
	 var weekshift='';
	 var currentD='';
	 var mes1="";	
	 var pass=$.cookie('accessing');
	 
	 
	 //判断是否是iphoneX
	 
	 if(isIphoneX()){
		 
		 $('#container').css('height','14.8rem');
	 }

	 //checkuser();
	 
	 if(uid==undefined||uid==''||userName==undefined||userName==''){
		 return;
	 }
	 
	 mes1={"uid":uid,"fid":fid,"username":userName,"schoolName":school};
	 
	 $.cookie('accessing','',{ expires: 0.0001 });
	 
	 //return;
	if(pass!=undefined&&pass!=uid&&pass!=''){
		
		 //$.cookie('accessing','',{ expires: 0.1 });
		 initialLoading(mes1,ifNapping,uid);
	 }else if(pass!=undefined&&pass==uid&&pass!=''){
		
		 passLoading(userId,ifNapping);
			 
	 }else{
			
			initialLoading(mes1,ifNapping,uid);
			
			 
		 }


        $(document).click(function (e) {
        	//$('.menu_r').children('img').toggleClass('swichturn');
        	if($('.menu_r').children('img').attr('class')=='swichturn'){
        		$('.menu_r').children('img').removeClass('swichturn');
        	}
            $(".courseTimeList").slideUp();
            $(".setList").slideUp();
            e.stopPropagation();
        });
        
        $('.menu_l').click(function(){
        	
        	$.cookie('accessing','',{ expires: -1 });
        	exit();
        })
        
       
        
        $(".menu_r").click(function(e){
        	//$(this).children('img').toggleClass('swichturn');
        	
            $(this).next().slideToggle(50);
            e.stopPropagation();
        })
        
        $('#scan').click(function(){
        	barcode();
        })
        
        $('#share').click(function(){
        	window.location="shareTime.html";
        	
        	
        })
        $('#create').click(function(){
        	window.location="addCourse.html";
        	
        })
        
        $('#setup').click(function(){
        	window.location="timeTableSetup.html";
        })
        
        $('#newterm').click(function(){
        	window.location="createTerm.html";
        })
        
        $('#newcourse').click(function(){
        	window.location="newCourse.html";
        })
        
        
       
        var ifvisible=false;
        var chooseCount=0;
        
        $('#choose').click(function(){
        	chooseCount++;

 			$(this).children('img').toggleClass('swithturn');
        	if($(this).children('img').attr('class').length==0){
        		 
        		  //console.log($('.currweekbg'));
        		  $('.currweekbg').removeClass('cur');
        		  $('.currweekbg').removeClass('currweekbg');
        		  $('.nowWeek').parents('li').addClass('cur');
        		  $('.nowWeek').parents('li').addClass('currweekbg');

        		  var realM=calculationDate(curWeek,curWeek);        		  
        		  var remedy='第'+curWeek+'周';
	        	  
        		
        		  $('#ofix1_tb_header').remove();
	        	  $('#ofix1_tb_left').remove();
	        	  $('#ofix1_tb_top_left').remove();
	        	  
	        	  $('.table').children('thead').children('tr').empty();
	        	  $('.table').children('thead').children('tr').append("<td class='firstTd' style='width: 1rem;'><p class='tdHeadP1'>日期</p><p class='tdHeadP2'>时间</p></td>"); 	        		
	        	  $('.table').children('tbody').empty();
	        	  

	        	  loading(userId,curWeek,realM,remedy);
        		  //window.location="term.html";
        	}
        	
        	
 			$('#mfyA').toggleClass('revealing');
  			$('#wrapper1').toggleClass('revealing');
  			$('#choosediv').toggleClass('revealing');

        })
        
        $('.seatCharts-seat').each(function(){
        	$(this).click(function(){
        		$('.seatCharts-seat').addClass('available').removeClass('selected');
        		$(this).addClass('selected');
        		
        	})
        })
        
         //.....
     	 var weekbegin=['第1周','第2周','第3周','第4周','第5周','第6周','第7周','第8周','第9周','第10周','第11周','第12周','第13周','第14周','第15周','第16周','第17周','第18周','第19周','第20周','第21周','第22周','第23周','第24周','第25周'];
      	 var mobileSelect3 = new MobileSelect({
      			
      		    trigger: '#mfyA',
      		    type:'beginwith',
      		    title: '设置当前周',
      		    wheels: [
      		                {data: weekbegin},
      	
      		            ],
      		    position:[2, 2, 2, 2, 2], 
      		    transitionEnd:function(indexArr, data){
      		    	$('.title').text('设置当前周为：'+data)
      		    },
      		    callback:function(indexArr, data){
      		    	
      		     
      		        var chooseW=data[0].replace(reg,'');      		        
      		       // currentWeek(userId,chooseW);
      		        currentWeek(userId,chooseW);
      		        $('.clearfix').empty();
      		        weekGenerate(chooseW);
      		       
      		        weekListener(userId);
      		       
      		      
      		    }
      		});
      	 //......
        
        
      	weekListener(userId);
      
      	
    });
 
 
 
 	//封装的方法
 	var passLoading=function(userId,ifNapping){
 		
 		$.ajax({
     		"dataType": 'json',
     		"type": "GET",
     		"async":false,
    		"url": cutUrl()+"/api/course/getUserCourseInfo",
     		"data": {"userId":userId},
     		"contentType":"application/json;charset=utf-8",
     		"success": function (data, textStatus, jqXHR){
     			var raw1=JSON.stringify(data);
     			//console.log(raw1)
     			$('#mfyA').addClass('concealing');
     			$('#wrapper1').addClass('concealing');
     			$('#choosediv').addClass('concealing');
				
     			raw1=$.parseJSON(raw1);
     			
     			if(raw1.error.id=='0000'){
     				
     				var schoolName=raw1.schoolName;
         			var department=raw1.department;
         			var getTerm=raw1.hasXq;
         			var clsList=raw1.hasCourse;
         			currentD=raw1.currentZs;
         			curWeek=raw1.currentZs;
         			
         			weekGenerate(currentD);
         			
         			if(schoolName!=null&&schoolName!=''&&department!=null&&department!=''){//有院校信息的情况下，判断是否有学期
     					if(getTerm==1){//已有学期的情况下，判断是否已有课程
     						
     						if(clsList==1){//有院校，学期，课程的情况，展示课程信息

		        	        	
		        	        	 var adyear=raw1.xn;
	     			        	 var rgyear=raw1.rxny;
	     			        	 var termseries=raw1.xq;
	     			        	 adyear=adyear.split('-');
	     			        	 adyear=adyear[0];
	     			        	 rgyear=rgyear.substring(0,4);
	     			        	 var opening=new Date(raw1.kxsj).Format('yyyy');
	     			        	 var gradeInfo=termCal(opening,rgyear,termseries,raw1.xn);
	     			        	 
	     			        	 $('.menuP').text(gradeInfo);
	     			        	 $('.courseUp').children('a').children('em').text('第'+currentD+'周');
	     			        	 
	     			        	 var weekStart=raw1.weekStart;
	     			        	 weekshift=raw1.weekStart;
	     			        	 
	     			        	if(weekStart>1){
	     			        		 weekStart=weekStart-1;
	     			        		 for(var w=0;w<7;w++){	        			 
	     				        		 weekStart++;
	     				        		 if(weekStart>7){
	     				        			 weekStart=weekStart-7;
	     				        		 }
	     				        		 var weekId='tdP'+weekStart;
	     				        		 
	     				        		 var cnws=SectionToChinese(weekStart);
	     				        		 if(cnws=='七'){
	     			        				 cnws='日';
	     			        			 }
	     				        		 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
	     				        	 }
	     			        	 }else{
	     			        		 for(var w=0;w<7;w++){
	     			        			 var weekId='tdP'+weekStart;
	     			        			 
	     			        			 var cnws=SectionToChinese(weekStart);
	     			        			 if(cnws=='七'){
	     			        				 cnws='日';
	     			        			 }
	     			        			 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
	     			        			 weekStart++;
	     			        		 }
	     			        		 
	     			        	 } 
	     			        	var max=raw1.jcMax;
	     			        	var max1=parseInt(max)-1;
	     			        	//var timeSpan=raw1.list;
	     			        	var timeSpan=[];
	     			        	$.each(raw1.list,function(i,dom){
	     			        		if(i>max1){
	     			        			return;
	     			        		}else{
	     			        			timeSpan.push(dom);
	     			        		}
	     			        		
	     			        	})

	     			        	
     							timeSpan.push(raw1.list[12])
     							
		        	        	   	 		        	        	
		        	        	 
		        	        	//查看是否有午休
		        	        	var checkNapIn=raw1.list[12].jckssj;
		        	        	
		        	        	checkNapIn=checkNapIn.replace(reg,'');
		        	        	var trueIndex=0;
		        	        	
	     			        	if(checkNapIn.length>0){
	     			        		var ifAll=true;
	     			        		$.each(timeSpan,function(i,dom){
	     			        			if(dom.jckssj.length==0){
	     			        				ifAll=false;
	     			        			}
	     			        		})
	     			        		
	     			        		 var resetArr=sortting(timeSpan,ifAll);
	     			        		
		        	        		 //in case 有午休
		        	        		 ifNapping=true;
		        	        		 
		        	        		 var indexing=0;
		        	        		 
		        	        		 $.each(resetArr,function(i,dom){
		        	        			 indexing++;
		        	        			
		        	        			 if(dom.jcdm==0){
		        	        				 trueIndex=indexing;
		        	        			 }
		        	        		 })
		        	        		 trueIndex=trueIndex-1;
		        	        		// console.log('有午休'+trueIndex)
		        	        		 
		        	        		 $.each(resetArr,function(i,dom){	
			        	        		//console.log(dom);
		        	        			
		        	        			
		        	        			 var series=dom.jcmc;
		        	        			 var reg=/[\u4e00-\u9fa5]/g;
		        	        			 series=classConvert(series);
		        	        			 var trmark='mark'+i;
		        	        			 
		        	        			 if(i<trueIndex){
		        	        				 if(i>=max){
				        	        			 return;
				        	        		 } 	
		        	        			 }else{
		        	        				 if(i>max){
				        	        			 return;
				        	        		 } 	
		        	        			 }
		        	        			
			        	        		  /*if(i>max){
			        	        			 return;
			        	        		 } 	*/
		        	        			 /*console.log(dom.jckssj);*/
		        	        			 
		        	        			 
		        	        			 var trulyStart='';
		        	        			 if(dom.jckssj.length>10){
		        	        				 trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
		        	        			 }else{
		        	        				 trulyStart=dom.jckssj
		        	        			 }
		        	        			 
		        	        			 
			        	        		 if(dom.jcdm==0){			        	        			 
			        	        			 //$('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'></p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
			        	        			 $('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'>"+trulyStart+"</p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
			        	        		 }else{
			        	        			 //$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'></p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
			        	        			 $('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
			        	        		 }
			        	        		 
			        	        		       	        		
		        	        	 }) 

		        	        		 
		        	        		 
		        	        	 }else{
		        	        		
		        	        		 //in case 没有午休
		        	        		 ifNapping=false;
		        	        		 //resetArr.remove(resetArr[0])	        	        		
		        	        		 $.each(timeSpan,function(i,dom){	
				        	        		
			        	        			 var series=dom.jcmc;
			        	        			 
			        	        			 series=classConvert(series);
			        	        			
			        	        			/* var reg=/[\u4e00-\u9fa5]/g;
			        	        			 series=series.replace(reg,'');*/
			        	        			 
			        	        			 var trmark='mark'+i;		        	        		
				        	        		  if(i>=max){
				        	        			 return;
				        	        		 } 	
				        	        		  
				        	        		
				        	        		 //var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
				        	        		 var trulyStart='';
			        	        			 if(dom.jckssj.length>10){
			        	        				 trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
			        	        			 }else{
			        	        				 trulyStart=dom.jckssj
			        	        			 }
			        	        			 
				        	        		$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
				        	        		// $('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'></p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
				        	        		 
				        	        		 
				        	        		       	        		
			        	        	 }) 

		        	        	 }
	     			        	
	     			        	
	     			        	var ofix1 = new oFixedTable('ofix1', document.getElementById('mytable'), {rows:1, cols:1});
	     			        	
	     			        	
		        	        	//课程数据展示
     							newLoading(userId,currentD,weekshift,ifNapping,trueIndex);
		        	        	
     							
     							
     						}else{//已有学期但是没课程的时候跳转到 nocourseTerm.html页面
     							window.location='noCourseTerm.html';
     						}
 
     						
     					}else if(getTerm==2){//还没学期的时候跳转到新建学期页面
     						
     						window.location='blankterm.html';
     					}
         				
     				}else{//院校信息不齐全，跳转到建立院校信息页面
     					window.location='index.html';
     				}
     				
     			}else{
     				window.location='index.html';
     				//alert(raw1.error.message);
     			}

     			
     		}
    		})
 	}
 	
 	
 
 	 var initialLoading=function(mes1,ifNapping,uid){
 		 
 		$.ajax({
	         "dataType": 'json',
	         "type": "GET",
	         "async":false,
	         "url": cutUrl()+"/api/auth/loginByChaoxing",
	         "data": mes1,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	 var raw=JSON.stringify(data);  
	        	 	
	        	 	 raw=$.parseJSON(raw);	        	 	
	            	 localStorage.userId=raw.userId;
	            	 var userId=raw.userId;
	            	 if(raw.first_login=="NO"){
	            		
	            		$.cookie('accessing',uid,{ expires: 0.1 });
	            		
	            		
	            		$.ajax({
	             		"dataType": 'json',
	             		"type": "GET",
	             		"async":false,
	            		"url": cutUrl()+"/api/course/getUserCourseInfo",
	             		"data": {"userId":raw.userId},
	             		"contentType":"application/json;charset=utf-8",
	             		"success": function (data, textStatus, jqXHR){
	             			var raw1=JSON.stringify(data);	
	             			
	             			$('#mfyA').addClass('concealing');
	             			$('#wrapper1').addClass('concealing');
	             			$('#choosediv').addClass('concealing');
	             			
	             			raw1=$.parseJSON(raw1);
	             			
	             			if(raw1.error.id=='0000'){
	             				
	             				var schoolName=raw1.schoolName;
	                 			var department=raw1.department;
	                 			var getTerm=raw1.hasXq;
	                 			var clsList=raw1.hasCourse;
	                 			currentD=raw1.currentZs;
	                 			curWeek=raw1.currentZs;	                 		
	                 			weekGenerate(currentD);
	                 			
	                 			
	                 			
	                 			if(schoolName!=null&&schoolName!=''&&department!=null&&department!=''){//有院校信息的情况下，判断是否有学期
	             					if(getTerm==1){//已有学期的情况下，判断是否已有课程
	             						
	             						if(clsList==1){//有院校，学期，课程的情况，展示课程信息

	        		        	        	
	        		        	        	 var adyear=raw1.xn;	        		        	        	 
	        	     			        	 var rgyear=raw1.rxny;
	        	     			        	 var termseries=raw1.xq;
	        	     			        	 adyear=adyear.split('-');
	        	     			        	 adyear=adyear[0];
	        	     			        	 rgyear=rgyear.substring(0,4);
	        	     			        	 var opening=new Date(raw1.kxsj).Format('yyyy');
	       	     			        	 	 var gradeInfo=termCal(opening,rgyear,termseries,raw1.xn);
	        	     			        	 //var gradeInfo=termCal(opening,rgyear,termseries);
	       	     			        	 	
	        	     			        	 $('.menuP').text(gradeInfo);
	        	     			        	 $('.courseUp').children('a').children('em').text('第'+currentD+'周');
	        	     			        	 var weekStart=raw1.weekStart;
	        	     			        	 weekshift=raw1.weekStart;
	        	     			        	 
	        	     			        	if(weekStart>1){
	        	     			        		 weekStart=weekStart-1;
	        	     			        		 for(var w=0;w<7;w++){	        			 
	        	     				        		 weekStart++;
	        	     				        		 if(weekStart>7){
	        	     				        			 weekStart=weekStart-7;
	        	     				        		 }
	        	     				        		 var weekId='tdP'+weekStart;
	        	     				        		 var cnws=SectionToChinese(weekStart);
	        	     				        		 if(cnws=='七'){
	        	     			        				 cnws='日';
	        	     			        			 }
	        	     				        		 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
	        	     				        	 }
	        	     			        	 }else{
	        	     			        		 for(var w=0;w<7;w++){
	        	     			        			 var weekId='tdP'+weekStart;
	        	     			        			 var cnws=SectionToChinese(weekStart);
	        	     			        			 if(cnws=='七'){
	        	     			        				 cnws='日';
	        	     			        			 }
	        	     			        			 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
	        	     			        			 weekStart++;
	        	     			        		 }
	        	     			        		 
	        	     			        	 } 
	        	     			        	var max=raw1.jcMax;
	        	     			        	//var timeSpan=raw1.list;    	
	        	     			        		        
	        	     			        	var max1=parseInt(max)-1;
	        	     			        	
	        	     			        	//var timeSpan=raw1.list;
	        	     			        	var timeSpan=[];
	        	     			        	$.each(raw1.list,function(i,dom){
	        	     			        		if(i>max1){
	        	     			        			return;
	        	     			        		}else{
	        	     			        			timeSpan.push(dom);
	        	     			        		}
	        	     			        		
	        	     			        	})
	        	     			        	timeSpan.push(raw1.list[12]);
	        		        	        	
	        		        	        	//resetArr=resetArr.slice(0,resetArr.length-1);	
	        		        	        	var checkNapIn=raw1.list[12].jckssj;
	        		        	        	//checkNapIn=checkNapIn.replace(reg,'');
	        		        	        	var trueIndex=0;
	        		        	        	
	        		        	        	
	        	     			        	if(checkNapIn.length>0){
	        		        	        		 //in case 有午休
	        	     			        		var ifAll=true;
	        	     			        		$.each(timeSpan,function(i,dom){
	        	     			        			if(dom.jckssj.length==0){
	        	     			        				ifAll=false;
	        	     			        			}
	        	     			        		})
	        	     			        		var resetArr=sortting(timeSpan,ifAll);

	        		        	        		 ifNapping=true;
	        		        	        		
	        		        	        		 $.each(resetArr,function(i,dom){	
	        			        	        		
	        		        	        			 
	        		        	        			
	        		        	        			 var series=dom.jcmc;
	        		        	        			 var reg=/[\u4e00-\u9fa5]/g;
	        		        	        			 series=classConvert(series);
	        		        	        			 var trmark='mark'+i;
	        		        	        			 
	        		        	        			 
	        		        	        			 var indexing=0;
	        			        	        		 
	        			        	        		 $.each(resetArr,function(i,dom){
	        			        	        			 indexing++;
	        			        	        			
	        			        	        			 if(dom.jcdm==0){
	        			        	        				 trueIndex=indexing;
	        			        	        			 }
	        			        	        		 })
	        			        	        		 
	        			        	        		 trueIndex=trueIndex-1;
	        			        	        		 
	        		        	        			 
	        		        	        			 if(i<trueIndex){
	    			        	        				 if(i>=max){
	        				        	        			 return;
	        				        	        		 } 	
	    			        	        			 }else{
	    			        	        				 if(i>max){
	        				        	        			 return;
	        				        	        		 } 	
	    			        	        			 }
	        		        	        			
	        			        	        		  /*if(i>max){
	        			        	        			 return;
	        			        	        		 }*/
	        		        	        			 
	        		        	        			 var trulyStart='';
	        		        	        			 if(dom.jckssj.length>10){
	        		        	        				 trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
	        		        	        			 }else{
	        		        	        				 trulyStart=dom.jckssj
	        		        	        			 }
	        		        	        			 
	        		        	        			 //var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
	        			        	        		
	        			        	        		 if(dom.jcdm==0){
	        			        	        			 
	        			        	        			 $('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'>"+trulyStart+"</p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
	        			        	        			 //$('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'></p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
	        			        	        		 }else{
	        			        	        			 $('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
	        			        	        			 //$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'></p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
	        			        	        		 }
	        			        	        		 
	        			        	        		       	        		
	        		        	        	 }) 

	        		        	        		 
	        		        	        		 
	        		        	        	 }else{
	        		        	        		 
	        		        	        		 //in case 没有午休
	        		        	        		ifNapping=false;
	        		        	        		 //resetArr.remove(resetArr[0])
	        		        	        		console.log(raw1.list);
	        		        	        		 $.each(raw1.list,function(i,dom){	
	        				        	        		
	        			        	        			 var series=dom.jcmc;
	        			        	        			 
	        			        	        			 series=classConvert(series);
	        			        	        			/* var reg=/[\u4e00-\u9fa5]/g;
	        			        	        			 series=series.replace(reg,'');*/
	        			        	        			 
	        			        	        			 var trmark='mark'+i;		        	        		
	        				        	        		  if(i>=max){
	        				        	        			 return;
	        				        	        		 } 
	        				        	        		  
	        				        	        		 var trulyStart='';
	 	        		        	        			 if(dom.jckssj.length>10){
	 	        		        	        				 trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
	 	        		        	        			 }else{
	 	        		        	        				 trulyStart=dom.jckssj
	 	        		        	        			 }
	        				        	        		  
	        				        	        		//var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
	        				        	        		$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
	        				        	        		//$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'></p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
	        				        	        		 
	        				        	        		 
	        				        	        		       	        		
	        			        	        	 }) 

	        		        	        	 }
	        	     			        	
	        	     			        	var ofix1 = new oFixedTable('ofix1', document.getElementById('mytable'), {rows:1, cols:1});
	        	     			        	
	        	     			        	
	        		        	        	//课程数据展示
	             							newLoading(userId,currentD,weekshift,ifNapping,trueIndex);
	        		        	        	
	             							
	             							
	             						}else{//已有学期但是没课程的时候跳转到 nocourseTerm.html页面
	             							window.location='noCourseTerm.html';
	             						}
	         
	             						
	             					}else if(getTerm==2){//还没学期的时候跳转到新建学期页面
	             						
	             						window.location='blankterm.html';
	             					}
	                 				
	             				}else{//院校信息不齐全，跳转到建立院校信息页面
	             					
	             						window.location='index.html';

	             				}
	                 			
	             			}else{
	             				//alert(raw1.error.message);
	             				$.MsgBox.Alert('温馨提示',raw1.error.message);
	             			}
	 
	             			
	             		}
	            		})
	     
	            	 }else{
	            		
	            		 classlengthInit(raw.userId);
	            	 }
	 
	            	 
	         }
		 })
 	 }
 	
 	
 	
 	
 		// 重置当前周
      var currentWeek=function(userId,currentZs){
    	 
    	  var url=cutUrl()+"/api/kbsz/settingCurrentZs";
 		  var mes={"userId":userId,"currentZs":currentZs};
    	  $.ajax({
				  "dataType": 'json',
				  "type": "GET",
				  "url": url,
				  "data": mes,
				  "contentType":"application/json;charset=utf-8",
				  "success": function (data, textStatus, jqXHR){
					  var raw=JSON.stringify(data);
					 
					  raw=$.parseJSON(raw);
					  if(raw.error.id=='0000'){
						  /*$('.table').children('thead').children('tr').empty();
			        	  $('.table').children('thead').children('tr').append("<td class='firstTd' style='width: 1rem;'><p class='tdHeadP1'>日期</p><p class='tdHeadP2'>时间</p></td>");			        		
			        	  $('.table').children('tbody').empty();*/
			        	 window.location='term.html';
						
						 /*curLoading(userId,currentZs);*/
					  }else{
						  //alert(raw.error.message);
						  $.MsgBox.Alert('温馨提示',raw.error.message);
					  }
					  
				  }
    	  })
    	  
      }
      
      //生成表头
      var weekGenerate=function(series){
    	  
    	  
    	  
    	  
    	  var headtr=0; 
    	  for(var t=1;t<27;t++){  
    		  headtr++;
    		  var trang='trang'+headtr;
    	  		if(series==t){
    	  			$('.clearfix').append("<li class='currweekbg'><a href='javascript:;' class='weekA'><p class='weekP nowWeek'>第"+t+"周</p><table class='narrowTab' id="+trang+"><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table><p class='nowWeekP'>当前周</p></a></li>");
    	  		}else{
    	  			$('.clearfix').append("<li><a href='javascript:;' class='weekA'><p class='weekP'>第"+t+"周</p><table class='narrowTab' id="+trang+"><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table><p class='nowWeekP'></p></a></li>");
    	  		}
    			
    		}
    	  
    	  if(isIphonePlus()){
    		  
    		  $('.narrowTab').find('td').css('border','solid 0.7px white')
    		  
    	  }
    	  $('.wrapper').navbarscroll();
    	 
    	  
      }
   
      
      //....initial Checkup
      //节次时间初始化
      var classlengthInit=function(userId){
    		 var url=cutUrl()+"/api/course/initJcsj";
    		 var set=[];
    		 var chinese=['一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五'];
    		 //var starttime=['8:00','9:00','10:00','11:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00'];
    		 var starttime=['8:00','9:00','10:00','11:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00'];
    		 var endtime=['8:45','9:45','10:45','11:45','14:45','15:45','16:45','17:45','18:45','19:45','20:45','21:45','22:45','23:45'];
    		 
    		 //初始化节次及其课时
    		 /*for(var i=0;i<12;i++){
    			 var j=i+1;
    			 var chineseSeries='第'+chinese[i]+'节';
    			 var unit='{"id":"","jcdm":"'+j+'","jcmc":"'+chineseSeries+'","jckssj":"'+starttime[i]+'","jcjssj":"'+endtime[i]+'","userId":"'+userId+'"}';
    			 set.push(unit);
    		 }*/
    		 //初始化节次,不含相应的课时
    		 for(var i=0;i<12;i++){
    			 var j=i+1;
    			 var chineseSeries='第'+chinese[i]+'节';
    			 var unit='{"id":"","jcdm":"'+j+'","jcmc":"'+chineseSeries+'","jckssj":"","jcjssj":"","userId":"'+userId+'"}';
    			 set.push(unit);
    		 }
    		 
    		 //var nap='{"id":"","jcdm":"0","jcmc":"午休","jckssj":"不休息","jcjssj":"不休息","userId":"'+userId+'"}';
    		 var nap='{"id":"","jcdm":"0","jcmc":"午休","jckssj":"","jcjssj":"","userId":"'+userId+'"}';
    		 set.push(nap);
    		 set='['+set+']';
    		 var mes='{"kcJcsjEntityList":'+set+'}';
    			 $.ajax({
    		         "dataType": 'json',
    		         "type": "POST",
    		         "url": url,
    		         "data": mes,
    		         "contentType":"application/json;charset=utf-8",
    		         "success": function (data, textStatus, jqXHR){
    		        
    		        	 var fid=localStorage.fid;
    		        	 if(fid==0){
    		        		 window.location='index.html';
    		        	 }else{
    		        		 window.location="term.html";
    		        	 }
    		        	
    		         }
    			 })
    		 
    	}

    
     			        	        	 
 
 		//星期添加监听
 		var weekListener=function(userId){
 			
 			
 			$('.narrowTab').each(function(){
 				
 	        	$(this).click(function(){
 	        		
 	        		
 	        		var week=$(this).siblings('.weekP ').text();
 	        		
 	        		
 	        		$('#ofix1_tb_header').remove();
 	        		$('#ofix1_tb_left').remove();
 	        		$('#ofix1_tb_top_left').remove();
 	        		
 	        		if(clickCtrl){
 	        			return;
 	        		}
 	        		clickCtrl=true;
 	        		
 	        		$('.narrowTab').children('tbody').children('tr').children('td').css('background','#ECEEF5');
 	        		var fetchweek=$(this).siblings('.weekP').text();
 	        		
 	        		var reg=/[\u4e00-\u9fa5]/g;
 	        		fetchweek=fetchweek.replace(reg,'');
 	        		
 	        		
 	        		$('.table').children('thead').children('tr').empty();
 	        		$('.table').children('thead').children('tr').append("<td class='firstTd' style='width: 1rem;'><p class='tdHeadP1'>日期</p><p class='tdHeadP2'>时间</p></td>"); 	        		
 	        		$('.table').children('tbody').empty();
 	        		var realM=calculationDate(curWeek,fetchweek);
 	        		
 	        		loading(userId,fetchweek,realM,week);
 	        		
 	        		$('.currweekbg').removeClass('currweekbg');
 	        		$(this).parents('li').removeClass('weekbg').addClass('currweekbg');
 	        		
 	        		
 	        	})
 	        	
 	       
 	        })
 		}
 		

 		
 		var termCal=function(adyear,rgyear,series,fuladyear){
 			
 			adyear=parseInt(adyear);
 			rgyear=parseInt(rgyear);
 			
 			
 			var gap=adyear-rgyear;
 			if(series==1){
 				gap=gap+1;
 			}
 			
 			//console.log(gap);
 			var feedback='';
 			if(gap<1||gap>5){
 				feedback=fuladyear+' 第'+series+'学期';
 			}else{
 				
 				gap=SectionToChinese(gap);
 	 			series=SectionToChinese(series);
 	 			feedback='大'+gap+' '+'第'+series+'学期';
 			}
 			
 			
 			
 			
 			
 			
 			
 			return feedback;
 		}
 		
 		
 		
 	
 	   
 	   //扫码 复制课表信息
 		try{
    		jsBridge.bind('CLIENT_BARCODE_SCANNER', function(object){
    			var version=isIos();
    			
    			
  				var para=object.message;
  				
    			para=para.split('=');
    			
    			para=para[1];
    			para=para.split('&');
    			para=para[0];
    			
    			if(!version){
    				
    				var cfm=confirm('是否复制课表');
    				
    				if(!cfm){
    					
    					return;
    				}
    			}
    			
    			
    				var userId=localStorage.userId;
    				var uid=localStorage.uid;
    				var fid=localStorage.fid;
    				var schoolName=localStorage.school1;
    				var username=localStorage.userName;
    				
    				//var copymes='{"userId":"'+userId+'","uid":"'+uid+'","fid":"'+fid+'","schoolName":"'+schoolName+'","username":"'+username+'","copyObjectUserId":"'+para+'"}';
    				//var copymes='{"uid":"'+uid+'","fid":"'+fid+'","schoolName":"'+schoolName+'","username":"'+username+'","copyObjectUserId":"'+para+'"}';
    				var copymes='{"uid":"'+uid+'","fid":"'+fid+'","copyObjectUserId":"'+para+'"}';
    				$.ajax({
    			         "dataType": 'json',
    			         "type": "POST",
    			         "async":false,
    			         "url": cutUrl()+"/api/course/copyCourseInfo",
    			         "data": copymes,
    			         "contentType":"application/json;charset=utf-8",
    			         "success": function (data, textStatus, jqXHR){
    			        	
    			        	 var raw=JSON.stringify(data);
    			        	
    			        	 //var currentWeek=localStorage.currentWeek;    			        	 
    			        	 raw=$.parseJSON(raw);
    			        	 
    			        	 
    			        	 if(raw.error.id=='0000'){
    			        		
    			         		window.location="term.html";
    			        		//loading(userId,curWeek,monday);
    			        		// weekGenerate(curWeek);
    			        		 
    			        	 }
    			        	 
    			        	 
    			         }
    				 })
    				
    			
    		});  
    	}catch(e){}

    	function barcode(){
    		
    		jsBridge.postNotification('CLIENT_BARCODE_SCANNER', {}) ;
    	}
    	
    	
    	//设置日期格式
    	 Date.prototype.Format = function (fmt) { 
     	    var o = {
     	        "M+": this.getMonth() + 1, //月份 
     	        "d+": this.getDate(), //日 
     	        "h+": this.getHours(), //小时 
     	        "m+": this.getMinutes(), //分 
     	        "s+": this.getSeconds(), //秒 
     	        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
     	        "S": this.getMilliseconds() //毫秒 
     	    };
     	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
     	    for (var k in o)
     	    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
     	    return fmt;
     	}
 		
    	
    	
    	//中文数字转阿拉伯数字
    	 var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
         var chnUnitSection = ["","万","亿","万亿","亿亿"];
         var chnUnitChar = ["","十","百","千"];

         function SectionToChinese(section){
             var strIns = '', chnStr = '';
             var unitPos = 0;
             var zero = true;
             while(section > 0){
                 var v = section % 10;
                 if(v === 0){
                     if(!zero){
                         zero = true;
                         chnStr = chnNumChar[v] + chnStr;
                     }
                 }else{
                     zero = false;
                     strIns = chnNumChar[v];
                     strIns += chnUnitChar[unitPos];
                     chnStr = strIns + chnStr;
                 }
                 unitPos++;
                 section = Math.floor(section / 10);
             }
             return chnStr;
         }
         
         
        	 Array.prototype.indexOf = function (val) {
        		    for (var i = 0; i < this.length; i++) {
        		        if (this[i] == val) return i;
        		    }
        		    return -1;
        		};

        		Array.prototype.remove = function (val) {
        		    var index = this.indexOf(val);
        		    if (index > -1) {
        		        this.splice(index, 1);
        		    }
        		};
        
        		
        		
 				//中文周 转阿拉伯文周
        		var interpret=function(week){
        			if(week=='周一'){
        				return 1;
        			}else if(week=='周二'){
        				return 2;
        			}else if(week=='周三'){
        				return 3;
        			}else if(week=='周四'){
        				return 4;
        			}else if(week=='周五'){
        				return 5;
        			}else if(week=='周六'){
        				return 6;
        			}else if(week=='周日'||week=='周天'){
        				return 7;
        			}
        		}
        		
 				//中文节次转阿拉伯数字节次
        		var classConvert=function(week){
        			if(week=='第一节'){
        				return 1;
        			}else if(week=='第二节'){
        				return 2;
        			}else if(week=='第三节'){
        				return 3;
        			}else if(week=='第四节'){
        				return 4;
        			}else if(week=='第五节'){
        				return 5;
        			}else if(week=='第六节'){
        				return 6;
        			}else if(week=='第七节'){
        				return 7;
        			}else if(week=='第八节'){
        				return 8;
        			}else if(week=='第九节'){
        				return 9;
        			}else if(week=='第十节'){
        				return 10;
        			}else if(week=='第十一节'){
        				return 11;
        			}else if(week=='第十二节'){
        				return 12;
        			}else if(week=='第十三节'){
        				return 13;
        			}else if(week=='第十四节'){
        				return 14;
        			}else if(week=='第十五节'){
        				return 15;
        			}else if(week=='午休'){
        				return '午休';
        			}
        		}
 				
 				
 				//日期计算
 				
 				var calculationDate=function(orgCur,updateCur){
 					//console.log('当前：'+orgCur+' ---Trang---'+'选取：'+updateCur);
 					var monday=getMonday();
 					var x=orgCur-updateCur;
 					//console.log(x);
 					//console.log('check the value of monday:'+monday);
 					var orgMondayMil=Date.parse(monday);
 					var gapMil=(updateCur-orgCur)*7*86400000;
 					var realMondayMil=orgMondayMil+gapMil;
 					var realMonday=new Date(realMondayMil).Format('yyyy-MM-dd');
 					//console.log(realMonday+'   更新');
 					//localStorage.realMonday=realMonday;
 					return realMonday;
 				}
 				
 				
 				//获取星期一日期
 				
 				var getMonday=function(){
 					var date=new Date();
					var weekDate=new Date().getDay();
					
					var weekGap=weekDate-1;
					
					date=date.Format('yyyy-MM-dd');
					var milvalue=Date.parse(date);
					var mondayMil=milvalue-weekGap*86400000;
					
					var x=new Date(milvalue).Format('yyyy-MM-dd');
					var y=new Date(mondayMil).Format('yyyy-MM-dd');
					
					
					return y;
					
 				}
 				
 				
 				
 				//根据星期一计算星期天日期
 				
 				var calculateSun=function(monday){
 					var rawMonday=Date.parse(monday);
					var milSun=rawMonday+86400000*6;
					var y=new Date(milSun).Format('yyyy-MM-dd');
					return y;
					
 				}
 				
 				//根据星期一计算上一个星期天日期
 				
 				var calculatePriorSun=function(monday){
 					
 					var rawMonday=Date.parse(monday);
					var milSun=rawMonday-86400000;
					var y=new Date(milSun).Format('yyyy-MM-dd');
					return y;
					
 				}
 				
 				
 				
 				
 				//获取星期天日期
 				
 				var getSunday=function(){
 					var date=new Date();
					var weekDate=new Date().getDay();
					
					var weekGap=7-weekDate;
					
					date=date.Format('yyyy-MM-dd');
					var milvalue=Date.parse(date);
					var mondayMil=milvalue+weekGap*86400000;
					
					var x=new Date(milvalue).Format('yyyy-MM-dd');
					var y=new Date(mondayMil).Format('yyyy-MM-dd');
					
					
					return y;
					
 				}
 				
 				//获取上周天日期
 				
 				var getPriorSun=function(){
 					var date=new Date();
					var weekDate=new Date().getDay();
					
					var weekGap=7-weekDate;
					
					date=date.Format('yyyy-MM-dd');
					var milvalue=Date.parse(date);
					var mondayMil=milvalue+weekGap*86400000;
					mondayMil=mondayMil-86400000*7;
					var x=new Date(milvalue).Format('yyyy-MM-dd');
					var y=new Date(mondayMil).Format('yyyy-MM-dd');
					
					
					return y;
					
 				}
 				
 				
 				
 				
 				
 				// 标志当前时间
 				var markCur=function(){
 					var liveDate=new Date().getDay();
					  if(liveDate==1){
						  textColor('#tdP1');
					  }else if(liveDate==2){
						  textColor('#tdP2');
					  }else if(liveDate==3){
						  textColor('#tdP3');
					  }else if(liveDate==4){
						  textColor('#tdP4');
					  }else if(liveDate==5){
						  textColor('#tdP5');
					  }else if(liveDate==6){
						  textColor('#tdP6');
					  }else if(liveDate==0){
						  textColor('#tdP7');
					  }
 				}
 				
 				//文本变色
 				var textColor=function(id){
 					$(id).css('color','#ff7886');
 					
 					$(id).siblings('em').css('color','#ff7886');
 					//$(id).parent('td').css('border-top','solid 0.07rem #ff7886');
 					var url="url('../image/topmarker.png')"
 					//$(id).parent('td').css('background-image',url);
 					//$(id).parent('td').css('background-size','cover');
 					
 					//$(id).parent('td').addClass('cur::before');
 					//$(id).parents('tr').append("<hr style='border-top:solid 0.07rem red'>");
 					
 					//$(id).parent('td').prepend("<hr>");
 					//$(id).siblings('hr').css('width','100%')
 					//$(id).siblings('hr').css('border-top','solid 0.07rem #ff7886');
 				}
 				
 				
        		
        		//页面加载
        		var loading=function(userId,zc,monday1,weekshow){
        			  $('#ofix1_tb_header').remove();
	   	        	  $('#ofix1_tb_left').remove();
	   	        	  $('#ofix1_tb_top_left').remove();
	   	        	  $('.table').children('thead').children('tr').empty();
		        	  $('.table').children('thead').children('tr').append("<td class='firstTd' style='width: .9rem;'><p class='tdHeadP1'>日期</p><p class='tdHeadP2'>时间</p></td>"); 	        		
		        	  $('.table').children('tbody').empty();
        			   
        			   var paraurl=cutUrl()+"/api/course/qryKbSettingsInfo";
        			   var parames='{"userId":"'+userId+'"}';

        		  	   var spanurl=cutUrl()+"/api/kbsz/qryJcTime";
        		   	   var spanmes='{"userId":"'+userId+'"}';
        		   	   
        		   	   var url=cutUrl()+"/api/course/qryCourseList";
					   var mes='{"userId":"'+userId+'","zc":"'+zc+'"}';
        			   
        				 $.ajax({
        			         "dataType": 'json',
        			         "type": "POST",
        			         "url": paraurl,
        			         "data": parames,
        			         "contentType":"application/json;charset=utf-8",
        			         "success": function (data, textStatus, jqXHR){
        			        	 var raw=JSON.stringify(data);
        			        	 //console.log(raw);
        			        	
        			        	 raw=$.parseJSON(raw);
        			        	 var adyear=raw.kbSettingsInfo.xn;
        			        	 var rgyear=raw.kbSettingsInfo.rxny;
        			        	 var termseries=raw.kbSettingsInfo.xq;
        			        	 var currentW=raw.kbSettingsInfo.dqzs;
        			        	 curWeek=raw.kbSettingsInfo.dqzs;
        			        	
        			        	 adyear=adyear.split('-');
        			        	 adyear=adyear[0];
        			        	 rgyear=rgyear.substring(0,4);
        			        	 var opening=new Date(raw.kbSettingsInfo.kxsj).Format('yyyy');
        			        	 var gradeInfo=termCal(opening,rgyear,termseries,raw.kbSettingsInfo.xn);
        			        	 
        			        	 //$('.courseUp').children('a').children('em').text('第'+raw.kbSettingsInfo.dqzs+'周');
        			        	 var inheriWeek=weekshow.replace(reg,'');
        			        	 
        			        	 
        			        
        			        	 
        			        	 if(inheriWeek!=raw.kbSettingsInfo.dqzs){
        			        		 $('.courseUp').children('a').children('em').text(weekshow);
            			        	 $('.courseUp').children('a').children('p').text('● 返回当前周');
        			        		 $('#choose').children('p').addClass('nowWeek');
        			        		 $('#choose').children('em').addClass('nowWeek');
        			        	 }else{
        			        		 $('.menuP').text(gradeInfo);
        			        		 $('.courseUp').children('a').children('em').text('第'+raw.kbSettingsInfo.dqzs+'周');
        			        		 $('#choose').children('p').removeClass('nowWeek');
        			        		 $('#choose').children('em').removeClass('nowWeek');
        			        	 }
        			        	 
        			        	 var weekStart=raw.kbSettingsInfo.weekStart;
        			        	 var weekshift=raw.kbSettingsInfo.weekStart;
        			        	 var weekshift1=raw.kbSettingsInfo.weekStart;
        			        	 if(weekStart>1){
        			        		 weekStart=weekStart-1;
        			        		 for(var w=0;w<7;w++){	        			 
        				        		 weekStart++;
        				        		 if(weekStart>7){
        				        			 weekStart=weekStart-7;
        				        		 }
        				        		 var weekId='tdP'+weekStart;
        				        		 var cnws=SectionToChinese(weekStart);
        				        		 if(cnws=='七'){
        			        				 cnws='日';
        			        			 }
        				        		 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
        				        	 }
        			        	 }else{
        			        		 for(var w=0;w<7;w++){
        			        			 var weekId='tdP'+weekStart;
        			        			 var cnws=SectionToChinese(weekStart);
        			        			 if(cnws=='七'){
        			        				 cnws='日';
        			        			 }
        			        			 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
        			        			 weekStart++;
        			        		 }
        			        		 
        			        	 }
        			        	 
        			        	
        			        	 var max=raw.kbSettingsInfo.jcMax;
        			        	 var ifNapping=false;
        			     	
        			        		 $.ajax({
        			        	         "dataType": 'json',
        			        	         "type": "POST",
        			        	         "url": spanurl,
        			        	         "data": spanmes,
        			        	         "contentType":"application/json;charset=utf-8",
        			        	         "success": function (data, textStatus, jqXHR){
        			        	        	 var raw1=JSON.stringify(data);
        			        	        	
        			        	        	 raw1=$.parseJSON(raw1);
        			        	        	 var resetList=raw1.list;
        			        	        	 var resetArr=[];
        			        	        	 
        			        	        	 var max1=parseInt(max)-1;
 	        	     			        	
 	        	     			        	//var timeSpan=raw1.list;
 	        	     			        	var timeSpan=[];
 	        	     			        	$.each(raw1.list,function(i,dom){
 	        	     			        		if(i>max1){
 	        	     			        			return;
 	        	     			        		}else{
 	        	     			        			timeSpan.push(dom);
 	        	     			        		}
 	        	     			        		
 	        	     			        	})
 	        	     			        	timeSpan.push(raw1.list[12]);
        			        	        	 
        			        	        	 var checkNapIn=raw1.list[12].jckssj;
        				        	         //checkNapIn=checkNapIn.replace(reg,'');
        			        	        	 //console.log(raw1.list[15].jckssj+' '+raw1.list[15].jckssj.length);
        				        	         var trueIndex=0;
        			        	        	 if(checkNapIn.length>0){
        			        	        		 
        			        	        		var ifAll=true;
 	        	     			        		$.each(timeSpan,function(i,dom){
 	        	     			        			if(dom.jckssj.length==0){
 	        	     			        				ifAll=false;
 	        	     			        			}
 	        	     			        		})
        			        	        		 resetArr=sortting(timeSpan,ifAll);
        			        	        		 //in case 有午休
        			        	        		 
        			        	        		 var indexing=0;
	        			        	        		 
	        			        	        		 $.each(resetArr,function(i,dom){
	        			        	        			 indexing++;
	        			        	        			
	        			        	        			 if(dom.jcdm==0){
	        			        	        				 trueIndex=indexing;
	        			        	        			 }
	        			        	        		 })
	        			        	        		 
	        			        	        		 
	        			        	        	 trueIndex=trueIndex-1; 
        			        	        		 ifNapping=true;
        			        	        		 
        			        	        		 $.each(resetArr,function(i,dom){	
        				        	        		//console.log(dom);
        			        	        			 var series=dom.jcmc;
        			        	        			 var reg=/[\u4e00-\u9fa5]/g;
        			        	        			 series=classConvert(series);
        			        	        			 var trmark='mark'+i;
        			        	        			 
        			        	        			 if(i<trueIndex){
        			        	        				 if(i>=max){
            				        	        			 return;
            				        	        		 } 	
        			        	        			 }else{
        			        	        				 if(i>max){
            				        	        			 return;
            				        	        		 } 	
        			        	        			 }
        			        	        			
        			        	        			 //var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
        			        	        			 var trulyStart='';
	        		        	        			 if(dom.jckssj.length>10){
	        		        	        				 trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
	        		        	        			 }else{
	        		        	        				 trulyStart=dom.jckssj
	        		        	        			 }
        				        	        		
        				        	        		 if(dom.jcdm==0){
        				        	        			 //$('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'></p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
        				        	        			 $('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'>"+trulyStart+"</p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
        				        	        		 }else{
        				        	        			 //$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'></p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
        				        	        			 $('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
        				        	        			 
        				        	        		 }
        				        	        		 
        				        	        		       	        		
        			        	        	 }) 

        			        	        		 
        			        	        		 
        			        	        	 }else{
        			        	        		 //in case 没有午休
        			        	        		
        			        	        		ifNapping=false;
        			        	        		 //resetArr.remove(resetArr[0])	        	        		
        			        	        		 $.each(timeSpan,function(i,dom){	
        					        	        		
        				        	        			 var series=dom.jcmc;
        				        	        			 var reg=/[\u4e00-\u9fa5]/g;
        				        	        			 series=classConvert(series);
        				        	        			
        				        	        			 //series=series.replace(reg,'');
        				        	        			 var trmark='mark'+i;		        	        		
        					        	        		  if(i>=max){
        					        	        			 return;
        					        	        		 } 	
        					        	        		  
        					        	        		 //var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
        					        	        		 var trulyStart='';
    	        		        	        			 if(dom.jckssj.length>10){
    	        		        	        				 trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
    	        		        	        			 }else{
    	        		        	        				 trulyStart=dom.jckssj
    	        		        	        			 }
        					        	        		$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
        					        	        		 //$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'></p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
        					        	        		 
        					        	        		 
        					        	        		       	        		
        				        	        	 }) 

        			        	        	 }

        			        	        	 var ofix1 = new oFixedTable('ofix1', document.getElementById('mytable'), {rows:1, cols:1});
        			        	        	 //....
        			        	        	 
        			        	        	 $.ajax({
        		         					  "dataType": 'json',
        		         					  "type": "POST",
        		         					  "url": url,
        		         					  "data": mes,
        		         					  "contentType":"application/json;charset=utf-8",
        		         					  "success": function (data, textStatus, jqXHR){
        		         						 //$('.table').children('tbody').children('tr').eq(0).children('td').eq(3).css('background-color','yellow');
        		         						  var raw2=JSON.stringify(data);
        		         						  //console.log(raw2)
        		         						  clickCtrl=false;
        		         						  raw2=$.parseJSON(raw2);
        		         						  weekshift1=parseInt(weekshift1);       		         						  
        		         						  milm=Date.parse(monday1);
        		         						  var sunday=calculateSun(monday1);
        		         						 
       	    								      var priorSun=calculatePriorSun(monday1);
       	    								      var sunMil=Date.parse(sunday);
       	    								      var priorMil=Date.parse(priorSun);

        		         						  
        		         						  var monday=''
        		         						  var tuesday='';
        		         						  var wenesday='';
        		         						  var thirsday='';
        		         						  var friday='';
        		         						  var saturday='';
        		         						  var sunday='';
        		         						 
        	    								  
        		         						 
        	    								  
	       		         						 if(weekshift1==1){
	       		         							 monday=milm;
	       		         							 tuesday=milm+86400000*1;
	       		         						     wenesday=milm+86400000*2;
	       		         						     thirsday=milm+86400000*3;
	       		         						     friday=milm+86400000*4;
	       		         						     saturday=milm+86400000*5;
	       		         						     sunday=milm+86400000*6;
	  	    								    	  
	  	    								      }else if(weekshift1==2){
	  	    								    	
	       		         							 tuesday=sunMil-86400000*5;
	       		         						     wenesday=sunMil-86400000*4;
	       		         						     thirsday=sunMil-86400000*3;
	       		         						     friday=sunMil-86400000*2;
	       		         						     saturday=sunMil-86400000*1;
	       		         						     sunday=sunMil;
	       		         						     monday=sunMil+86400000*1;
	  	    								    	  
	  	    								      }else if(weekshift1==3){
	  	    								    	 
	       		         						     wenesday=sunMil-86400000*4;
	       		         						     thirsday=sunMil-86400000*3;
	       		         						     friday=sunMil-86400000*2;
	       		         						     saturday=sunMil-86400000*1;
	       		         						     sunday=sunMil;
	       		         						     monday=sunMil+86400000*1;
	       		         						     tuesday=sunMil+86400000*2;
	  	    								    	  
	  	    								      }else if(weekshift1==4){
	  	    								    	
	       		         						     thirsday=sunMil-86400000*3;
	       		         						     friday=sunMil-86400000*2;
	       		         						     saturday=sunMil-86400000*1;
	       		         						     sunday=sunMil;
	       		         						     monday=sunMil+86400000*1;
	       		         						     tuesday=sunMil+86400000*2;
	       		         						     wenesday=sunMil+86400000*3;
	  	    								    	  
	  	    								      }else if(weekshift1==5){
	  	    								    	
	       		         						     friday=sunMil-86400000*2;
	       		         						     saturday=sunMil-86400000*1;
	       		         						     sunday=sunMil;
	       		         						     monday=sunMil+86400000*1;
	       		         						     tuesday=sunMil+86400000*2;
	       		         						     wenesday=sunMil+86400000*3;
	       		         						     thirsday=sunMil+86400000*4;
	  	    								    	  
	  	    								      }else if(weekshift1==6){
	  	    								    	
	       		         						     saturday=sunMil-86400000*1;
	       		         						     sunday=sunMil;
	       		         						     monday=sunMil+86400000*1;
	       		         						     tuesday=sunMil+86400000*2;
	       		         						     wenesday=sunMil+86400000*3;
	       		         						     thirsday=sunMil+86400000*4;
	       		         						     friday=sunMil+86400000*5;
	  	    								    	  
	  	    								      }else if(weekshift1==7){
	  	    								    	
	       		         						     sunday=sunMil;
	       		         						     monday=sunMil+86400000*1;
	       		         						     tuesday=sunMil+86400000*2;
	       		         						     wenesday=sunMil+86400000*3;
	       		         						     thirsday=sunMil+86400000*4;
	       		         						     friday=sunMil+86400000*5;
	       		         						     saturday=sunMil-86400000*6;
	  	    								      }
  	    								      
        		         						  
        		         						  
        		         						  
        		         						  
        		         						  monday=new Date(monday).Format("MM-dd");
        		         						  tuesday=new Date(tuesday).Format("MM-dd");
        		         						  wenesday=new Date(wenesday).Format("MM-dd");
        		         						  thirsday=new Date(thirsday).Format("MM-dd");
        		         						  friday=new Date(friday).Format("MM-dd");
        		         						  saturday=new Date(saturday).Format("MM-dd");
        		         						  sunday=new Date(sunday).Format("MM-dd");
        		         						  
        		         						 
        		         						  
        		         						  $('#tdP1').text(monday);
        		         						  $('#tdP2').text(tuesday);
        		         						  $('#tdP3').text(wenesday);
        		         						  $('#tdP4').text(thirsday);
        		         						  $('#tdP5').text(friday);
        		         						  $('#tdP6').text(saturday);
        		         						  $('#tdP7').text(sunday);
        		         						  
        		         						  if(curWeek==zc){
        		         							 markCur();
        		         						  }
        		         						  
        		         						
        		         						  
        		         						  $.each(raw2.weeklist,function(i,dom){
        		         							 
			         							  var thid='trang'+dom.zc;
			         							  var theadrow=dom.xqs;
			         							  var theadcol=dom.jcdm;
			         							  
			         							  theadcol=theadcol.split(',');
			         							  
			         							 $.each(theadcol,function(t,doc){
			         								  if(dom.zc==currentW){
			         									 $('#'+thid).children('tbody').children('tr').eq(theadcol[t]-1).children('td').eq(theadrow-1).css('background','#FF6D6D')
			         								  }else{
			         									 $('#'+thid).children('tbody').children('tr').eq(theadcol[t]-1).children('td').eq(theadrow-1).css('background','#7693FF') 
			         								  }
			         								 
			         							  })
			         							  
			         							 
			         							  
			         							 
        		         						  })
        		         						  
        		         						  
        		         						  
        		         						  $.each(raw2.list,function(i,dom){
	        	 				   		 
				        	 				   		 var row=dom.xqs;
				        	 				   		 var col=dom.jcdm;
				        	 				   		 
				        	 				   		 var colArr= new Array(); //定义一数组 
				        	 				   		 colArr=col.split(',');
			
				        	 				   		 row=parseInt(row);
				        	 				   		 weekshift=parseInt(weekshift);
				        	 				   		 
				        	 				   		 row=7-(weekshift-row)+1;
				        	 				   		
				        	 				   		 if(row>7){
				        	 				   			 row=row-7;
				        	 				   		 } 
				        	 				   		 
				        	 				   		 var trueClasIndex=colArr[0]-1;
				        	 				   		 var span0=parseInt(colArr.length)-1;
				        	 				   		 var span1=parseInt(colArr[0]);
				        	 				   		 var span2=parseInt(trueIndex);
				        	 				   		 var oneside=span0+span1;
				        	 				   		 
				        	 				   		//var tdClass='meg'+dom.color;
				        	 				   		
				        	 				   		//$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
				        	 				   		//$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass(tdClass);
				        	 				   		 
				        	 				   		 
				        	 				   		 if(oneside<=parseInt(trueIndex)||parseInt(trueIndex)==0){
				        	 				   			// console.log("早上以内")
				        	 				   			 //早上或没有午休
				        	 				   		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
				        	 				   		 	
				        	 				   			if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
				        	 				   				
				        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
				        	 				   			}else{
				        	 				   				
				        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
				        	 				   			}
				        	 				   			
				        	 				   		    $('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).attr('rowspan',colArr.length)
					        	 				   		 
				        	 				   		    
					        	 				   		for(var m=1;m<colArr.length;m++){
				        	 				   				
				        	 				   				$('.table').children('tbody').children('tr').eq(colArr[m]-1).children('td').eq(row).hide();//隐藏节次后几节
				        	 				   			}
				        	 				   		 }else{
				        	 				   			 
				        	 				   			 if(span1>span2){
				        	 				   				
				        	 				   				 //下午的课程
				        	 				   				 
				        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).addClass('ok');
				        	 				   				
					        	 				   			if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
					        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
					        	 				   			}else{
					        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
					        	 				   			}
				             	 				   		 	
				         	 				   		 		
				         	 				   		 		$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).attr("rowspan",parseInt(colArr.length));
				         	 				   		 		for(var m=1;m<colArr.length;m++){
				         	 				   		 			//console.log(colArr[m]-1+"   "+row);
				         	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[m]).children('td').eq(row).hide();//隐藏节次后几节
				         	 				   		 		}
				         	 				   		 		

					        	 				   		

				        	 				   			 }else{
				        	 				   				 //早上至下午的课程
				        	 				   				 
				        	 				   				 
				        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
					        	 				   			if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
					        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
					        	 				   			}else{
					        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
					        	 				   			}
				            	 				   		 	
				        	 				   		 		
				        	 				   		 		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).attr("rowspan",parseInt(colArr.length)+1);
				        	 				   		 		for(var m=1;m<colArr.length;m++){
				        	 				   		 			//console.log(colArr[m]-1+"   "+row);
				        	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[m]-1).children('td').eq(row).hide();//隐藏节次后几节
				        	 				   		 		}
				        	 					 		$('.table').children('tbody').children('tr').eq(colArr[colArr.length-1]).children('td').eq(row).hide();//隐藏

				        	 				   							        	 				   			
				        	 				   			 }
				        	 				   			 
				        	 				   			
				        	 				   			 
				        	 				   		 }
				        	 				   		 
				   
				        	 				   		 
			        	 				   		
				        	 				   	  })
        		         						 

        		        	 				   	  
        		        	 				   	
        		        	 				   	  
        		        	 				   	   $('.ok').each(function(){
        		        	 				   		   
	        		        	 				   		if($(this).attr('rowspan')>1){
	        		        	 				   			if($(this).children('.cn').text().length+$(this).children('.room').text().length<24){
		        		        	 				   			$(this).children('.cn').css('white-space','normal')
		        		        	 				   			$(this).children('.room').css('white-space','normal')
		        		        	 				   			$(this).children('.cn').css('display','block')
		        		        	 				   			$(this).children('.room').css('display','block')
	        		        	 				   			}else{
		        		        	 				   			$(this).children('.cn').css('-webkit-line-clamp','3')
		        		        	 				   			$(this).children('.room').css('-webkit-line-clamp','3')
	        		        	 				   			}
	        		        	 				   			
	        		        	 				   			
	        		        	 				   		}
	        		        	 				   		
	        		        	 				   	var coloring=$(this).children('.color').val();
	        		        	 				   	var colorClass='meg'+coloring;
	        		        	 				   	$(this).addClass(colorClass)
	        		        	 				   		
	        		        	 				   		
	        		        	 				  
        		        	 				   			
        		        	 				   		 })
        		        	 				   		 
        		        	 				   		 
        		        	 				   		 
        		        	 				   		
        		        	 				   		 
        		        	 				   		 
        		        	 				   		 
        		        	 				   		 
        		        	 				   	 //非当前周
        			         						 $.each(raw2.kcList,function(i,dom){
        			        	 				   		 
        			        	 				   		 var row=dom.xqs;
        			        	 				   		 var col=dom.jcdm;
        			        	 				   		 
        			        	 				   		 var colArr= new Array(); //定义一数组 
        			        	 				   		 colArr=col.split(',');

        			        	 				   		 row=parseInt(row);
        			        	 				   		 weekshift=parseInt(weekshift);
        			        	 				   		 
        			        	 				   		 row=7-(weekshift-row)+1;
        			        	 				   		
        			        	 				   		 if(row>7){
        			        	 				   			 row=row-7;
        			        	 				   		 } 
        			        	 				   		 
        			        	 				   		 var topId='trang'+zc;
        			        	 				   		 for(var m=0;m<colArr.length;m++){
        			        	 				   			 var colIndex=colArr[m]-1;
        			        	 				   			
        			        	 				   			 if(ifNapping){
        			        	 				   			 if(colIndex>trueIndex-1){            	 				   			 
        			             	 				   			colIndex=colArr[m];             	 				   		                 	 				   			
        			             	 				   			} 
        			        	 				   			 }
        			        	 				   			
        			        	 				   			var resident=$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).attr('class');
        			        	 				   			
        			        	 				   			if(resident!=undefined){
        			        	 				   				return;
        			        	 				   			}
        			        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).addClass('notCurrent');
        			        	 				   			if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
        			        	 				   				
        			        	 				   				$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='teacher'>[非本周]</span><span class='cn'>"+dom.courseName+"</span><input type='hidden' class='noneId' value="+dom.id+"><input type='hidden' class='noneIndex' value="+colIndex+"><input type='hidden' class='noneweek' value="+dom.xqs+"><span class='room'>@"+dom.room+"</span>");
        			        	 				   			}else{
        			        	 				   				
        			        	 				   				$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='teacher'>[非本周]</span><span class='cn'>"+dom.courseName+"</span><input type='hidden' class='noneId' value="+dom.id+"><input type='hidden' class='noneIndex' value="+colIndex+"><input type='hidden' class='noneweek' value="+dom.xqs+"><span class='room'>"+dom.room+"</span>");
        			        	 				   			}
        			        	 				   			
        			        	 				   		    //$('#'+topId).children('tbody').children('tr').eq(colIndex).children('td').eq(row-1).css('background','red')
        			        	 				   		 	
        			        	 				   		 }	        	 				   		 
        			        	 				   		
        			        	 				   	  })
        			        	 				   	  
        			        	 				   	  $('.notCurrent').each(function(){
        			        	 				   		  $(this).css('background','#CDCED7')
        			        	 				   	  })
        			        	 				   	  var otherset=[];
        			         						 var strotherset='';
        			        	 				   	  $('.notCurrent').each(function(){
        			        	 				   		  if($(this).css('display')!='none'){
        			        	 				   			  var noneweek=$(this).children('.noneweek').val();
        				        	 				   		  var noneId=$(this).children('.noneId').val();
        				        	 				   		  var noneIndex=$(this).children('.noneIndex').val();
        				        	 				   		 // console.log('星期：'+noneweek+' 节次：'+noneIndex+' 课程id:'+noneId);
        				        	 				   		  
        				        	 				   		strotherset+='{'+'"'+'week'+'"'+':'+'"'+noneweek+'"'+','+'"'+'series'+'"'+':'+'"'+noneIndex+'"'+','+'"'+'id'+'"'+':'+'"'+noneId+'"'+'}'+',';
        				        	 				   		otherset.push(noneId)
        			        	 				   		  }
        			        	 				   		  
        			        	 				   		 
        			        	 				   		  
        			        	 				   	  })
        			        	 				   	  strotherset=strotherset.substring(0,strotherset.length-1);
        			        	 				   	  strotherset='['+strotherset+']';
        			        	 				   	  strotherset=$.parseJSON(strotherset);
        			        	 				   
        			        	 				   	  
        			        	 				   	 
        			        	 				   	  var thao='';
        			        	 				   	  var vivian=[];
        			        	 				   	  for(i=0;i<unique1(otherset).length;i++){
        			        	 				   		  
        			        	 				   		  var clsstr=[];
        			        	 				   		  var wk='';
        			        	 				   		  
        			        	 				   		  for(var j=0;j<strotherset.length;j++){
        			        	 				   			  
        			        	 				   			  if(unique1(otherset)[i]==strotherset[j].id){
        			        	 				   				clsstr.push(strotherset[j].series);
        			        	 				   				wk=strotherset[j].week;
	        			        	 				   			wk=7-(weekshift-wk)+1;
	        		    	        	 				   		
	        			   	        	 				   		 if(wk>7){
	        			   	        	 				   			 wk=wk-7;
	        			   	        	 				   		 } 
        			        	 				   			  }
        			        	 				   			  
        			        	 				   		  }
        			        	 				   		 // console.log('第一节课位置：'+clsstr[0]+'连续长度：'+clsstr.length +'---星期几-'+wk+' 午休位置 ' +trueIndex)
        			        	 				   		  //...........................start
        			        	 				   		 if(parseInt(clsstr[0])+parseInt(clsstr.length)<=parseInt(trueIndex)||parseInt(trueIndex)==0){
        				        	 				   			 //console.log("早上以内")
        				        	 				   		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
        				        	 				   		 	
        				        	 				   			/*if(dom.room!=''&&dom.room!=null&&dom.room!='null'){*/
        				        	 				   				
        				        	 				   					$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
        				        	 				   				
        				        	 				   			
        				        	 				   		    		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr('rowspan',clsstr.length)
        					        	 				   		 
        				        	 				   		    
        					        	 				   		for(var m=1;m<clsstr.length;m++){
        				        	 				   				
        				        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
        				        	 				   			}
        				        	 				   		    		
        				        	 				   		 }else{
        				        	 				   			 
        				        	 				   			 if(parseInt(clsstr[0])>parseInt(trueIndex)){
        				        	 				   				
        				        	 				   				// console.log('aftermoon', row)
        				        	 				   				 
        				        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
        				             	 				   		 	$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
        				         	 				   		 		
        				         	 				   		 		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr("rowspan",parseInt(clsstr.length));
        				         	 				   		 		for(var m=1;m<clsstr.length;m++){
        				         	 				   		 			//console.log(colArr[m]-1+"   "+row);
        				         	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
        				         	 				   		 		}
        				         	 				   		 		// $('.table').children('tbody').children('tr').eq(colArr[colArr.length-1]).children('td').eq(row).hide();//隐藏

        					        	 				   		

        				        	 				   			 }else{
        				        	 				   				
        				        	 				   				// console.log('morning to afternoon')
        				        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
        				            	 				   		 	$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
        				        	 				   		 		//console.log(parseInt(colArr[0])+"==="+parseInt(napIndex)+"==="+parseInt(colArr[colArr.length-1])+"==="+parseInt(napIndex));	
        				        	 				   		 		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr("rowspan",parseInt(clsstr.length)+1);
        				        	 				   		 		
        				        	 				   		 		for(var m=1;m<clsstr.length;m++){
        				        	 				   		 			
        				        	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
        				        	 				   		 		}
        				        	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[clsstr.length-1]+1).children('td').eq(wk).hide();//隐藏

        				        	 				   							        	 				   			
        				        	 				   			 }
        				        	 				   			 
        				        	 				   			
        				        	 				   			 
        				        	 				   		 } 
        			        	 				   		  
        			        	 				   		  //....................end
        			        	 				   	  }
        			        	 				   	  
        			        	 				   	  
        			        	 				   	$('.notCurrent').each(function(){
				        	 				   			/*if($(this).attr('rowspan')>1){
				        	 				   				$(this).children('.cn').css('-webkit-line-clamp','2')
				        	 				   			}else{
				        	 				   				$(this).children('.cn').css('-webkit-line-clamp','1')
				        	 				   			}*/
        			        	 				   		
        			        	 				   	if($(this).attr('rowspan')>1){
        		        	 				   			if($(this).children('.cn').text().length+$(this).children('.room').text().length<20){
            		        	 				   			$(this).children('.cn').css('white-space','normal')
            		        	 				   			$(this).children('.room').css('white-space','normal')
            		        	 				   			$(this).children('.cn').css('display','block')
            		        	 				   			$(this).children('.room').css('display','block')
        		        	 				   			}else{
            		        	 				   			$(this).children('.cn').css('-webkit-line-clamp','3')
            		        	 				   			$(this).children('.room').css('-webkit-line-clamp','3')
        		        	 				   			}
        		        	 				   			
        		        	 				   			
        		        	 				   		}else{
        		        	 				   			if($(this).children('.room').text().length==0){
        		        	 				   			 $(this).children('.cn').css('-webkit-line-clamp','2')
        		        	 				   			}else{
        		        	 				   			 $(this).children('.cn').css('-webkit-line-clamp','1')
        		        	 				   			}
        		        	 				   		   
        		        	 				   		}
        			        	 				   		
        			        	 				   		
				        	 				   		
				        	 				   			
				        	 				   		}) 	
				        	 				   		
				        	 				   		
        			        	 				   	  
        			        	 				  
       		        	 				   		 
        		        	 				   		
        		        	 				   		 
        		        	 				   	/*  $('td').each(function(){ */
        		        	 				   		 $('.table').children('tbody').children('tr').children('td').each(function(){
        		        	 				   		 $(this).click(function(){
        		        	 				   			$('td').removeClass("addTd");
        		        	 				   			$('td').children('.addImgA').remove();
        		        	 				   			
        		        	 				   			var row=$(this).parent().prevAll().length+1; 
        		   	 				   			 		var col=$(this).prevAll().length;
        		   	 				   			
		        		   	 				   			if(ifNapping){
		     			   	 				   			 	if(row==trueIndex+1||col==0){
		     			   	 				   			 		if(col==0){
		     			   	 				   			 			window.location="clsDuraLiveSet.html";
		     			   	 				   			 			return;
		     			   	 				   			 		}else{
		     			   	 				   			 			return;
		     			   	 				   			 		}
		     		   	 				   				 		
		     		   	 				   			 		}
		     	   	 				   			 		}else{
		     	   	 				   			 			if(col==0){
		     	   	 				   			 				window.location="clsDuraLiveSet.html";
		     	   	 				   			 				return;
		     	   	 				   			 			}
		     	   	 				   			 		}
        		   	 				   			 		if(ifNapping&&row>trueIndex){
        		   	 				   						row=row-1;
        		   	 				   			 		}
        		   	 				   					var rawstr=$('.table').children('thead').children('tr').children('td').eq(col).text();
        			 				   			 		rawstr=rawstr.substring(0,2);
        			 				   			 		rawstr=interpret(rawstr);
        		        	 				   			
        		        	 				   			var lesson=$(this).children('.cn').text();
        		        	 				   			var teacher=$(this).children('.teacher').text(); 
        		        	 				   			var paraArr=[];
        		        	 				   			paraArr.push(lesson);
        		        	 				   			paraArr.push(row);
        		        	 				   			paraArr.push(rawstr);
        		        	 				   			localStorage.paraArr=paraArr;
        		        	 				   			if(lesson.length>0){
        		        	 				   				
        		        	 				   				
        		        	 				   			
        		        	 				   				localStorage.lesson=lesson;
        		        	 				   				
        		        	 				   				
        		        	 				   				window.location='courseDetail.html';
        		        	 				   				
        		        	 				   				
        		        	 				   			}else{
        		        	 				   			 
        		        	 				   			 
        		        	 				   			
        		        	 				   			$(this).addClass("addTd");
        		        	 				   			$(this).append("<a href='javascript:;' class='addImgA'><img src='../image/addCourse.png' alt=''></a>");
        		        	 				   			$('.addImgA').click(function(){
        		        	 				   				localStorage.row=row;
        		        	 				   				localStorage.rawstr=rawstr;
        		        	 				   				window.location='singleCourse.html';
        		        	 				   			})
        		        	 				           	
        		        	 				   			 
        		        	 				   			}
        		        	 				   			
        		        	 				   		 })
        		        	 				   	 })
        		        	 
        		         					  }
        			 						  }) 
        			        	        	 //....
        			        	         }
        			        		 })
        			        	 
        			         }
        				 })
        		}
        				 
     
      
    	
    	
    	var newLoading=function(userId,zc,weekshift,ifNapping,napIndex){
    		
    		
    		 
	   	   	var url=cutUrl()+"/api/course/qryCourseList";
		    var mes='{"userId":"'+userId+'","zc":"'+zc+'"}';

		        	        	 $.ajax({
	         					  "dataType": 'json',
	         					  "type": "POST",
	         					  "url": url,
	         					  "data": mes,
	         					  "contentType":"application/json;charset=utf-8",
	         					  "success": function (data, textStatus, jqXHR){
	         						 //$('.table').children('tbody').children('tr').eq(0).children('td').eq(3).css('background-color','yellow');
	         						  var raw2=JSON.stringify(data);
	         						 // console.log(raw2)
	         						
	         						  raw2=$.parseJSON(raw2);
	         						  //var monday=raw2.mondayDate;
	         						 // console.log(raw2);
	         						  var monday1=getMonday();

	         						  milm=Date.parse(monday1);	         						  
	         						  weekshift=parseInt(weekshift);
	         						  var monday='';
	         						  var tuesday='';
	         						  var wenesday='';
	         						  var thirsday='';
	         						  var friday='';
	         						  var saturday='';
	         						  var sunday='';
	         						  var cur=new Date().getDay();	         						  
	         						  var today=new Date();  	         						  
    								  var tmilm=Date.parse(today);    								  	         						  
	         						  if(weekshift>1&&weekshift<7){
	         							  
		         						  
		         						  var getSun=getSunday();
		         						  var sunMil=Date.parse(getSun);
		         						  var priorSun=getPriorSun();
		         						  var priorSunMil=Date.parse(priorSun);
		         						  
		         						 
		         						  	  if(weekshift<=cur){
		         						  		if(weekshift==2){
			         								  
			         								  tuesday=sunMil-86400000*5;
			         								  wenesday=sunMil-86400000*4;
					         						  thirsday=sunMil-86400000*3;
					         						  friday=sunMil-86400000*2;
					         						  saturday=sunMil-86400000*1;
					         						  sunday=sunMil;
					         						  monday=sunMil+86400000*1;
			         								  
			         							  }else if(weekshift==3){
			         								  
			         								  wenesday=sunMil-86400000*4;
					         						  thirsday=sunMil-86400000*3;
					         						  friday=sunMil-86400000*2;
					         						  saturday=sunMil-86400000*1;
					         						  sunday=sunMil;
					         						  monday=sunMil+86400000*1;
			         								  tuesday=sunMil+86400000*2;
			         								  
			         							  }else if(weekshift==4){
			         								 
					         						  thirsday=sunMil-86400000*3;
					         						  friday=sunMil-86400000*2;
					         						  saturday=sunMil-86400000*1;
					         						  sunday=sunMil;
					         						  monday=sunMil+86400000*1;
			         								  tuesday=sunMil+86400000*2;
			         								  wenesday=sunMil+86400000*3;
			         								  
			         							  }else if(weekshift==5){
			         								  
					         						  friday=sunMil-86400000*2;
					         						  saturday=sunMil-86400000*1;
					         						  sunday=sunMil;
					         						  monday=sunMil+86400000*1;
			         								  tuesday=sunMil+86400000*2;
			         								  wenesday=sunMil+86400000*3;
					         						  thirsday=sunMil+86400000*4;
			         								  
			         							  }else if(weekshift==6){
			         								  
					         						  saturday=sunMil-86400000*1;
					         						  sunday=sunMil;
					         						  monday=sunMil+86400000*1;
			         								  tuesday=sunMil+86400000*2;
			         								  wenesday=sunMil+86400000*3;
					         						  thirsday=sunMil+86400000*4;
					         						  friday=sunMil+86400000*5;
			         								  
			         							  }
		         						  	  }else{
		         						  		if(weekshift==2){
			         								  
			         								  tuesday=priorSunMil-86400000*5;
			         								  wenesday=priorSunMil-86400000*4;
					         						  thirsday=priorSunMil-86400000*3;
					         						  friday=priorSunMil-86400000*2;
					         						  saturday=priorSunMil-86400000*1;
					         						  sunday=priorSunMil;
					         						  monday=priorSunMil+86400000*1;
			         								  
			         							  }else if(weekshift==3){
			         								  
			         								  wenesday=priorSunMil-86400000*4;
					         						  thirsday=priorSunMil-86400000*3;
					         						  friday=priorSunMil-86400000*2;
					         						  saturday=priorSunMil-86400000*1;
					         						  sunday=priorSunMil;
					         						  monday=priorSunMil+86400000*1;
			         								  tuesday=priorSunMil+86400000*2;
			         								  
			         							  }else if(weekshift==4){
			         								 
					         						  thirsday=priorSunMil-86400000*3;
					         						  friday=priorSunMil-86400000*2;
					         						  saturday=priorSunMil-86400000*1;
					         						  sunday=priorSunMil;
					         						  monday=priorSunMil+86400000*1;
			         								  tuesday=priorSunMil+86400000*2;
			         								  wenesday=priorSunMil+86400000*3;
			         								  
			         							  }else if(weekshift==5){
			         								  
					         						  friday=priorSunMil-86400000*2;
					         						  saturday=priorSunMil-86400000*1;
					         						  sunday=priorSunMil;
					         						  monday=priorSunMil+86400000*1;
			         								  tuesday=priorSunMil+86400000*2;
			         								  wenesday=priorSunMil+86400000*3;
					         						  thirsday=priorSunMil+86400000*4;
			         								  
			         							  }else if(weekshift==6){
			         								  
					         						  saturday=priorSunMil-86400000*1;
					         						  sunday=priorSunMil;
					         						  monday=priorSunMil+86400000*1;
			         								  tuesday=priorSunMil+86400000*2;
			         								  wenesday=priorSunMil+86400000*3;
					         						  thirsday=priorSunMil+86400000*4;
					         						  friday=priorSunMil+86400000*5;
			         								  
			         							  }
		         						  	  }

		         						  
	         						  }else if(weekshift==7){//每周起始日为星期天
	         							  
	         							  if(cur==7){
	         								  
	         								  monday=tmilm+86400000*1;
		         							  tuesday=tmilm+86400000*2;
			         						  wenesday=tmilm+86400000*3;
			         						  thirsday=tmilm+86400000*4;
			         						  friday=tmilm+86400000*5;
			         						  saturday=tmilm+86400000*6;
			         						  sunday=tmilm;
	         							  }else{
	         								  monday=milm;
		         							  tuesday=milm+86400000*1;
			         						  wenesday=milm+86400000*2;
			         						  thirsday=milm+86400000*3;
			         						  friday=milm+86400000*4;
			         						  saturday=milm+86400000*5;
			         						  sunday=milm-86400000; 
	         							  }
	         							  
	         							  
	         						  }else{//每周起始日为星期一
	         							  monday=milm;
	         							  tuesday=milm+86400000*1;
		         						  wenesday=milm+86400000*2;
		         						  thirsday=milm+86400000*3;
		         						  friday=milm+86400000*4;
		         						  saturday=milm+86400000*5;
		         						  sunday=milm+86400000*6;
	         							  
	         						  }
	         						  

	         						  
	         						  monday=new Date(monday).Format("MM-dd");
	         						  tuesday=new Date(tuesday).Format("MM-dd");
	         						  wenesday=new Date(wenesday).Format("MM-dd");
	         						  thirsday=new Date(thirsday).Format("MM-dd");
	         						  friday=new Date(friday).Format("MM-dd");
	         						  saturday=new Date(saturday).Format("MM-dd");
	         						  sunday=new Date(sunday).Format("MM-dd");
	         						  $('#tdP1').text(monday);
	         						  $('#tdP2').text(tuesday);
	         						  $('#tdP3').text(wenesday);
	         						  $('#tdP4').text(thirsday);
	         						  $('#tdP5').text(friday);
	         						  $('#tdP6').text(saturday);
	         						  $('#tdP7').text(sunday);
	         						 
	         						  markCur();
	         						  //课程小图标
	         						
	         						  
	         						 $.each(raw2.weeklist,function(i,dom){
	         							
	         							  var thid='trang'+dom.zc;
	         							  var theadrow=dom.xqs;
	         							  var theadcol=dom.jcdm;
	         							  
	         							  theadcol=theadcol.split(',');
	         							  $.each(theadcol,function(t,doc){
	         								  if(dom.zc==zc){
	         									 $('#'+thid).children('tbody').children('tr').eq(theadcol[t]-1).children('td').eq(theadrow-1).css('background','#FF6D6D')
	         								  }else{
	         									 $('#'+thid).children('tbody').children('tr').eq(theadcol[t]-1).children('td').eq(theadrow-1).css('background','#7693FF') 
	         								  }
	         								 
	         							  })
	         							  
	         							 
	         						  })
	         						  
	         						  
	         						  
	        	 				   	  $.each(raw2.list,function(i,dom){
	        	 				   		 
	        	 				   		 var row=dom.xqs;
	        	 				   		 var col=dom.jcdm;
	        	 				   		
	        	 				   		 var colArr= new Array(); //定义一数组 
	        	 				   		 colArr=col.split(',');
	        	 				   		
	        	 				   		 row=parseInt(row);
	        	 				   		 weekshift=parseInt(weekshift);
	        	 				   		 
	        	 				   		 row=7-(weekshift-row)+1;
	        	 				   		
	        	 				   		 if(row>7){
	        	 				   			 row=row-7;
	        	 				   		 } 
	        	 				   		 
	        	 				   		 
	        	 				   		 
	        	 				   		 var topId='trang'+zc;
	        	 				   		 for(var m=0;m<colArr.length;m++){
	        	 				   			 var colIndex=colArr[m]-1;
	        	 				   			
	        	 				   			 if(ifNapping){
	        	 				   			 if(colIndex>napIndex-1){            	 				   			 
	             	 				   			colIndex=colArr[m];             	 				   		                 	 				   			
	             	 				   			} 
	        	 				   			 }
	        	 				   			 
	        	 				   			 
	        	 				   			 
	        	 				   			 //----
	        	 				   			var trueClasIndex=colArr[0]-1;
		        	 				   		 var span0=parseInt(colArr.length)-1;
		        	 				   		 var span1=parseInt(colArr[0]);
		        	 				   		 var span2=parseInt(napIndex);
		        	 				   		 var oneside=span0+span1;
		        	 				   		
		        	 				   		
		        	 				   		 if(oneside<=parseInt(napIndex)||parseInt(napIndex)==0){
		        	 				   			 
		        	 				   		
		        	 				   		 
		        	 				   		  
		        	 				   		  $('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
		        	 				   		  //$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass(tdClass);
		        	 				   			if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
		        	 				   				
		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
		        	 				   			}else{
		        	 				   				
		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
		        	 				   			}
		        	 				   			
		        	 				   			//console.log(colArr[0]-1+'---'+row+'colArr.lenght:'+colArr.length+'courseName:'+dom.courseName);
		        	 				   			
		        	 				   		    		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).attr('rowspan',colArr.length)
			        	 				   		 
		        	 				   		    
			        	 				   		for(var m=1;m<colArr.length;m++){
		        	 				   				
		        	 				   				$('.table').children('tbody').children('tr').eq(colArr[m]-1).children('td').eq(row).hide();//隐藏节次后几节
		        	 				   			}
		        	 				   		    		
		        	 				   		 }else{
		        	 				   			 
		        	 				   			 if(span1>span2){
		        	 				   				
		        	 				   				 //console.log('aftermoon', row)
		        	 				   				 
		        	 				   				  $('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).addClass('ok');
		        	 				   				  //$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass(tdClass);
			             	 				   		if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
			             	 				   			$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
			             	 				   		}else{
			             	 				   			$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
			             	 				   		}
		         	 				   		 		$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).attr("rowspan",parseInt(colArr.length));
		         	 				   		 		for(var m=1;m<colArr.length;m++){
		         	 				   		 			
		         	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[m]).children('td').eq(row).hide();//隐藏节次后几节
		         	 				   		 		}
		         	 				   		 		

			        	 				   		

		        	 				   			 }else{
		        	 				   				 
		        	 				   				 //console.log('morning to afternoon'+tdClass)
		        	 				   				 
		        	 				   				  $('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
		        	 				   				  //$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass(tdClass);
		        	 				   				if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
		        	 				   				}else{
		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
		        	 				   				}
		            	 				   		 	
		        	 				   		 		//console.log(parseInt(colArr[0])+"==="+parseInt(napIndex)+"==="+parseInt(colArr[colArr.length-1])+"==="+parseInt(napIndex));	
		        	 				   		 		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).attr("rowspan",parseInt(colArr.length)+1);
		        	 				   		 		
		        	 				   		 		for(var m=1;m<colArr.length;m++){
		        	 				   		 			
		        	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[m]-1).children('td').eq(row).hide();//隐藏节次后几节
		        	 				   		 		}
		        	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[colArr.length-1]).children('td').eq(row).hide();//隐藏

		        	 				   							        	 				   			
		        	 				   			 }
		        	 				   			 
		        	 				   			
		        	 				   			 
		        	 				   		 }     	 				   			 	        	 				   			
	        	 				   			
	        	 				   			
	        	 				   		 	
	        	 				   		 }	        	 				   		 
	        	 				   		
	        	 				   	  })
	        	 				   	  
	        	 				   	  
	        	 				   	  
	        	 				   	  
	        	 				   	  
	        	 				   	   $('.ok').each(function(){
	        	 				   		   
	        	 				   		   
	        	 				   		if($(this).attr('rowspan')>1){
	        	 				   			if($(this).children('.cn').text().length+$(this).children('.room').text().length<24){
		        	 				   			$(this).children('.cn').css('white-space','normal')
		        	 				   			$(this).children('.room').css('white-space','normal')
		        	 				   			$(this).children('.cn').css('display','block')
		        	 				   			$(this).children('.room').css('display','block')
		        	 				   			
	        	 				   			}else{
		        	 				   			$(this).children('.cn').css('-webkit-line-clamp','3')
		        	 				   			$(this).children('.room').css('-webkit-line-clamp','3')
	        	 				   			}
	        	 				   			
	        	 				   			
	        	 				   		}
	        	 				   		
	        	 				   		
	        	 				   	
	        	 				   	
	        	 				   	var coloring=$(this).children('.color').val();
	        	 				   	var colorClass='meg'+coloring;
	        	 				   	$(this).addClass(colorClass)
	        	 				   	
	        	 			
        		        	 				   			
        		        	 				   		 })
	        	 				   	  
	        	 				   	  
	        	 				   	  
	        	 				   		 
	        	 				   		
	        	 				   		 
	        	 				   		 //非当前周
	         						 $.each(raw2.kcList,function(i,dom){
	        	 				   		 
	        	 				   		 var row=dom.xqs;
	        	 				   		 var col=dom.jcdm;
	        	 				   	 
	        	 				   		 var colArr= new Array(); //定义一数组 
	        	 				   		 colArr=col.split(',');

	        	 				   		 row=parseInt(row);
	        	 				   		 weekshift=parseInt(weekshift);
	        	 				   		 
	        	 				   		 row=7-(weekshift-row)+1;
	        	 				   		
	        	 				   		 if(row>7){
	        	 				   			 row=row-7;
	        	 				   		 } 
	        	 				   		 
	        	 				   		
	        	 				   		 var topId='trang'+zc;
	        	 				   		 for(var m=0;m<colArr.length;m++){
	        	 				   			 var colIndex=colArr[m]-1;
	        	 				   			
	        	 				   			 if(ifNapping){
	        	 				   			 if(colIndex>napIndex-1){            	 				   			 
	             	 				   			colIndex=colArr[m];             	 				   		                 	 				   			
	             	 				   			} 
	        	 				   			 }
	        	 				   			
	        	 				   			var resident=$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).attr('class');
	        	 				   			
	        	 				   			if(resident!=undefined){
	        	 				   				return;
	        	 				   			}
	        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).addClass('notCurrent');
		        	 				   		if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
		        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='teacher'>[非本周]</span><span class='cn'>"+dom.courseName+"</span><input type='hidden' class='noneId' value="+dom.id+"><input type='hidden' class='noneIndex' value="+colIndex+"><input type='hidden' class='noneweek' value="+dom.xqs+"><span class='room'>@"+dom.room+"</span>");
		        	 				   		}else{
		        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='teacher'>[非本周]</span><span class='cn'>"+dom.courseName+"</span><input type='hidden' class='noneId' value="+dom.id+"><input type='hidden' class='noneIndex' value="+colIndex+"><input type='hidden' class='noneweek' value="+dom.xqs+"><span class='room'>"+dom.room+"</span>");
		        	 				   		}
	        	 				   			
	        	 				   		    
	        	 				   		 	
	        	 				   		 }	        	 				   		 
	        	 				   		
	        	 				   	  })
	        	 				   	  
	        	 				   	  $('.notCurrent').each(function(){
	        	 				   		  $(this).css('background','#CDCED7');
	        	 				   		  
	        	 				   	  })
	        	 				   	  var otherset=[];
	         						 var strotherset='';
	        	 				   	  $('.notCurrent').each(function(){
	        	 				   		  if($(this).css('display')!='none'){
	        	 				   			  var noneweek=$(this).children('.noneweek').val();
		        	 				   		  var noneId=$(this).children('.noneId').val();
		        	 				   		  var noneIndex=$(this).children('.noneIndex').val();
		        	 				   		 
		        	 				   		  
		        	 				   		strotherset+='{'+'"'+'week'+'"'+':'+'"'+noneweek+'"'+','+'"'+'series'+'"'+':'+'"'+noneIndex+'"'+','+'"'+'id'+'"'+':'+'"'+noneId+'"'+'}'+',';
		        	 				   		otherset.push(noneId)
	        	 				   		  }
	        	 				   		  
	        	 				   		 
	        	 				   		  
	        	 				   	  })
	        	 				   	  strotherset=strotherset.substring(0,strotherset.length-1);
	        	 				   	  strotherset='['+strotherset+']';
	        	 				   	  strotherset=$.parseJSON(strotherset);
	        	 				   
	        	 				   	  
	        	 				   	 
	        	 				   	  var thao='';
	        	 				   	  var vivian=[];
	        	 				   	  for(i=0;i<unique1(otherset).length;i++){
	        	 				   		  
	        	 				   		  var clsstr=[];
	        	 				   		  var wk='';
	        	 				   		  
	        	 				   		  for(var j=0;j<strotherset.length;j++){
	        	 				   			  
	        	 				   			  if(unique1(otherset)[i]==strotherset[j].id){
	        	 				   				clsstr.push(strotherset[j].series);
	        	 				   				wk=strotherset[j].week;
		        	 				   			wk=7-(weekshift-wk)+1;
	    	        	 				   		
		   	        	 				   		 if(wk>7){
		   	        	 				   			 wk=wk-7;
		   	        	 				   		 } 
		   	        	 				   		 
		   	        	 				   		 
	        	 				   			  }
	        	 				   			  
	        	 				   		  }
	        	 				   		 
	        	 				   		  //...........................start
	        	 				   		 if(parseInt(clsstr[0])+parseInt(clsstr.length)<=parseInt(napIndex)||parseInt(napIndex)==0){
		        	 				   			
		        	 				   		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
		        	 				   		 	
		        	 				   			
		        	 				   				
		        	 				   					$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
		        	 				   				
			        	 				   				
		        	 				   			
		        	 				   		    		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr('rowspan',clsstr.length)
			        	 				   		 
		        	 				   		    
			        	 				   		for(var m=1;m<clsstr.length;m++){
		        	 				   				
		        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
		        	 				   			}
		        	 				   		    		
		        	 				   		 }else{
		        	 				   			 
		        	 				   			 if(parseInt(clsstr[0])>parseInt(napIndex)){
		        	 				   				
		        	 				   				// console.log('aftermoon', row)
		        	 				   				 
		        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
		             	 				   		 	$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
		         	 				   		 		
		         	 				   		 		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr("rowspan",parseInt(clsstr.length));
		         	 				   		 		for(var m=1;m<clsstr.length;m++){
		         	 				   		 			//console.log(colArr[m]-1+"   "+row);
		         	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
		         	 				   		 		}
		         	 				   		 		// $('.table').children('tbody').children('tr').eq(colArr[colArr.length-1]).children('td').eq(row).hide();//隐藏

			        	 				   		

		        	 				   			 }else{
		        	 				   				
		        	 				   				// console.log('morning to afternoon')
		        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
		            	 				   		 	$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
		        	 				   		 		//console.log(parseInt(colArr[0])+"==="+parseInt(napIndex)+"==="+parseInt(colArr[colArr.length-1])+"==="+parseInt(napIndex));	
		        	 				   		 		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr("rowspan",parseInt(clsstr.length)+1);
		        	 				   		 		
		        	 				   		 		for(var m=1;m<clsstr.length;m++){
		        	 				   		 			
		        	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
		        	 				   		 		}
		        	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[clsstr.length-1]+1).children('td').eq(wk).hide();//隐藏

		        	 				   							        	 				   			
		        	 				   			 }
		        	 				   			 
		        	 				   			
		        	 				   			 
		        	 				   		 } 
	        	 				   		  
	        	 				   		  //....................end
	        	 				   	  }
	        	 				   	  
	        	 				   	  

	        	 				   	  
	         						  //非当前end	 
	         						  
	        	 				   	$('.notCurrent').each(function(){
	        	 				   		
		        	 				   	if($(this).attr('rowspan')>1){
	        	 				   			if($(this).children('.cn').text().length+$(this).children('.room').text().length<20){
		        	 				   			$(this).children('.cn').css('white-space','normal')
		        	 				   			$(this).children('.room').css('white-space','normal')
		        	 				   			$(this).children('.cn').css('display','block')
		        	 				   			$(this).children('.room').css('display','block')
	        	 				   			}else{
		        	 				   			$(this).children('.cn').css('-webkit-line-clamp','3')
		        	 				   			$(this).children('.room').css('-webkit-line-clamp','3')
	        	 				   			}
	        	 				   			
	        	 				   			
	        	 				   		}else{
	        	 				   			if($(this).children('.room').text().length==0){
	        	 				   				$(this).children('.cn').css('-webkit-line-clamp','2')
	        	 				   			}else{
	        	 				   				$(this).children('.cn').css('-webkit-line-clamp','1')
	        	 				   			}
	        	 				   		    
	        	 				   		}
	        	 				   	
        	 				   		
        	 				   			
        	 				   		})
	        	 				   		
	        	 				   		 
	        	 				   		 
	        	 				   		 
	        	 				   	/*  $('td').each(function(){ */
	        	 				   		 $('.table').children('tbody').children('tr').children('td').each(function(){
	        	 				   		 $(this).click(function(){
	        	 				   			 
	        	 				   			
	        	 				   			/*var tdClass=$(this).attr('class');
	        	 				   			
	        	 				   			if(tdClass=='notCurrent'){
	        	 				   				
	        	 				   			}*/
	        	 				   			
	        	 				   			$('td').removeClass("addTd");
	        	 				   			$('td').children('.addImgA').remove();
	        	 				   			
	        	 				   			var row=$(this).parent().prevAll().length+1; 
	   	 				   			 		var col=$(this).prevAll().length;
	   	 				   			 		
	   	 				   			 		if(ifNapping){
			   	 				   			 	if(row==napIndex+1||col==0){
			   	 				   			 		if(col==0){
			   	 				   			 			window.location="clsDuraLiveSet.html";
			   	 				   			 			return;
			   	 				   			 		}else{
			   	 				   			 			return;
			   	 				   			 		}
		   	 				   				 		
		   	 				   			 		}
	   	 				   			 		}else{
	   	 				   			 			if(col==0){
	   	 				   			 				window.location="clsDuraLiveSet.html";
	   	 				   			 				return;
	   	 				   			 			}
	   	 				   			 		}
	   	 				   			 		
	   	 				   			 		
	   	 				   			 		if(ifNapping&&row>napIndex){
	   	 				   						row=row-1;
	   	 				   			 		}
	   	 				   					var rawstr=$('.table').children('thead').children('tr').children('td').eq(col).text();
		 				   			 		rawstr=rawstr.substring(0,2);
		 				   			 		rawstr=interpret(rawstr);
	        	 				   			
	        	 				   			var lesson=$(this).children('.cn').text();
	        	 				   			var teacher=$(this).children('.teacher').text(); 
	        	 				   			var paraArr=[];
	        	 				   			paraArr.push(lesson);
	        	 				   			paraArr.push(row);
	        	 				   			paraArr.push(rawstr);
	        	 				   			localStorage.paraArr=paraArr;
	        	 				   			if(lesson.length>0){
	        	 				   				
	        	 				   				
	        	 				   			
	        	 				   				localStorage.lesson=lesson;
	        	 				   				
	        	 				   				
	        	 				   				window.location='courseDetail.html';
	        	 				   				
	        	 				   				
	        	 				   			}else{
	        	 				   			 
	        	 				   			 
	        	 				   			
	        	 				   			$(this).addClass("addTd");
	        	 				   			$(this).append("<a href='javascript:;' class='addImgA'><img src='../image/addCourse.png' alt=''></a>");
	        	 				   			$('.addImgA').click(function(){
	        	 				   				localStorage.row=row;
	        	 				   				localStorage.rawstr=rawstr;
	        	 				   				window.location='singleCourse.html';
	        	 				   			})
	        	 				           
	        	 				   			 
	        	 				   			}
	        	 				   			
	        	 				   		 })
	        	 				   	 })
	        	 				   	 
	        	 				   	 $('.coverDiv').hide();
	        	 				    
	        	 
	         					  }
		 						  }) 
		        	        
		 						 
		 						 
		}
		        	        	 

		
		//获取用户信息
		try{
			jsBridge.bind('CLIENT_GET_USERINFO', function(object){
				 // alert("uid:"+object.uid+" name:"+object.name + "  fid:"+object.fid);
					


			});  
			var checkuser=function(){
				jsBridge.postNotification("CLIENT_GET_USERINFO", {"accountKey":"" } ) ;
			}
		    
		}catch(e){}

		
		
		var startx, starty;
        //获得角度
        function getAngle(angx, angy) {
            return Math.atan2(angy, angx) * 180 / Math.PI;
        };

        //根据起点终点返回方向 1向上 2向下 3向左 4向右 0未滑动
        function getDirection(startx, starty, endx, endy) {
           /* var angx = endx - startx;
            var angy = endy - starty;
            var result = 0;

            //如果滑动距离太短
            if (Math.abs(angx) < 2 && Math.abs(angy) < 2) {
                return result;
            }

            var angle = getAngle(angx, angy);
            if (angle >= -135 && angle <= -45) {
                result = 1;
            } else if (angle > 45 && angle < 135) {
                result = 2;
            } else if ((angle >= 135 && angle <= 180) || (angle >= -180 && angle < -135)) {
                result = 3;
            } else if (angle >= -45 && angle <= 45) {
                result = 4;
            }

            return result;*/
        	
        	var angx = endx - startx;
            var angy = endy - starty;
        	
            if(Math.abs(angx)>Math.abs(angy)){
            	result=1;
            }else if(Math.abs(angx)<Math.abs(angy)){
            	result=2;
            }else{
            	result=0;
            }
        	return result;
        	
        }
        //手指接触屏幕
        document.addEventListener("touchstart", function(e){
        	//$('#container').css('overflow','auto');
            startx = e.touches[0].pageX;
            starty = e.touches[0].pageY;
            
           
            $('.tj_div1').each(function(){
 
            	
            	if($(this).css('display')=='block'){
            		$('#currentPage').val($(this).attr('id'));
            		localStorage.currentPage=$(this).attr('id');
            	}
            })
            
        }, false);
        //手指滑动
        //document.addEventListener("touchend", function(e) {
        document.addEventListener("touchmove", function(e) {
            var endx, endy;
            endx = e.changedTouches[0].pageX;
            endy = e.changedTouches[0].pageY;
            var direction = getDirection(startx, starty, endx, endy);
            
            if(direction=='0'){
            	//$('#container').css('overflow','auto');
            }else if(direction=='1'){
            	//console.log('checking direction 左右')
            	//$('#container').css('overflow-x','auto');
            	//$('#container').css('overflow-y','hidden');
            }else if(direction=='2'){
            	//console.log('checking direction -----上下')
            	//$('#container').css('overflow-y','auto');
            	//$('#container').css('overflow-x','hidden');
            }else{
            	//$('#container').css('overflow','auto');
            }
            
           /* switch (direction) {
                case 0:
                    //alert("未滑动！");
                    
                	$('#container').css('overflow','auto')
                    break;
                case 1:
                    console.log("向上！");
                    //$('#container').css('overflow-y','auto')
                    //$('#container').css('overflow-x','hidden')
                    //$('#container').css("width","100%")
                    //$('#container').css("height","100%")
                    break;
                case 2:
                	//$('#container').css('overflow-y','auto')
                   // $('#container').css('overflow-x','hidden')
                	//$('#container').css("width","100%")
                    //$('#container').css("height","100%")
                    console.log("向下！");
                    break;
                case 3:
                	//$('#container').css('overflow-x','auto')
                    //$('#container').css('overflow-y','hidden')
                	//$('#container').css("width","100%")
                    //$('#container').css("height","100%")
                    
                    console.log("向左！")
                    
                    break;
                case 4:
                	//$('#container').css('overflow-x','auto')
                    //$('#container').css('overflow-y','hidden')
                	//$('#container').css("width","100%")
                   // $('#container').css("height","100%")
                    
                    console.log("向右！");
                    break;
                default:
            }*/
        }, false);
        
        document.addEventListener("touchend", function(e){
        	//console.log('release--------')
        	//$('#container').css('overflow','auto');
            //$('#container').css('overflow-x','auto')
        	
            
            
        }, false);
        
       
    	