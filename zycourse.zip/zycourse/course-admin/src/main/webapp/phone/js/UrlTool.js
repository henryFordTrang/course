/********************
 *
 *
 *url
 *
 * 
 ********************/
//截取网址部分信息
function cutUrl(){
	//window.location.pathname:设置或获取对象指定的文件名或路径(/web-bpzx/phone/xxx)
	return window.location.pathname.split("/phone")[0];//返回信息(/web-bpzx)
}
