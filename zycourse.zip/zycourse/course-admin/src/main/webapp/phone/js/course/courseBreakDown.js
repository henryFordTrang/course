$(function(){
	 var reg=/[\u4e00-\u9fa5]/g;
	 	var fid=localStorage.fid;
	    var uid=localStorage.uid;
	 	var userId=localStorage.userId;
	 	var spanset=[];
	 	var couse=localStorage.breakdownCourse;
	 	
	 	$('.menu_l').click(function(){
	 		window.location='initCourse.html';
	 	})
	 	
	 	var spanurl=cutUrl()+"/api/kbsz/qryJcTime";
  	 	var spanmes='{"userId":"'+userId+'"}';
	
  		 $.ajax({
  	         "dataType": 'json',
  	         "type": "POST",
  	         "url": spanurl,
  	         "data": spanmes,
  	         "contentType":"application/json;charset=utf-8",
  	         "success": function (data, textStatus, jqXHR){
  	        	 var raw=JSON.stringify(data);
  	        	 
  	        	 raw=$.parseJSON(raw);
  	        	 $.each(raw.list,function(i,dom){
  	        		 var unit=dom.jcdm+','+dom.jckssj+','+dom.jcjssj;
  	        		 spanset.push(unit);
  	        	 })
  	        	 
  	        	
  	   
 				//..........查询课程
  				
	        	 		 var courseUrl=cutUrl()+"/api/course/qryKcDetailsByCourseName";
	        	 		 var courseMes='{"userId":"'+userId+'","courseName":"'+couse+'","js":"","xnxqId":""}';
	        	 		 
	        	 		$.ajax({
	        	 	        "dataType": 'json',
	        	 	        "type": "POST",
	        	 	        "async":false,
	        	 	        "url": courseUrl,
	        	 	        "data": courseMes,
	        	 	        "contentType":"application/json;charset=utf-8",
	        	 	        "success": function (data, textStatus, jqXHR){
	        	 	       	var raw3=JSON.stringify(data);
	        	 	       	console.log(raw3);
	        	 	       	raw3=$.parseJSON(raw3);
	        	 	       	$.each(raw3.kcDetailsList,function(i,dom){
	        	 	       		var timespec=dom.xqs;
	        	 	       		var seriesCls=dom.jcdm;
	        	 	       		var during='';
	        	 	       		var index1=dom.id;
	        	 	       		if(dom.jcdm.length>1){
	        	 	       			
	        	 	       			var Arr=dom.jcdm.split(',');
	        	 	       		
	        	 	       			during=duration(spanset,Arr[0],Arr[Arr.length-1]);
	        	 	       			seriesCls=Arr[0]+'-'+Arr[Arr.length-1]+'节';
	        	 	       			
	        	 	       		}else{
	        	 	       			during=singleDura(spanset,dom.jcdm);
	        	 	       			
	        	 	       			during=during.split(',');
	        	 	       			during=during[1]+'-'+during[2];
	        	 	       			seriesCls=seriesCls+'节';
	        	 	       			
	        	 	       		}
	        	 	       		
	        	 	       		
	        	 	       		
	        	 	       		timespec=convertWeek(timespec);
	        	 	       		finalSpec=timespec+' '+seriesCls+' '+during;
	        	 	       		if(dom.status==2){
	        	 	       			$('.addCourseDiv').append("<div class='courseInfo'><p class='courseN'>"+dom.courseName+"</p><a href='javascript:;' class='setCourseA' id="+index1+"><div class='setCourse addC'><span class='courseEm'>添加到课表</span></div></a><p class='courseItem'><img src='../image/teacher.png' alt=''><span>老师：</span><span>"+dom.js+"</span></p><p class='courseItem'><img src='../image/courseT.png' alt=''><span>时间：</span><span>"+finalSpec+"</span></p><p class='courseItemLast'><img src='../image/courseP.png' alt=''><span>教室：</span><span>"+dom.room+"</span></p></div>");
	        	 	       				$('#'+index1).click(function(){
	        	 	       					$(this).children('.setCourse').toggleClass("addC").toggleClass("delC");
	        	 	       					if($(this).children().children(".courseEm").text()=="添加到课表"){
	        	 	       		        	$(this).children().children(".courseEm").text("删除");
	        	 	       		        	console.log("调用删除接口1");
	        	 	       		       					 committing(dom.id);
	        	 	       		    			}else{
	        	 	       		        	$(this).children().children(".courseEm").text("添加到课表");
	        	 	       		        	console.log("调用添加接口1");
	        	 	       		        				withdraw(dom.id);	
	        	 	       		    		}
	        	 	       				})
	        	 	       		}else{
	        	 	       			$('.addCourseDiv').append("<div class='courseInfo'><p class='courseN'>"+dom.courseName+"</p><a href='javascript:;' class='setCourseA' id="+index1+"><div class='setCourse delC'><span class='courseEm'>删除</span></div></a><p class='courseItem'><img src='../image/teacher.png' alt=''><span>老师：</span><span>"+dom.js+"</span></p><p class='courseItem'><img src='../image/courseT.png' alt=''><span>时间：</span><span>"+finalSpec+"</span></p><p class='courseItemLast'><img src='../image/courseP.png' alt=''><span>教室：</span><span>"+dom.room+"</span></p></div>");
	        	 	       				$('#'+index1).click(function(){
    	 	       							$(this).children('.setCourse').toggleClass("addC").toggleClass("delC");
    	 	       							if($(this).children().children(".courseEm").text()=="添加到课表"){
    	 	       				        				$(this).children().children(".courseEm").text("删除");
    	 	       				        			 committing(dom.id);
    	 	       				        			console.log("调用删除接口2");
    	 	       				    			}else{
    	 	       				        				$(this).children().children(".courseEm").text("添加到课表");
    	 	       				        			console.log("调用添加接口2");
    	 	       				        				withdraw(dom.id);
    	 	       				        				
    	 	       				   			 }
    	 	       							
    	 	       						})
	        	 	       		}
	        	 	       		
	        	 	       		
	        	 	       		
	        	 	       	})
	        	 	       
	        	 	       	 
	        	 	        }
	        	 		 })
	        	 		 
  	       }
 		 }) 
	        	 	
//........................end
		
  	     
 })
 
 var committing=function(id){
	 var spanurl=cutUrl()+"/api/course/addToSchedule";
  	 var spanmes='{"kcDetailsId":"'+id+'"}';
	
  		 $.ajax({
  	         "dataType": 'json',
  	         "type": "POST",
  	         "url": spanurl,
  	         "data": spanmes,
  	         "contentType":"application/json;charset=utf-8",
  	         "success": function (data, textStatus, jqXHR){
  	        	 var raw=JSON.stringify(data);
  	        	 
  	         }
  		 })
 }
 
 var withdraw=function(id){
	 var spanurl=cutUrl()+"/api/course/removeSchedule";
  	 var spanmes='{"kcDetailsId":"'+id+'"}';
  	
  		 $.ajax({
  	         "dataType": 'json',
  	         "type": "POST",
  	         "url": spanurl,
  	         "data": spanmes,
  	         "contentType":"application/json;charset=utf-8",
  	         "success": function (data, textStatus, jqXHR){
  	        	 var raw=JSON.stringify(data);
  	        	
  	         }
  		 })
 }

 var convertWeek=function(val){
	 if(val==1){
		 return '周一';
	 }else if(val==2){
		 return '周二';
	 }else if(val==3){
		 return '周三';
	 }else if(val==4){
		 return '周四';
	 }else if(val==5){
		 return '周五';
	 }else if(val==6){
		 return '周六';
	 }else if(val==7){
		 return '周天';
	 }
 }
 
 var convertTerm=function(val){
	 if(val=='第一学期'){
		 return 1;
	 }else if(val=='第二学期'){
		 return 2;
	 }
 }
 
 var commiting=function(url,mes){
	   
		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "async":false,
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	var raw=JSON.stringify(data);
	        	console.log(raw);
	        	raw=$.parseJSON(raw);
	        
	        	 
	         }
		 })
}
 
 
 var duration=function(spanset,start,end){
	 console.log(start+' '+end);
	   var starttime='';
	   var endtime='';
	   for(i=0;i<spanset.length;i++){
		   
		  
		   var spanunit=spanset[i].split(',');
		  
		  
		   if(spanunit[0]==start){
			   starttime=spanunit[1];
		   }
		   if(spanunit[0]==end){
			   endtime=spanunit[2];
		   }
		   
		   
	   }
	   
	   var returnval=starttime+'-'+endtime;
	   return returnval;
	   
 }
 
 var singleDura=function(spanset,series){
	 
	   var realSeries=series-1;
	   return spanset[realSeries];
	   
}