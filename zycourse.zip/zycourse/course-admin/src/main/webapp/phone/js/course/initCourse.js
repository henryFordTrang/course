$(function(){
	  var fid=localStorage.fid;
	  var uid=localStorage.uid;	  
	  var school=localStorage.school1;
	  var userId=localStorage.userId;
	 // var chooser=localStorage.proceedingChooser;
	  //var proceedingDate=localStorage.proceedingDate;
	  

	  
	  var bterm=false;

	  
	$('#sysip').click(function(){
		
		$(this).parent('li').addClass('cur');
		$('#mnip').parent('li').removeClass('cur');
		 $('#item1').css('display','block');
		$('#item2').css('display','none'); 
		
		
	})
	
	$('#mnip').click(function(){
		
		$(this).parent('li').addClass('cur');
		$('#sysip').parent('li').removeClass('cur');
		 $('#item2').css('display','block');
		$('#item1').css('display','none'); 
		
		
	})
	
	var isSelected=true;
	$('.selectA').click(function(){
	    isSelected=!isSelected;
	    if(isSelected){
	        $(this).children('.img1').attr("src","../image/pwd.png");
	    }else{
	       $(this).children('.img1').attr("src","../image/unPwd.png"); 
	    }

	})
	$('#import').click(function(){
	    $(this).toggleClass("unInput").toggleClass("import");
	})
	$('.ipt').keyup(function(){
	    if($(this).val()==""){
	        $(this).removeClass("ipting").addClass("orgIpt"); 
	        $(".searchImg").show();
	        $(".searchImg1").hide();
	   }else{
	        $(this).removeClass("orgIpt").addClass("ipting");
	        $(".searchImg").hide();
	        $(".searchImg1").show();
	    }
	});
	$(".searchA").click(function(){
	    $('.addCourseDiv').show();
	    $('.courseUl').hide();
	})
	$(".cliA").click(function(){
		
	    $('.addCourseDiv').show();
	    $('.courseTimeUl').hide();
	})
	$('.setCourseA').click(function(){
	    $(this).children('.setCourse').toggleClass("addC").toggleClass("delC");
	    if($(this).children().children(".courseEm").text()=="添加到课表"){
	        $(this).children().children(".courseEm").text("删除");
	    }else{
	        $(this).children().children(".courseEm").text("添加到课表");
	    }
	})
	
	$('.menu_l').click(function(){
		//localStorage.removeItem('proceedingChooser');
		//localStorage.removeItem('proceedingDate');
		window.location="term.html";
	})
	
	/*$('#import').click(function(){
		localStorage.removeItem('proceedingChooser');
		localStorage.removeItem('proceedingDate');
		window.location="blankterm.html";
	})*/
	
	
	$('#addTime').click(function(){
		
		window.location="initNewCourse.html";
	})
	
	$('#menu_r').click(function(){
		//localStorage.removeItem('proceedingChooser');
		//localStorage.removeItem('proceedingDate');
		window.location="blankterm.html";
	})
	
	$('#forward').click(function(){
		//localStorage.removeItem('proceedingChooser');
		//localStorage.removeItem('proceedingDate');
		window.location="term.html";
	})
	
	/*$('#term').click(function(){
		if($('#yearterm').children('.liItem').children('em').text().length==0){
			alert('请先选择入学年份');
		}
	})*/
	
	//....日期控件
	var numArr=[];
    var courseFigureArr=[];  
    var starttime='';
    
	 var calendar1 = new datePicker();
        calendar1.init({
        'trigger': '#code2', /*按钮选择器，用于触发弹出插件*/
        'type': 'ym',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
        'minDate':'1900-1-1',/*最小日期*/
        'maxDate':'2100-12-31',/*最大日期*/
        'onSubmit':function(){/*确认时触发事件*/
            var theSelectData=calendar1.value;
            //...
            
            generateArr(calendar1.value);	
            
    },
    'onClose':function(){/*取消时触发事件*/
      
      
        var url=cutUrl()+"/api/course/insertFirstTimeOfSchool";
		var mes='{"userId":"'+userId+'","rxny":"'+calendar1.value+'"}';
		 
			 $.ajax({
		         "dataType": 'json',
		         "type": "POST",
		         "url": url,
		         "data": mes,
		         "contentType":"application/json;charset=utf-8",
		         "success": function (data, textStatus, jqXHR){
		        	
		        	 var raw=JSON.stringify(data);
		        	console.log(raw);
		        	 raw=$.parseJSON(raw);
		        	 if(raw.error.id=='0000'){
		        		 $('#menu_r').css('display','block');
		        		  $('#yearterm').children('.liItem').children('em').html(calendar1.value);
		        		  //localStorage.proceedingDate=calendar1.value;
		        		 
		        	 }else{
		        		
		        	 }
		         }
			 })
       
    },
    'onClear':function(){
    	
        
        }
      });
        
    
        
    
        
        $.ajax({
	  		"dataType": 'json',
	  		"type": "GET",
	  		"async":false,
	 		"url": cutUrl()+"/api/course/getUserCourseInfo",
	  		"data": {"userId":userId},
	  		"contentType":"application/json;charset=utf-8",
	  		"success": function (data, textStatus, jqXHR){
	  			var raw=JSON.stringify(data);
	  			//console.log(raw);
	  			raw=$.parseJSON(raw);
	  			if(raw.error.id=='0000'){
	  				if(raw.rxny==''||raw.rxny==null||raw.rxny=='null'){
		  				
		  				$('#code2').trigger('click');	
		  				
		  				
		  				
		  				$('#sysip').parent('li').addClass('cur');
			  			$('#item1').css('display','block');
			  			$('#mnip').parent('li').removeClass('cur');
			  			$('#item2').css('display','none');
		  				
		  			}else{
		  				
		  				if(raw.hasXq==1){
		  					
		  					$('#term').children('div').children('em').text(termCalculate(raw.xq,raw.xn,raw.rxny));
		  					$('#forward').css('display','block');
		  					$('#menu_r').css('display','none');
		  					
		  				}else{
		  					
		  					$('#forward').css('display','none');
		  					$('#menu_r').css('display','block');
		  					
		  				}
		  					
		  				generateArr(raw.rxny);	
		  				    
		  			  
		  				
		  			}
	  			}else{
	  				//alert(raw.error.message);
	  				$.MsgBox.Alert('温馨提示',raw.error.message);
	  			}
	  			
	  			
	  			
	  		}
	  })
	  
	  
	  
	
	
    
    //手动添加课程页面
    
      var courseurl=cutUrl()+"/api/course/qryCourseName";
	  var coursemes='{"userId":"'+userId+'","courseName":"","js":"","xnxqId":""}';
	  
			 $.ajax({
		         "dataType": 'json',
		         "type": "POST",
		         "url": courseurl,
		         "data": coursemes,
		         "contentType":"application/json;charset=utf-8",
		         "success": function (data, textStatus, jqXHR){
		        	 var raw=JSON.stringify(data);		
		        	
		        	 raw=$.parseJSON(raw);
		        	 $.each(raw.kcDetailsList,function(i,dom){
		        		 var clsseries=i+1;
		        		 var index='id'+dom.id;
		        		 
		        		 $('.courseTimeUl').append("<li class='line'><a href='javascript:;' class='cliA' id="+index+"><div class='liItem'><span>"+dom.courseName+"</span><img src='../image/go.png' alt=''></div></a></li>");
		        	 	 $('#'+index).click(function(){
		        	 		window.location='courseBreakDown.html';
		        	 		localStorage.breakdownCourse=dom.courseName;
		        	 	 })
		        	 })
		        	 
		        	 $('#searchC').bind("input propertychange",function(){
		        		 var searchTerm=$(this).val();	
		        		 var counting=0;
		        		 $('.courseTimeUl').empty();
		        		 $.each(raw.kcDetailsList,function(i,dom){
		        			 counting++;
		        			 var index='cherry'+counting;
		        			 
		        			 if(dom.courseName.indexOf(searchTerm)>-1){
		        				
		        				 $('.courseTimeUl').append("<li class='line'><a href='javascript:;' class='cliA' id="+index+"><div class='liItem'><span>"+dom.courseName+"</span><img src='../image/go.png' alt=''></div></a></li>");
				        	 	 $('#'+index).click(function(){
				        	 		window.location='courseBreakDown.html';
				        	 		localStorage.breakdownCourse=dom.courseName;
				        	 	 })
		        			 }
			        		 
			        	 })
			        	 
			        	 $('.courseTimeUl').append('<div class="submit2 cancelCon"><input type="submit" value="创建课程" id="addTime" class="add"><a class="addA" href="javascript:;"><img id="addImg" src="../image/add.png" alt=""></a></div>');
		        		 $('#addTime').click(function(){
		        			 window.location="initNewCourse.html";
		        		 })
		        		 
		        		 
		        	 })
		        	 
		        	 
		        	 
		         }
			 })
			 
			 
			
			
	
})

//根据入学年月，学年计算 大几
var termCalculate=function(term,dur,entering){
	
	//console.log(term+' '+dur+' '+entering);
	dur=dur.split('-');
	entering=entering.split('-');
	var grade=dur[0]-entering[0]+1;
	var dura=dur[0]+'年-'+dur[1];
	var term=revoTerm(term);
	if(term==2){
		grade=grade+1;
	}
	grade=gradeConvert(grade);
	
	console.log();
    	
    return dura+' '+grade+' '+term;	
    	
   
	
}

//根据入学年月生成学期信息
var generateArr=function(enterDate){
	  var entering='入学时间'+enterDate;
      starttime=enterDate;
      starttime=starttime.substring(0,4);        
      starttime=parseInt(starttime)-6;
      numArr=[];
      courseFigureArr=[];
      for(var i=0;i<15;i++){
      	if(i>=5&&i<10){
      		starttime++;
      		var grading=i-4;
      		var grade='';
      		if(grading==1){
      			grade='一';
      		}
      		if(grading==2){
      			grade='二';
      		}
      		if(grading==3){
      			grade='三';
      		}
      		if(grading==4){
      			grade='四';
      		}
      		if(grading==5){
      			grade='五';
      		}
          	var st=starttime+1;        	
          	var starttimeplus=starttime+'年-'+st+'年'+'       大'+grade;
          	courseFigureArr.push(starttimeplus);
      	}else{
      		starttime++;
          	var st=starttime+1;        	
          	var starttimeplus=starttime+'年-'+st+'年';
          	courseFigureArr.push(starttimeplus);
      	}
      	
      	
      }
      bgettime=false;
      
     // console.log(courseFigureArr+' '+entering);
      revealchooser(courseFigureArr,entering); 
}

var resetCurrentWeek=function(){
	userId=localStorage.userId;
	var resetUrl=cutUrl()+"/api/course/resetCurrentZs";
	var mes={"userId":userId};
	$.ajax({
        "dataType": 'json',
        "type": "GET",
        "async":false,
        "url": resetUrl,
        "data": mes,
        "contentType":"application/json;charset=utf-8",
        "success": function (data, textStatus, jqXHR){
        	var raw=JSON.stringify(data);
        	console.log(raw);
        	raw=$.parseJSON(raw);
        	
        }
	})
	
}

var revealchooser=function(courseFigureArr,entering){
	  
 	  var courseArr=['','','','',''];
 	  var spaceArr=[' ',' ',' ',' ',' ',' ',' '];	  
 	  var hourFigureArr=['第一学期','第二学期']; 	  
 	  var mobileSelect3 = new MobileSelect({
 				
 			    trigger: '#term',
 			    type:'newterm',
 			    org:'yes',
 			    title: entering,
 			    wheels: [
 			              
 			                {data: courseFigureArr},
 			                {data: courseArr},
 			                {data: spaceArr},
 			                {data: hourFigureArr}
 			               
 			              
 			            ],
 			    position:[5, 4, 2, 0, 2], 
 			    transitionEnd:function(indexArr, data){
 			    	//console.log(indexArr+'---'+data);
 			    	
 			    	var wheelIndex=0;
 			    	$('.wheels').children('.wheel').each(function(){
 			    		wheelIndex++;
 			    		if(wheelIndex==1){
 			    			var wIndex=0;
 			    			$(this).children('.selectContainer').children('li').each(function(){
 			    				wIndex++;
 			    				if(wIndex-1==indexArr[0]){
 			    					$(this).css('color','black');
 			    				}else{
 			    					$(this).css('color','grey')
 			    				}
 			    			})
 			    			
 			    		}else if(wheelIndex==4){
 			    			var wlIndex=0;
 			    			$(this).children('.selectContainer').children('li').each(function(){
 			    				wlIndex++;
 			    				if(wlIndex-1==indexArr[3]){
 			    					$(this).css('color','black');
 			    				}else{
 			    					$(this).css('color','grey')
 			    				}
 			    			})
 			    		}
 			    	})
 			        
 			    },
 			    callback:function(indexArr, data){
 			    	
 			    	var forshow=data[0]+' '+data[3];
 			    	
					
 			    	var reg =/[\u4e00-\u9fa5]/g;
 			    	var year=data[0].replace(reg,"");
 			    	year=year.replace(/(^\s*)|(\s*$)/g, "");
 			    	var yt=data[1]+' '+year;			    
 			      
 			        var sbterm=convertTerm(data[3]);
 			       
 			       var userId=localStorage.userId;
 			       var url=cutUrl()+"/api/course/createXq";	 
 			       var mes='{"userId":"'+userId+'","xn":"'+year+'","xq":"'+sbterm+'"}';
 			       commiting(url,mes,forshow);
 			   
 			    }
 			});
 	  			markS();
 }

	var markS=function(){
		var wheelIndex=0;
	    	$('.wheels').children('.wheel').each(function(){
	    		wheelIndex++;
	    		if(wheelIndex==1){
	    			var wIndex=0;
	    			$(this).children('.selectContainer').children('li').each(function(){
	    				wIndex++;
	    				if(wIndex-1==5){
	    					$(this).css('color','black');
	    				}else{
	    					$(this).css('color','grey')
	    				}
	    			})
	    			
	    		}else if(wheelIndex==4){
	    			var wlIndex=0;
	    			$(this).children('.selectContainer').children('li').each(function(){
	    				wlIndex++;
	    				if(wlIndex-1==0){
	    					$(this).css('color','black');
	    				}else{
	    					$(this).css('color','grey')
	    				}
	    			})
	    		}
	    	})
	}
 
 var convertTerm=function(val){
	 if(val=='第一学期'){
		 return 1;
	 }else if(val=='第二学期'){
		 return 2;
	 }
 }
 
 var revoTerm=function(val){
	 if(val==1){
		 return '第一学期';
	 }else if(val==2){
		 return '第二学期';
	 }
 }
 
 var gradeConvert=function(val){
	 if(val==1){
		 return '大一';
	 }else if(val==2){
		 return '大二';
	 }else if(val==3){
		 return '大三';
	 }else if(val==4){
		 return '大四';
	 }else if(val==5){
		 return '大五';
	 }
 }
 
 var submitDate=function(userId,smDate){
	 var url=cutUrl()+"/api/course/insertFirstTimeOfSchool";
		var mes='{"userId":"'+userId+'","rxny":"'+smDate+'"}';
		 
			 $.ajax({
		         "dataType": 'json',
		         "type": "POST",
		         "url": url,
		         "data": mes,
		         "contentType":"application/json;charset=utf-8",
		         "success": function (data, textStatus, jqXHR){
		        	
		        	 var raw=JSON.stringify(data);
		        	
		        	 raw=$.parseJSON(raw);
		        	 if(raw.error.id=='0000'){
		        		 $('#menu_r').css('display','block');
		        		  $('#yearterm').children('.liItem').children('em').html(calendar1.value);
		        		 // localStorage.proceedingDate=calendar1.value;
		        		 
		        	 }else{
		        		
		        	 }
		         }
			 })
 }
 
 var commiting=function(url,mes,forshow){
	   
		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "async":false,
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	var raw=JSON.stringify(data);
	        	//console.log(raw);
	        	raw=$.parseJSON(raw);
	        	if(raw.error.id=='0000'){
	        		resetCurrentWeek();
	        		$('#menu_r').css('display','none');
	        		$('#forward').css('display','block');
	        		$('#term').children('.liItem').children('em').text(forshow);
	        		//localStorage.proceedingChooser=forshow;
	        		
	        	 }else{
	        		 //alert(raw.error.message);
	        		 $.MsgBox.Alert('温馨提示',raw.error.message);
	        	 }
	        	 
	        
	         }
		 })
}