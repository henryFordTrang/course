$(function(){
	
	var userId=localStorage.userId;
	var recommendCo=localStorage.recommandCo;	
	console.log(recommendCo);
	var cosListIndex=localStorage.cosListIndex;
	var delIndexList=localStorage.delIndexList;
	
	recommendCo=$.parseJSON(recommendCo);
	
	cosListIndex=cosListIndex.split(',');
	delIndexList=delIndexList.split(',');
	
	var realSet=[];
	var teacher='';
	$.each(recommendCo,function(i,dom){
		
		var select=false;
		$.each(delIndexList,function(j,dom1){
			
			if(dom.id==dom1){
				select=true;
			}
		})
		
		if(select){
			teacher+=dom.js+' ';
			realSet.push(dom);
		}
		
	})
	
	$('#teacher').text(teacher);
	
	$.each(realSet,function(i,dom){
		
		var j=parseInt(i)+1;
		var lesson=dom.courseName;
		$('.courseName').text(lesson);		
		var weekSeries=dataSet(dom.zc);
		$('.center').append("<input type='hidden' name='' value="+dom.id+" class='deleteId'>");
		var day=dom.xqs;
		day=weekConvert(day);
		var classset=dom.jcdm;
		classset=classset.split(',');
		if(weekSeries=='2,4,6,8,10,12,14,16,18,20,22,24'){
		  weekSeries='双'
		 }else if(weekSeries=='1,3,5,7,9,11,13,15,17,19,21,23,25'){
		   weekSeries='单'
		 }
		 
		var rawClsSeries=dom.jcdm;
		rawClsSeries=rawClsSeries.split(',');
		showClass=rawClsSeries[0]+'-'+rawClsSeries[rawClsSeries.length-1]
		         						
		var clsSeries=day+' '+showClass+'节';
		$('.center').append("<div class='courseInfo'><p class='courseTitle'>上课时间"+j+"</p><p class='courseItem'><img src='../image/courseP.png' alt=''><span>教室：</span><span>"+dom.room+"</span></p><p class='courseItem'><img src='../image/courseT.png' alt=''><span>时间：</span><span>"+clsSeries+"</span></p><p class='courseItemLast'><img src='../image/courseW.png' alt=''><span>周数：</span><span>"+weekSeries+"周</span></p></div>");
		
	})
	
	/*$.each(cosListIndex,function(i,dom){
		var j=parseInt(i)+1;
		var lesson=recommendCo[dom].courseName;
		$('.courseName').text(lesson);		
		var weekSeries=dataSet(recommendCo[dom].zc);
		$('.center').append("<input type='hidden' name='' value="+recommendCo[dom].id+" class='deleteId'>");
		var day=recommendCo[dom].xqs;
		day=weekConvert(day);
		var classset=recommendCo[dom].jcdm;
		classset=classset.split(',');
		if(weekSeries=='2,4,6,8,10,12,14,16,18,20,22,24'){
		  weekSeries='双'
		 }else if(weekSeries=='1,3,5,7,9,11,13,15,17,19,21,23,25'){
		   weekSeries='单'
		 }
		 
		var rawClsSeries=recommendCo[dom].jcdm;
		rawClsSeries=rawClsSeries.split(',');
		showClass=rawClsSeries[0]+'-'+rawClsSeries[rawClsSeries.length-1]
		         						
		var clsSeries=day+' '+showClass+'节';
		$('.center').append("<div class='courseInfo'><p class='courseTitle'>上课时间"+j+"</p><p class='courseItem'><img src='../image/courseP.png' alt=''><span>教室：</span><span>"+recommendCo[dom].room+"</span></p><p class='courseItem'><img src='../image/courseT.png' alt=''><span>时间：</span><span>"+clsSeries+"</span></p><p class='courseItemLast'><img src='../image/courseW.png' alt=''><span>周数：</span><span>"+weekSeries+"周</span></p></div>");
	})*/
	
	
	
	/*var lesson=recommendCo.courseName;
	$('.courseName').text(lesson);		
	var weekSeries=dataSet(recommendCo.zc);
	$('.center').append("<input type='hidden' name='' value="+recommendCo.id+" class='deleteId'>");
	var day=recommendCo.xqs;
	day=weekConvert(day);
	var classset=recommendCo.jcdm;
	classset=classset.split(',');
	if(weekSeries=='2,4,6,8,10,12,14,16,18,20,22,24'){
	  weekSeries='双'
	 }else if(weekSeries=='1,3,5,7,9,11,13,15,17,19,21,23,25'){
	   weekSeries='单'
	 }
	 
	var rawClsSeries=recommendCo.jcdm;
	rawClsSeries=rawClsSeries.split(',');
	showClass=rawClsSeries[0]+'-'+rawClsSeries[rawClsSeries.length-1]
	         						
	var clsSeries=day+' '+showClass+'节';
	$('.center').append("<div class='courseInfo'><p class='courseTitle'>上课时间</p><p class='courseItem'><img src='../image/courseP.png' alt=''><span>教室：</span><span>"+recommendCo.room+"</span></p><p class='courseItem'><img src='../image/courseT.png' alt=''><span>时间：</span><span>"+clsSeries+"</span></p><p class='courseItemLast'><img src='../image/courseW.png' alt=''><span>周数：</span><span>"+weekSeries+"周</span></p></div>");*/
	         					

		   	$('#del').click(function(){
		   		
		   	  $.MsgBox.Confirm("温馨提示", "确认在课表中删除此课程吗?", function () {
		   		var deleteS=[];
   				$('input[type=hidden]').each(function(){
   					var trashid=$(this).val();
   					deleteS.push(trashid);
   				})

   				deleteS='['+deleteS+']';
   				var delurl=cutUrl()+"/api/course/deleteCourses";
   				var delmes='{"idList":'+deleteS+'}';

   				$.ajax({
         			"dataType": 'json',
         			"type": "POST",
         			"url": delurl,
         			"data": delmes,
         			"contentType":"application/json;charset=utf-8",
         			"success": function (data, textStatus, jqXHR){
         				var raw=JSON.stringify(data);
         				
         				raw=$.parseJSON(raw);
         				if(raw.error.id=="0000"){
         					
         					window.location="term.html";
         				}else{
         					//alert(raw.error.message);
         					$.MsgBox.Alert('温馨提示',raw.error.message);
         				}
         			}
   				})
		   		  
		   	  }, function () {
		   		  
		   		  return;
		   		  
		   	  })
		   		
		   		/*var cfm=confirm('确认在课表中删除此课程吗?');
		   		if(!cfm){
		   			return;
		   		}
		   		
   				var deleteS=[];
   				$('input[type=hidden]').each(function(){
   					var trashid=$(this).val();
   					deleteS.push(trashid);
   				})

   				deleteS='['+deleteS+']';
   				var delurl=cutUrl()+"/api/course/deleteCourses";
   				var delmes='{"idList":'+deleteS+'}';
			    
   				$.ajax({
         			"dataType": 'json',
         			"type": "POST",
         			"url": delurl,
         			"data": delmes,
         			"contentType":"application/json;charset=utf-8",
         			"success": function (data, textStatus, jqXHR){
         				var raw=JSON.stringify(data);
         				console.log(raw);
         				raw=$.parseJSON(raw);
         				if(raw.error.id=="0000"){
         					
         					window.location="term.html";
         				}else{
         					alert(raw.error.message);
         				}
         			}
   				})*/
   				
		   	})  
		   	
		   	
		   	
			
		   	$('.menu_r').click(function(){
		   		window.location='courseEdit.html';
		   	})
		   	
		   	$('.menu_l').click(function(){
			window.location='addCoDetail.html';
			})
			
		})
		
		var weekConvert=function(val){
			if(val==1){
				return '周一';
			}else if(val==2){
				return '周二';
			}else if(val==3){
				return '周三';
			}else if(val==4){
				return '周四';
			}else if(val==5){
				return '周五';
			}else if(val==6){
				return '周六';
			}else if(val==7){
				return '周天';
			}
		}
		//连续数字用'-'相连
		var dataSet=function(chooseArr){
			
		    var arrInfo="";
				/* for(var x=0;x<chooseArr.length;x++){
					 arrInfo+=chooseArr[x]+',';
				 }*/
				 arrInfo=chooseArr;/*.substring(0,arrInfo.length-1);*/
				
				 var infoArr=arrInfo.split(",");
				    var rres="";
				    var res=fn(infoArr);
				    for (var i = 0; i < res.length; i++) {
				        var item=res[i];
				        if(item.length==1){
				            rres+=item[0]+",";
				        }else{
				            rres+=item[0]+"-"+item[item.length-1]+",";
				        }
				        
				    }
				    rres=rres.substring(0,rres.length-1);
				    return rres;
		}
		
		 var fn=function(arr){
			   var result = [],
			       i = 0;
			   result[i] = [arr[0]];
			   arr.reduce(function(prev, cur){
			     cur-prev === 1 ? result[i].push(cur) : result[++i] = [cur];
			     return cur;
			   });
			  
			   return result;
			 }
		
		//计算上课时间
		var duraCal=function(paraset,val){
			
			if(val==1){
				var rawVal=paraset[0];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==2){
				var rawVal=paraset[1];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==3){
				var rawVal=paraset[2];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==4){
				var rawVal=paraset[3];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==5){
				var rawVal=paraset[4];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==6){
				var rawVal=paraset[5];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==7){
				var rawVal=paraset[6];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==8){
				var rawVal=paraset[7];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==9){
				var rawVal=paraset[8];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==10){
				var rawVal=paraset[9];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==11){
				var rawVal=paraset[10];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==12){
				var rawVal=paraset[11];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==13){
				var rawVal=paraset[12];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==14){
				var rawVal=paraset[13];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}else if(val==15){
				var rawVal=paraset[14];
				rawVal=rawVal.split('-');
				return rawVal[0];
			}
			
			
			
		}
		
		
		//计算上课时间
		var duraEndCal=function(paraset,val){
			
			if(val==1){
				var rawVal=paraset[0];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==2){
				var rawVal=paraset[1];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==3){
				var rawVal=paraset[2];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==4){
				var rawVal=paraset[3];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==5){
				var rawVal=paraset[4];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==6){
				var rawVal=paraset[5];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==7){
				var rawVal=paraset[6];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==8){
				var rawVal=paraset[7];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==9){
				var rawVal=paraset[8];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==10){
				var rawVal=paraset[9];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==11){
				var rawVal=paraset[10];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==12){
				var rawVal=paraset[11];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==13){
				var rawVal=paraset[12];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==14){
				var rawVal=paraset[13];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}else if(val==15){
				var rawVal=paraset[14];
				rawVal=rawVal.split('-');
				return rawVal[1];
			}
			
			
			
		}
		
		 //判断全部，单双周选择个数
        var judgeSingleOrPair=function(){
            var singleTotalNum=0;
            var pairTotalNum=0;
            var totalNum=0;
            $('.flag').each(function(){//全部
                totalNum+=parseInt($(this).val());
            })
            $('.fPair').each(function(){//双周
                pairTotalNum+=parseInt($(this).val());
            })
            $('.fSingle').each(function(){//单周
                singleTotalNum+=parseInt($(this).val());
            })
            
            console.log('single:'+singleTotalNum+' multiple:'+pairTotalNum+' all:'+totalNum);
            $('.odder').removeClass('odder_selected');
            if(totalNum==25){
                $('.odder1').addClass('odder_selected');
                return 'all';
            }
            if(singleTotalNum==13&&pairTotalNum==0){
               $('.odder3').addClass('odder_selected'); 
               return 'single';
            }
            if(pairTotalNum==12&&singleTotalNum==0){
               $('.odder2').addClass('odder_selected'); 
               return 'multiple';
            }
            //console.log(totalNum+" "+singleTotalNum+" "+pairTotalNum);
        }
		
		//数组删除重复元素
		function unique5(array){
			 var r = [];
			 for(var i = 0, l = array.length; i < l; i++) {
			  for(var j = i + 1; j < l; j++)
			   if (array[i] === array[j]) j = ++i;
			  r.push(array[i]);
			 }
			 return r;
			}