$(function(){
			 
	 var userId=localStorage.userId;
	 var fid=localStorage.fid;
	 var reg =/[\u4e00-\u9fa5]/g;
	 var weekLocate='';
	 var initStartTime='';
	 var initTermTime='';
	$(".menu_l").click(function(){
		
		 var url=cutUrl()+"/api/course/saveCourseSetting";
		 var mes='{"userId":"'+userId+'"}';
		 	
		 	
		 
		    var degreesb=$('#degree').children('.liItem').children('em').text();
		    //var currtsb=$('#currt').children('.liItem').children('em').text();
		    var currtsb=$('#currt').children('.currValue').val();
		    var termstartsb=$('#termstart').children('.liItem').children('em').text();
		    var currwsb=$('#currw').children('.liItem').children('em').text();
		    var beginwithsb=$('#beginwith').children('.liItem').children('em').text();
		    var maxclasssb=$('#maxclass').children('.liItem').children('em').text();
		    var termrgsb=$('#termrg').children('.liItem').children('em').text();
		    var scsb=$('#sc').children('.liItem').children('em').text();
		    var deansb=$('#dean').children('.liItem').children('em').text();
		    var termsb=$('#currt').children('.duraValue').val();
		    
		  
		    
		   // currtsb=currtsb.split(" ");
		    //console.log(currtsb[1]);
		    var reg=/[\u4e00-\u9fa5]/g;
		    //currtsb=currtsb[0].replace(reg,'');
		    currwsb=currwsb.replace(reg,'');
		    
		    beginwithsb=interpret(beginwithsb);
		   // beginwithsb=beginwithsb.replace(reg,'');
		    maxclasssb=maxclasssb.replace(reg,'');
		    
		    var cmurl=cutUrl()+"/api/course/saveCourseSetting";		   
			var cmmes='{"userId":"'+userId+'","schoolName":"'+scsb+'","department":"'+deansb+'","userxl":"'+degreesb+'","xn":"'+termsb+'","xq":"'+currtsb+'","kxsj":"'+termstartsb+'","dqzs":"'+currwsb+'","weekStart":'+beginwithsb+',"jcMax":"'+maxclasssb+'","rxny":"'+termrgsb+'","fid":"'+fid+'"}';
		    //var cmmes='{"userId":"'+userId+'","schoolName":"'+scsb+'","department":"'+deansb+'","userxl":"'+degreesb+'","kxsj":"'+termstartsb+'","dqzs":"'+currwsb+'","weekStart":'+beginwithsb+',"jcMax":"'+maxclasssb+'","rxny":"'+termrgsb+'","fid":"'+fid+'"}';
			
			
			var message='{"kbSettingsInfo":'+cmmes+'}';   

				 $.ajax({
			         "dataType": 'json',
			         "type": "POST",
			         "url": cmurl,
			         "data": message,
			         "contentType":"application/json;charset=utf-8",
			         "success": function (data, textStatus, jqXHR){
			        	
			        	 localStorage.removeItem('classlength');
			     		window.location="term.html";
			         }
				 })
		    
		
		
	})
	
	$('#sc').click(function(){
		if(fid==0){
			var cfm=confirm('修改学校将丢失之前学校的课表');
			if(cfm){
				//clearance(userId);
				
				window.location="modifySchool.html";
			}
			
		}else{
			//alert('机构用户不允许修改学校及学院信息');
			$.MsgBox.Alert('温馨提示','机构用户不允许修改学校及学院信息');
		}
	
		
	})

	$('#dean').click(function(){
		if(fid==0){
			var cfm=confirm('修改学校将丢失之前学校的课表');
			if(cfm){
				//clearance(userId);
				
				window.location="modifySchool.html";
			}
			
			
		}else{
			//alert('机构用户不允许修改学校及学院信息');
			$.MsgBox.Alert('温馨提示','机构用户不允许修改学校及学院信息');
		}
	})
	

	$('#classdura').click(function(){
		window.location="clsDuraSet.html";
	})
	
	
	
	 var url=cutUrl()+"/api/course/qryKbSettingsInfo";
	 var mes='{"userId":"'+userId+'"}';

		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	 
	        	 var raw=JSON.stringify(data);
	        	 //console.log(raw)
	        	 raw=$.parseJSON(raw);
	        	 if(raw.error.id=='0000'){
	        		 
	        		 //var registdate=raw.kbSettingsInfo.rxny;
	        		 //var enteringdate=raw.kbSettingsInfo.kxsj;
	        		 var term=raw.kbSettingsInfo.xq;
	        		 
	        		 var userDegree=raw.kbSettingsInfo.userxl;
	        		 if(userDegree==null){
	        			 userDegree='本科';
	        		 }
	        		 

	        		 
	        		var currentTerm=termCal(raw.kbSettingsInfo.kxsj,raw.kbSettingsInfo.rxny,raw.kbSettingsInfo.xq)
	        		
	        		
	        		if(raw.kbSettingsInfo.xn==null||raw.kbSettingsInfo.xn=='null'||raw.kbSettingsInfo.xn==''){
	        			currentTerm='';
	        		}else{
	        			currentTerm=raw.kbSettingsInfo.xn+' '+currentTerm;
	        		}
	        		
	        		 initTermTime=raw.kbSettingsInfo.rxny;
	        		 initStartTime=raw.kbSettingsInfo.kxsj;
	        		 
	        		 startTimeListener(initTermTime);
	        		 termListener(initStartTime);
	        		 
	        		 weekSelector(parseInt(raw.kbSettingsInfo.dqzs)-1);
	        		 weekBeginwith(parseInt(raw.kbSettingsInfo.weekStart)-1);
	        		 maxmumClass(parseInt(raw.kbSettingsInfo.jcMax)-1);
	        		 var currweek='第'+raw.kbSettingsInfo.dqzs+'周';
	        		 weekLocate=parseInt(raw.kbSettingsInfo.dqzs);
	        		 var wseries=figureToCn(raw.kbSettingsInfo.weekStart);
	        		 var beginwith='周'+wseries;
	        		 localStorage.classlength=raw.kbSettingsInfo.jcMax;
	        		 $('#degree').children('.liItem').children('em').text(userDegree);
	        		 /*if(realterm.replace(reg,'')==null||realterm.replace(reg,'')=='null'){
	        			 realterm='';
	        		 }*/
	        		 $('#currt').children('.liItem').children('em').text(currentTerm);
	        		 
	        		 
	        		 if(raw.kbSettingsInfo.kxsj==null||raw.kbSettingsInfo.kxsj=='null'){
	        			 $('#termstart').children('.liItem').children('em').text('');
	        		 }else{
	        			 $('#termstart').children('.liItem').children('em').text(raw.kbSettingsInfo.kxsj);
	        		 }
	        		 
	        		 var juding=currweek.substring(1,currweek.length-1);
	        		 
	        		 if(juding==null||juding=='null'){
	        			 currweek='';
	        		 }
	        		 
	        		 $('#currw').children('.liItem').children('em').text(currweek);
	        		 $('#beginwith').children('.liItem').children('em').text(beginwith);
	        		 $('#maxclass').children('.liItem').children('em').text(raw.kbSettingsInfo.jcMax);
	        		 $('#termrg').children('.liItem').children('em').text(raw.kbSettingsInfo.rxny);
	        		 $('#sc').children('.liItem').children('em').text(raw.kbSettingsInfo.schoolName);
	        		 $('#dean').children('.liItem').children('em').text(raw.kbSettingsInfo.department);
	        		 $('#currt').append("<input type='hidden' class='duraValue' value="+raw.kbSettingsInfo.xn+">");
	        		 $('#currt').append("<input type='hidden' class='currValue' value="+raw.kbSettingsInfo.xq+">");
	        		 
	        		 var suburl=cutUrl()+"/api/course/queryXnxqInfo";
	        		 var submes={"userId":userId};
	        		 var setup=[];
	        		 $.ajax({
	        	         "dataType": 'json',
	        	         "type": "GET",
	        	         "url": suburl,
	        	         "data": submes,
	        	         "contentType":"application/json;charset=utf-8",
	        	         "success": function (data, textStatus, jqXHR){
	        	        	
	        	        	 var subraw=JSON.stringify(data);
	        	        	 subraw=$.parseJSON(subraw);
	        	        	 $.each(subraw.xnxqInfoList,function(i,dom){
	        	        		 var yeardura=dom.xn;
	        	        		 var yearregi=dom.rxny;
	        	        		 yeardura=yeardura.split('-');
	        	        		 yeardura=yeardura[0];
	        	        		 yearregi=yearregi.split('-');
	        	        		 yearregi=yearregi[0];
	        	        		 var gradeset='';
	        	        		 var termdura=dom.xq;
	        	        		 if(dom.xq==1){
	        	        			 gradeset=yeardura-yearregi;
	        	        		 }else{
	        	        			 gradeset=yeardura-yearregi-1;
	        	        		 }
	        	        		 setup.push(dom.xn+' '+'大'+gradeset+' '+'第'+dom.xq+'学期');
	        	        		 
	        	        	 })
	        	        	
	        	        	
	    	        		// createSlider(setup);
	        	         }
	        		
	        		 })
	        		 
	        		 //$('#currt').children('.liItem').children('em').text(raw.kbSettingsInfo.userxl);
	        	 }
	        	 
	        	 
	        	 
	         }
		 })
	
	
        
        
    
           
           
           /*var maxclass=['1节','2节','3节','4节','5节','6节','7节','8节','9节','10节','11节','12节'];
        	 var mobileSelect3 = new MobileSelect({
        			
        		    trigger: '#maxclass',
        		    type:'maxclass',
        		    title: '设置最大节数',
        		    wheels: [
        		                {data: maxclass},
        	
        		            ],
        		    position:[2, 2, 2, 2, 2], 
        		    transitionEnd:function(indexArr, data){
        		       var forshow='设置最大节数为：'+data[0];
        		       $('#maxclassTitle').text(forshow);
        		       
        		    },
        		    callback:function(indexArr, data){
        		    	data=JSON.stringify(data);
        		    	data=data.replace(/[^0-9]/g,'');        		    	
        		        localStorage.classlength=data;
        		    }
        		});
           */
        	 
         
         /*var weekbegin=['周一','周二','周三','周四','周五','周六','周日'];
      	 var mobileSelect3 = new MobileSelect({
      			
      		    trigger: '#beginwith',
      		    type:'beginwith',
      		    title: '设置每周起始日',
      		    wheels: [
      		                {data: weekbegin},
      	
      		            ],
      		    position:[2, 2, 2, 2, 2], 
      		    transitionEnd:function(indexArr, data){
      		      
      		      var forshow="设置当前周为："+data[0];
      		    $('#beginwithTitle').text(forshow);
      		     
      		    },
      		    callback:function(indexArr, data){
      		        
      		    }
      		});*/
	
	
	 
	 var numArr=['专科','本科','研究生','博士'];
	 var mobileSelect3 = new MobileSelect({
			
		    trigger: '#degree',
		    type:'degree',
		    title: '设置学历',
		    wheels: [
		                {data: numArr},
	
		            ],
		    position:[2, 2, 2, 2, 2], 
		    transitionEnd:function(indexArr, data){
		        console.log(data);
		        $('#degreeid').text('设置学历为：'+data[0])
		    },
		    callback:function(indexArr, data){
		        console.log(data);
		    }
		});
	 
	 
	 /*var weekInfo=['第1周','第2周','第3周','第4周','第5周','第6周','第7周','第8周','第9周','第10周','第11周','第12周','第13周','第14周','第15周','第16周','第17周','第18周','第19周','第20周','第21周','第22周','第23周','第24周'];
	 var mobileSelect3 = new MobileSelect({
			
		    trigger: '#currw',
		    type:'currw',
		    title: '设置当前周',
		    wheels: [
		                {data: weekInfo},
	
		            ],
		    position:[2, 2, 2, 2, 2], 
		    transitionEnd:function(indexArr, data){
		        var forshow='设置当前周为：'+data[0];
		        $('#currwTitle').text(forshow)
		    },
		    callback:function(indexArr, data){
		        console.log(data);
		    }
		});*/
	 
	 
      
	 
	  var createSlider=function(set){
		  
		  var numArr1=['2010年','2011年','2012年','2013年','2014年','2015年','2016年','2017年','2018年','2019年','2020年','2021年','2022年','2023年','2024年','2025年','2026年','2027年','2028年','2029年','2030年','2031年','2032年'];
	 	  var courseFigureArr=['-2010年','-2011年','-2012年','-2013年','-2014年','-2015年','-2016年','-2017年','-2018年','-2019年','-2020年','-2021年','-2022年','-2023年','-2024年','-2025年','-2026年','-2027年','-2028年','-2029年','-2030年','-2031年','-2032年'];
	 	  var courseArr=['大一','大一','大一','大一','高一','高二','高三'];
	 	  var spaceArr=[' ',' ',' ',' ',' ',' ',' '];
	 	  
	 	  var hourFigureArr=['第一学期','第二学期','第三学期','第四学期'];
	 	  
	 		 var mobileSelect3 = new MobileSelect({
	 				
	 			    trigger: '#currt',
	 			    type:'termSetup',
	 			    title: '',
	 			    wheels: [
	 			                {data: set},
	 			               
	 			               
	 			              
	 			            ],
	 			    position:[1, 9, 2, 2, 2], 
	 			    transitionEnd:function(indexArr, data){
	 			       // console.log(data);
	 			    },
	 			    callback:function(indexArr, data){
	 			       // console.log(data);
	 			    }
	 			});
	  }
	  
	  
	  $('#currt').click(function(){
		  window.location="deleteTerm.html";
	  })
     
    
})


		var calcMin=function(){
			var standard=new Date();
			var minDate=new Date();
			var maxDate=new Date();
			standard=standard.Format('yyyy-MM-dd');
			
			var year=standard.split('-')[0];
			year=parseInt(year);
			var minYear=year-4;
			var maxYear=year+8;
			
			minDate.setYear(minYear);
			minDate.setMonth(0);
			minDate.setDate(1);
			maxDate.setYear(maxYear);
			maxDate.setMonth(0);
			maxDate.setDate(1);
			minDate=minDate.Format('yyyy-MM-dd');
			maxDate=maxDate.Format('yyyy-MM-dd');
			
			
			return minDate;
		}
		
		var calcMax=function(){
			var standard=new Date();
			var minDate=new Date();
			var maxDate=new Date();
			standard=standard.Format('yyyy-MM-dd');
			
			var year=standard.split('-')[0];
			year=parseInt(year);
			var minYear=year-4;
			var maxYear=year+8;
			
			minDate.setYear(minYear);
			minDate.setMonth(0);
			minDate.setDate(1);
			maxDate.setYear(maxYear);
			maxDate.setMonth(0);
			maxDate.setDate(1);
			minDate=minDate.Format('yyyy-MM-dd');
			maxDate=maxDate.Format('yyyy-MM-dd');
			
			
			return maxDate;
		}

		var termListener=function(initStartTime){
			  //....日期控件
			 var minDate=calcMin();
			 var maxDate=calcMax();
			 
		  	 var calendar1 = new datePicker();
		          calendar1.init({
		          'trigger': '#termstart', /*按钮选择器，用于触发弹出插件*/
		          'type': 'date',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
		          'org':initStartTime,
		          'minDate':minDate,/*最小日期*/
		          'maxDate':maxDate,/*最大日期*/
		          'onSubmit':function(){/*确认时触发事件*/
		              var theSelectData=calendar1.value;
		               setting=false;
		              
		      },
		      'onClose':function(){/*取消时触发事件*/
		       
		         $('#termstart').children('.liItem').children('em').html(calendar1.value)
		         
		      },
		      'onClear':function(){
		      	
		          
		          }
		        });
		}




		var startTimeListener=function(initTermTime){
			//....日期控件
			 var minDate=calcMin();
			 var maxDate=calcMax();
			 var calendar11 = new datePicker();
		        calendar11.init({
		        'trigger': '#termrg', /*按钮选择器，用于触发弹出插件*/
		        'type': 'ym',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
		        'minDate':minDate,/*最小日期*/
		        'maxDate':maxDate,/*最大日期*/
		        'org':initTermTime,
		        'onSubmit':function(){/*确认时触发事件*/
		            var theSelectData=calendar11.value;
		             setting=false;
		            
		    },
		    'onClose':function(){/*取消时触发事件*/
		     
		       $('#termrg').children('.liItem').children('em').html(calendar11.value);
		       
		       
		       var userId=localStorage.userId;
				var url=cutUrl()+"/api/kbsz/clearCourseInfo";
				var mes={"userId":userId};
				  $.ajax({
						  "dataType": 'json',
						  "type": "GET",
						  "url": url,
						  "data": mes,
						  "contentType":"application/json;charset=utf-8",
						  "success": function (data, textStatus, jqXHR){
							  var raw=JSON.stringify(data);
							 
							  raw=$.parseJSON(raw);
							  if(raw.error.id=='0000'){
								  $('#termrg').children('.liItem').children('em').html(calendar11.value);
								  
								    var url1=cutUrl()+"/api/course/insertFirstTimeOfSchool";
							 		var mes1='{"userId":"'+userId+'","rxny":"'+calendar11.value+'"}';
							 		
							 			 $.ajax({
							 		         "dataType": 'json',
							 		         "type": "POST",
							 		         "url": url1,
							 		         "data": mes1,
							 		         "contentType":"application/json;charset=utf-8",
							 		         "success": function (data, textStatus, jqXHR){
							 		        	clickCtrl=false;
							 		        	 var raw=JSON.stringify(data);
							 		        	
							 		        	 raw=$.parseJSON(raw);
							 		        	 if(raw.error.id=='0000'){					 		        		 					 		        		  
							 		        		window.location='timeTableSetup.html';
							 		        	 }else{
							 		        		 //alert(raw.error.message);
							 		        		$.MsgBox.Alert('温馨提示',raw.error.message);
							 		        		
							 		        	 }
							 		         }
							 			 })
								  
							  }else{
								  //alert(raw.error.message);
								  $.MsgBox.Alert('温馨提示',raw.error.message);
							  }
						  }
				  })
		       
		       
		       
		       
		       
		       
		       
		    },
		    'onClear':function(){
		    	
		        
		        }
		      });
		}


		var maxmumClass=function(val){
		
		var maxclass=['1节','2节','3节','4节','5节','6节','7节','8节','9节','10节','11节','12节'];
		var mobileSelect3 = new MobileSelect({
			
		    trigger: '#maxclass',
		    type:'maxclass',
		    title: '设置最大节数',
		    wheels: [
		                {data: maxclass},
	
		            ],
		    position:[val, 2, 2, 2, 2], 
		    transitionEnd:function(indexArr, data){
		       var forshow='设置最大节数为：'+data[0];
		       $('#maxclassTitle').text(forshow);
		       
		    },
		    callback:function(indexArr, data){
		    	data=JSON.stringify(data);
		    	data=data.replace(/[^0-9]/g,'');        		    	
		        localStorage.classlength=data;
		    }
		});
  
			
		}

		var weekBeginwith=function(val){
		
		 var weekbegin=['周一','周二','周三','周四','周五','周六','周日'];
	 	 var mobileSelect3 = new MobileSelect({
	 			
	 		    trigger: '#beginwith',
	 		    type:'beginwith',
	 		    title: '设置每周起始日',
	 		    wheels: [
	 		                {data: weekbegin},
	 	
	 		            ],
	 		    position:[val, 2, 2, 2, 2], 
	 		    transitionEnd:function(indexArr, data){
	 		      
	 		      var forshow="设置当前周为："+data[0];
	 		    $('#beginwithTitle').text(forshow);
	 		     
	 		    },
	 		    callback:function(indexArr, data){
	 		        
	 		    }
	 		});
		}

	   var weekSelector=function(val){
		 
		 var weekInfo=['第1周','第2周','第3周','第4周','第5周','第6周','第7周','第8周','第9周','第10周','第11周','第12周','第13周','第14周','第15周','第16周','第17周','第18周','第19周','第20周','第21周','第22周','第23周','第24周'];
		 var mobileSelect3 = new MobileSelect({
				
			    trigger: '#currw',
			    type:'currw',
			    title: '设置当前周',
			    wheels: [
			                {data: weekInfo},
		
			            ],
			    position:[val, 2, 2, 2, 2], 
			    transitionEnd:function(indexArr, data){
			        var forshow='设置当前周为：'+data[0];
			        $('#currwTitle').text(forshow)
			    },
			    callback:function(indexArr, data){
			        console.log(data);
			    }
			});
		}



		var chineseConvert=function(val){
		if(val=='大一'){
			return '1';
		}else if(val=='大二'){
			return '2';
		}else if(val=='大三'){
			return '3';
		}else if(val=='大四'){
			return '4';
		}else if(val=='大五'){
			return '5';
		}else{
			return '7';
		}
	}

//中文数字转阿拉伯数字
    	 var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
         var chnUnitSection = ["","万","亿","万亿","亿亿"];
         var chnUnitChar = ["","十","百","千"];

         function SectionToChinese(section){
             var strIns = '', chnStr = '';
             var unitPos = 0;
             var zero = true;
             while(section > 0){
                 var v = section % 10;
                 if(v === 0){
                     if(!zero){
                         zero = true;
                         chnStr = chnNumChar[v] + chnStr;
                     }
                 }else{
                     zero = false;
                     strIns = chnNumChar[v];
                     strIns += chnUnitChar[unitPos];
                     chnStr = strIns + chnStr;
                 }
                 unitPos++;
                 section = Math.floor(section / 10);
             }
             return chnStr;
         }
         
         
        	 Array.prototype.indexOf = function (val) {
        		    for (var i = 0; i < this.length; i++) {
        		        if (this[i] == val) return i;
        		    }
        		    return -1;
        		};

        		Array.prototype.remove = function (val) {
        		    var index = this.indexOf(val);
        		    if (index > -1) {
        		        this.splice(index, 1);
        		    }
        		};

/*//根据入学年月和当前时间判断学期
 		var termCal=function(adyear,rgyear,series){
 			console.log(adyear+' '+rgyear+' '+series)
 			adyear=parseInt(adyear);
 			rgyear=parseInt(rgyear);
 			var gap=adyear-rgyear+1;
 			if(series==2){
 				gap=gap+1;
 			}
 			
 			gap=SectionToChinese(gap);
 			series=SectionToChinese(series);
 			
 			return '大'+gap+' '+'第'+series+'学期';
 		}*/
 		
 		
 		//根据入学年月和当前时间判断学期
 		var termCal=function(adyear,rgyear,series){
 			console.log('学年：'+adyear+' 入学时间：'+rgyear+' 学期'+series)
 			adyear=parseInt(adyear);
 			rgyear=parseInt(rgyear);
 			console.log('学年：'+adyear+' 入学时间：'+rgyear+' 学期'+series)
 			
 			var gap=adyear-rgyear;
 			if(series==1){
 				gap=gap+1;
 			}
 			
 			console.log(gap);
 			var feedback='';
 			if(gap<1||gap>5){
 				feedback='第'+series+'学期';
 			}else{
 				
 				gap=SectionToChinese(gap);
 	 			series=SectionToChinese(series);
 	 			feedback='大'+gap+' '+'第'+series+'学期';
 			}
 			
 			
 			
 			
 			
 			
 			
 			return feedback;
 		}

var clearance=function(userId){
	  var url=cutUrl()+"/api/kbsz/clearCourseInfo";
	  var mes={"userId":userId};
	  $.ajax({
			  "dataType": 'json',
			  "type": "GET",
			  "url": url,
			  "data": mes,
			  "contentType":"application/json;charset=utf-8",
			  "success": function (data, textStatus, jqXHR){
				  console.log(JSON.stringify(data));
			  }
	  })
}

var figureToCn=function(value){
	if(value==1){
		return '一';
	}else if(value==2){
		return '二';
	}else if(value==3){
		return '三';
	}else if(value==4){
		return '四';
	}else if(value==5){
		return '五';
	}else if(value==6){
		return '六';
	}else if(value==7){
		return '日';
	}
}

var interpret=function(week){
	
	if(week=='周一'){
		return 1;
	}else if(week=='周二'){
		return 2;
	}else if(week=='周三'){
		return 3;
	}else if(week=='周四'){
		return 4;
	}else if(week=='周五'){
		return 5;
	}else if(week=='周六'){
		return 6;
	}else if(week=='周日'){
		return 7;
	}
}