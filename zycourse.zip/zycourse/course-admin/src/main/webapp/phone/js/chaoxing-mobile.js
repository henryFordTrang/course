/**
 * 
 */
	//获取用户信息
	try{
		jsBridge.bind('CLIENT_GET_USERINFO', function(object){
			 // alert("uid:"+object.uid+" name:"+object.name + "  fid:"+object.fid);
			window.currentUserInfo = object;
				localStorage.uid=object.puid;//放入本地存储-puid
				localStorage.fid=object.fid;//放入本地存储
				localStorage.school1=object.schoolname;
				localStorage.userName=object.name;
				
				
	
	
		});  
	    jsBridge.postNotification("CLIENT_GET_USERINFO", {"accountKey":"" } ) ;
	}catch(e){}
	
	
	
	function exit()
	{
		var cmd = "CLIENT_EXIT_LEVEL";
		jsBridge.postNotification(cmd,{
			"message" : "||"
		});
	}
	
	function open(client,title,webUrl)
	{
		jsBridge.postNotification(client,{
			"title" : title,
			"loadType":"1",
			"webUrl":webUrl,
			"toolbarType":"0"
		});
	}

	var concealing=function(){
		
		jsBridge.postNotification('CLIENT_TOOLBAR_TYPE', {toolbarType:"0"}  ); 
	
	}