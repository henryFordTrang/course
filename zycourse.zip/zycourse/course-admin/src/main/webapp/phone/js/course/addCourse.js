$(function(){
	  var fid=localStorage.fid;
	  var uid=localStorage.uid;	  
	  var school=localStorage.school1;
	  var userId=localStorage.userId;
	  var chooser=localStorage.proceedingChooser;
	  var proceedingDate=localStorage.proceedingDate;
	  
	  
	  var clientHeight = document.documentElement.clientHeight || document.body.clientHeight; $(window).on('resize', function () {
		    var nowClientHeight = document.documentElement.clientHeight || document.body.clientHeight;
		    if (clientHeight > nowClientHeight) {
		    	
		       $('.submit2').css('display','none');
		    }
		    else {
		    	
		    	$('.submit2').css('display','block');
		    } });
	  
	  if(proceedingDate!=undefined){
		  $('#yearterm').children('.liItem').children('em').html(proceedingDate);
		  $('#menu_r').css('display','block');
	  }
	  
	  if(chooser!=undefined){
		  $('#term').children('.liItem').children('em').text(chooser);
		  $('#menu_r').css('display','none');
  		  $('#forward').css('display','block');
	  }
	  
	  var bterm=false;

	  
	/*$('#sysip').click(function(){
		
		$(this).parent('li').addClass('cur');
		$('#mnip').parent('li').removeClass('cur');
		 $('#item1').css('display','block');
		$('#item2').css('display','none'); 
		
		
	})
	
	$('#mnip').click(function(){
		
		$(this).parent('li').addClass('cur');
		$('#sysip').parent('li').removeClass('cur');
		 $('#item2').css('display','block');
		$('#item1').css('display','none'); 
		
		
	})*/
	
	var isSelected=true;
	$('.selectA').click(function(){
	    isSelected=!isSelected;
	    if(isSelected){
	        $(this).children('.img1').attr("src","../image/pwd.png");
	    }else{
	       $(this).children('.img1').attr("src","../image/unPwd.png"); 
	    }

	})
	$('#import').click(function(){
	    $(this).toggleClass("unInput").toggleClass("import");
	})
	$('.ipt').keyup(function(){
	    if($(this).val()==""){
	        $(this).removeClass("ipting").addClass("orgIpt"); 
	        $(".searchImg").show();
	        $(".searchImg1").hide();
	   }else{
	        $(this).removeClass("orgIpt").addClass("ipting");
	        $(".searchImg").hide();
	        $(".searchImg1").show();
	    }
	});
	$(".searchA").click(function(){
	    $('.addCourseDiv').show();
	    $('.courseUl').hide();
	})
	$(".cliA").click(function(){
		
	    $('.addCourseDiv').show();
	    $('.courseTimeUl').hide();
	})
	$('.setCourseA').click(function(){
	    $(this).children('.setCourse').toggleClass("addC").toggleClass("delC");
	    if($(this).children().children(".courseEm").text()=="添加到课表"){
	        $(this).children().children(".courseEm").text("删除");
	    }else{
	        $(this).children().children(".courseEm").text("添加到课表");
	    }
	})
	
	$('.menu_l').click(function(){
		
		window.location="term.html";
	})
	
	$('#import').click(function(){
		window.location="blankterm.html";
	})
	
	
	$('#addTime').click(function(){
		window.location="newCourseInit.html";
	})
	
	$('#menu_r').click(function(){
		window.location="blankterm.html";
	})
	
	$('#forward').click(function(){
		window.location="term.html";
	})
	
	$('#term').click(function(){
		if($('#yearterm').children('.liItem').children('em').text().length==0){
			//alert('请先选择入学年份');
			$.MsgBox.Alert('温馨提示','请先选择入学年份');
		}
	})
	
	//....日期控件
	var numArr=[];
    var courseFigureArr=[];  
    var starttime='';
    
	 var calendar1 = new datePicker();
        calendar1.init({
        'trigger': '#yearterm', /*按钮选择器，用于触发弹出插件*/
        'type': 'ym',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
        'minDate':'1900-1-1',/*最小日期*/
        'maxDate':'2100-12-31',/*最大日期*/
        'onSubmit':function(){/*确认时触发事件*/
            var theSelectData=calendar1.value;
            //...
            var entering='入学时间'+theSelectData;
            starttime=calendar1.value;
            starttime=starttime.substring(0,4);        
            starttime=parseInt(starttime)-6;
            numArr=[];
            courseFigureArr=[];
            for(var i=0;i<15;i++){
            	if(i>=5&&i<10){
            		starttime++;
            		var grading=i-4;
            		var grade='';
            		if(grading==1){
            			grade='一';
            		}
            		if(grading==2){
            			grade='二';
            		}
            		if(grading==3){
            			grade='三';
            		}
            		if(grading==4){
            			grade='四';
            		}
            		if(grading==5){
            			grade='五';
            		}
                	var st=starttime+1;        	
                	var starttimeplus=starttime+'年-'+st+'年'+'       大'+grade;
                	courseFigureArr.push(starttimeplus);
            	}else{
            		starttime++;
                	var st=starttime+1;        	
                	var starttimeplus=starttime+'年-'+st+'年';
                	courseFigureArr.push(starttimeplus);
            	}
            	
            	
            }
            bgettime=false;
            revealchooser(courseFigureArr,entering); 
            //...
            
    },
    'onClose':function(){/*取消时触发事件*/
      
      
        var url=cutUrl()+"/api/course/insertFirstTimeOfSchool";
		var mes='{"userId":"'+userId+'","rxny":"'+calendar1.value+'"}';
		 
			 $.ajax({
		         "dataType": 'json',
		         "type": "POST",
		         "url": url,
		         "data": mes,
		         "contentType":"application/json;charset=utf-8",
		         "success": function (data, textStatus, jqXHR){
		        	
		        	 var raw=JSON.stringify(data);
		        	
		        	 raw=$.parseJSON(raw);
		        	 if(raw.error.id=='0000'){
		        		 $('#menu_r').css('display','block');
		        		  $('#yearterm').children('.liItem').children('em').html(calendar1.value);
		        		 localStorage.proceedingDate=calendar1.value;
		        		 bterm=true;
		        	 }else{
		        		 false;
		        	 }
		         }
			 })
       
    },
    'onClear':function(){
    	
        
        }
      });
        
    
    
    var calendar11 = new datePicker();
        calendar11.init({
        'trigger': '#modifyterm', /*按钮选择器，用于触发弹出插件*/
        'type': 'ym',/*模式：date日期；datetime日期时间；time时间；ym年月；*/
        'minDate':'1900-1-1',/*最小日期*/
        'maxDate':'2100-12-31',/*最大日期*/
        'onSubmit':function(){/*确认时触发事件*/
            var theSelectData=calendar11.value;
             setting=false;
            
    },
    'onClose':function(){/*取消时触发事件*/
      
    $('#yearterm').children('.liItem').children('em').html(calendar11.value)
       
    },
    'onClear':function(){
    	
        
        }
      });
	
    
    //手动添加课程页面
        
        
    
      var courseurl=cutUrl()+"/api/course/qryCourseName";
	  var coursemes='{"userId":"'+userId+'","courseName":"","js":"","xnxqId":""}';
	 
			 $.ajax({
		         "dataType": 'json',
		         "type": "POST",
		         "url": courseurl,
		         "data": coursemes,
		         "contentType":"application/json;charset=utf-8",
		         "success": function (data, textStatus, jqXHR){
		        	 var raw=JSON.stringify(data);		
		        	 console.log(raw);
		        	 raw=$.parseJSON(raw);
		        	 $.each(raw.kcDetailsList,function(i,dom){
		        		 var clsseries=i+1;
		        		 var index='id'+dom.id;
		        		 
		        		 $('.courseTimeUl').append("<li><a href='javascript:;' class='cliA' id="+index+"><div class='liItem'><span>"+dom.courseName+"</span><img src='../image/go.png' alt=''></div></a></li><hr style='margin-left:0.21rem'>");
		        	 	 $('#'+index).click(function(){
		        	 		
		        	 		window.location='addCoDetail.html';
		        	 		localStorage.breakdownCourse=dom.courseName;
		        	 	 })
		        	 })
		        	 
		        	 $('#searchC').bind("input propertychange",function(){
		        		 var searchTerm=$(this).val();	
		        		 var counting=0;
		        		 var reCount=0;
		        		 $('.courseTimeUl').empty();
		        		 $.each(raw.kcDetailsList,function(i,dom){
		        			 counting++;
		        			 var index='cherry'+counting;
		        			 
		        			 if(dom.courseName.indexOf(searchTerm)>-1){
		        				 reCount++;
		        				 $('.courseTimeUl').append("<li class='line'><a href='javascript:;' class='cliA' id="+index+"><div class='liItem'><span>"+dom.courseName+"</span><img src='../image/go.png' alt=''></div></a></li>");
				        	 	 $('#'+index).click(function(){
				        	 		window.location='addCoDetail.html';
				        	 		localStorage.breakdownCourse=dom.courseName;
				        	 	 })
		        			 }
			        		 
			        	 })
			        	 
			        	 console.log(reCount+'***** the value of countting')
			        	 
			        	 if(reCount==0){
			        		 $('.courseTimeUl').hide();
			        		 $('.newCourse').show();
			        	 }else{
			        		 $('.newCourse').hide();
			        		 $('.courseTimeUl').show();
			        	 }
		        		 
		        	 })
		        	 
		        	 
		         }
			 })
    
			 
	
	$('.newCoPro').click(function(){
		var key=$('#searchC').val();
		localStorage.recommandCourse=key;
		window.location="brdNewCourse.html";
	})
	
})

var revealchooser=function(courseFigureArr,entering){
	
 	  var courseArr=['','','','',''];
 	  var spaceArr=[' ',' ',' ',' ',' ',' ',' '];	  
 	  var hourFigureArr=['第一学期','第二学期']; 	  
 	  var mobileSelect3 = new MobileSelect({
 				
 			    trigger: '#term',
 			    type:'newterm',
 			    org:'yes',
 			    title: entering,
 			    wheels: [
 			              
 			                {data: courseFigureArr},
 			                {data: courseArr},
 			                {data: spaceArr},
 			                {data: hourFigureArr}
 			               
 			              
 			            ],
 			    position:[5, 4, 2, 0, 2], 
 			    transitionEnd:function(indexArr, data){
 			    	
 			        
 			    },
 			    callback:function(indexArr, data){
 			    	
 			    	var forshow=data[0]+' '+data[3];
 			    	
					
 			    	var reg =/[\u4e00-\u9fa5]/g;
 			    	var year=data[0].replace(reg,"");
 			    	year=year.replace(/(^\s*)|(\s*$)/g, "");
 			    	var yt=data[1]+' '+year;			    
 			      
 			        var sbterm=convertTerm(data[3]);
 			       
 			       var userId=localStorage.userId;
 			       var url=cutUrl()+"/api/course/createXq";	 
 			       var mes='{"userId":"'+userId+'","xn":"'+year+'","xq":"'+sbterm+'"}';
 			       commiting(url,mes,forshow);
 			   
 			    }
 			});
 }
 
 var convertTerm=function(val){
	 if(val=='第一学期'){
		 return 1;
	 }else if(val=='第二学期'){
		 return 2;
	 }
 }
 
 var commiting=function(url,mes,forshow){
	   
		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "async":false,
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	var raw=JSON.stringify(data);
	        	raw=$.parseJSON(raw);
	        	if(raw.error.id=='0000'){
	        		$('#menu_r').css('display','none');
	        		$('#forward').css('display','block');
	        		$('#term').children('.liItem').children('em').text(forshow);
	        		localStorage.proceedingChooser=forshow;
	        		
	        	 }else{
	        		 //alert(raw.error.message);
	        		 $.MsgBox.Alert('温馨提示',raw.error.message);
	        	 }
	        	 
	        
	         }
		 })
}