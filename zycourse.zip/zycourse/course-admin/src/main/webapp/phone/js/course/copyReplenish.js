$(function(){
  
  $('#save').addClass('input');

  var fid=localStorage.fid;
  var uid=localStorage.uid;
  var userName=localStorage.userName;
  var school=localStorage.school1;
  
  
  var initurl=cutUrl()+"/api/course/searchSchoolName";
  $.ajax({
      "dataType": 'json',
      "type": "POST",
      "url": initurl,
      "contentType":"application/json;charset=utf-8",
      "success": function (data, textStatus, jqXHR){
    	  var raw=JSON.stringify(data);    	
    	  raw=$.parseJSON(raw);
    	  if(raw.error.id=='0000'){
    		  $('#sc').keyup(function(){
    			  if($(this).val()==""){
    				  $('.schoollist').css('display','none');
    			  }
    		  })
    		  $('#sc').bind("input propertychange",function(){
    			  
    			  var school=$(this).val();
    			  var dataSc=raw.shcoolNameList;
    			  $('.schoollist').empty();
    			  var count=0;
    			  $.each(dataSc,function(i,dom){
    				  count++;
    				  var id='cherry'+count;
    				  if(dom.indexOf(school)>-1){
    					  $('.schoollist').css('display','block');
    					  $('.schoollist').append("<li><a href='javascript:;' id="+id+"><span class='schoolSpan'>"+dom+"</span> </a></li>");
    					  $('#'+id).click(function(){
    						  var school=$(this).text();
    						  
    						  $('#sc').val(school);
    						  $('.schoollist').css('display','none');
    					  })
    					  
    				  }
    				 
    			  })
    			 // console.log(school)
    		  })
    		  
    		  
    		  
    	  }else{
    		  //alert(raw.error.message);
    		  $.MsgBox.Alert('温馨提示',raw.error.message);
    	  }
    	  
      }
  	})
 
  
  if(school!=''&&school.length>0){
	  $('#sc').val(school);
  }
 
  //roleChecking(fid,uid,userName,school);
  
  $('.menu_l').click(function(){
	  exit();
  })
  
  $('#sc').focus(function(){
	 
  })
  
 
  
  $('#sc').blur(function(){
	  
  })
  
  $('#dp').blur(function(){
	  
  })
  
  $('#sc').keyup(function(){
	  var phoneNo=$(this).val();
	  var rang=document.createRange();
	  if(phoneNo.length>18){		  
		  var phoneNo1=phoneNo.substring(0,18);
		  $("#sc").val(phoneNo1);


	  }
	  
	  if($('#dp').val().length>0&&$(this).val().length>0){
		  $('#save').css('background','#7693FF')
	  }else{
		  $('#save').css('background','#9395A3')
	  }
	  
  })
  
  $('#dp').keyup(function(){
	  var phoneNo=$(this).val();
	  var rang=document.createRange();
	  if(phoneNo.length>10){		  
		  var phoneNo1=phoneNo.substring(0,10);
		  $("#dp").val(phoneNo1);


	  }
	  console.log($('#sc').val()+'******'+$(this).val())
	  
	  if($('#sc').val().length>0&&$(this).val().length>0){
		  $('#save').css('background','#7693FF')
	  }else{
		  $('#save').css('background','#9395A3')
	  }
  })
  
  
  $(document).click(function (e) {
	  $('.schoollist').css('display','none');
  })
  
 

  $('#save').click(function(){
	 
	 sm(); 
	  

  })
  
  
  var sm=function(i){
	  var sc=$('#sc').val();
	  var dp=$('#dp').val();
	  var bsc=false;
	  var bdp=false;
	  var nsc="请输入学校,";
	  var ndp="请输入院系,";
	  if(sc.length>0){
		  bsc=true;
		  nsc="";
	  }else{
		  bsc=false;
		  nsc="请输入学校,";
	  }
	  
	  if(dp.length>0){
		  bdp=true;
		  ndp="";
	  }else{
		  bdp=false;
		  ndp="请输入院系,";
	  }
	  
	  if(bsc&&bdp){
		  var userId=localStorage.userId;
		  var url=cutUrl()+"/api/course/insertSchoolInfo";
		  var mes='{"userId":"'+userId+'","fid":"'+fid+'","schoolName":"'+sc+'","department":"'+dp+'"}';
		  
		 
			 $.ajax({
		         "dataType": 'json',
		         "type": "POST",
		         "url": url,
		         "data": mes,
		         "contentType":"application/json;charset=utf-8",
		         "success": function (data, textStatus, jqXHR){
		        	 var raw=JSON.stringify(data);
		        	 raw=$.parseJSON(raw);
		        	 
		        	 if(raw.error.id=="0000"){
		        		 
		        		
		        		 window.location="copy.html";
		        		
		        		 localStorage.school=sc;
		        		 localStorage.depart=dp;
		        	 }else{
		        		 //alert(raw.error.message);
		        		 $.MsgBox.Alert('温馨提示',raw.error.message);
		        	 }
		        	 
		         }
			 })
	  }else{
		  var general=nsc+ndp;
		  if(general.length>0){
			  general=general.substring(0,general.length-1);
			  //alert(general);
			  $.MsgBox.Alert('温馨提示',general);
		  }
	  }
  }
  
  
 })
 
 
 function set_focus(id)
{
    el=document.getElementById(id);
    
    //el=el[0];  //jquery 对象转dom对象
    el.focus();
    if($.support.msie)
    {
    	
        var range = document.selection.createRange();
        this.last = range;
        range.moveToElementText(el);
        range.select();
        document.selection.empty(); //取消选中
    }
    else
    {
    	
        var range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    }
}
 
 
 
 
 //获取用户信息
try{
	jsBridge.bind('CLIENT_GET_USERINFO', function(object){
		 // alert("uid:"+object.uid+" name:"+object.name + "  fid:"+object.fid);
		
			//alert(JSON.stringify(object));


	});  
	var checkuser=function(){
		jsBridge.postNotification("CLIENT_GET_USERINFO", {"accountKey":"" } ) ;
	}
    
}catch(e){}