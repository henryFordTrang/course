 $(function(){
  /* $('#save').click(function(){
    $(this).toggleClass("unInput").toggleClass("input");
  }) */
  
  var ismodify=localStorage.modify;
  if(ismodify==1){
	  $('.submit').children('input[type=submit]').val('完成');
	  $('.submit').children('input[type=submit]').removeAttr('id');
	  $('.submit').children('input[type=submit]').attr('id','modify');
  }
 
  
  $('#save').addClass('input');
  
  var fid=localStorage.fid;
  var uid=localStorage.uid;
  
  var school=localStorage.school1;

  if(school.length>0){
	  $('#sc').val(school);
  }
 
 // roleChecking(fid,uid);
  $('.menu_l').click(function(){
	  window.location="timeTableSetup.html";
  })
  
  $('#sc').focus(function(){
	 
  })
  
  $('#dp').focus(function(){
	 
	  var sc=$('#sc').val();
	  
	  if(sc.length==0){
		  //alert('请先选择学校');
		  $.MsgBox.Alert('温馨提示','请先选择学校');
	  }
  })
  
  $('#sc').blur(function(){
	  
  })
  
  $('#dp').blur(function(){
	  
  })
  
  $('#sc').keyup(function(){
	  var phoneNo=$(this).val();
	  var rang=document.createRange();
	  if(phoneNo.length>18){		  
		  var phoneNo1=phoneNo.substring(0,18);
		  $("#sc").val(phoneNo1);


	  }
	  
	  if($('#dp').val().length>0&&$(this).val().length>0){
		  $('#save').css('background','#7693FF')
	  }
	  
  })
  
  $('#dp').keyup(function(){
	  var phoneNo=$(this).val();
	  var rang=document.createRange();
	  if(phoneNo.length>10){		  
		  var phoneNo1=phoneNo.substring(0,10);
		  $("#dp").val(phoneNo1);


	  }
	  
	  
	  if($('#sc').val().length>0&&$(this).val().length>0){
		  $('#save').css('background','#7693FF')
	  }
  })
  
  

  $('#save').click(function(){
	 
	 sm(); 
	  

  })
  
  
  var sm=function(){
	  var userId=localStorage.userId;
	  var sc=$('#sc').val();
	  var dp=$('#dp').val();
	  var bsc=false;
	  var bdp=false;
	  var nsc="请输入学校,";
	  var ndp="请输入院系,";
	  if(sc.length>0){
		  bsc=true;
		  nsc="";
	  }else{
		  bsc=false;
		  nsc="请输入学校,";
	  }
	  
	  if(dp.length>0){
		  bdp=true;
		  ndp="";
	  }else{
		  bdp=false;
		  ndp="请输入院系,";
	  }
	  
	  if(bsc&&bdp){
		  
		  //删除原有数据
		  var url1=cutUrl()+"/api/kbsz/clearCourseInfo";
		  var mes1={"userId":userId};
		  $.ajax({
				  "dataType": 'json',
				  "type": "GET",
				  "url": url1,
				  "data": mes1,
				  "contentType":"application/json;charset=utf-8",
				  "success": function (data, textStatus, jqXHR){
					  var initRaw=JSON.stringify(data);
					  
					  initRaw=$.parseJSON(initRaw);
					  if(initRaw.error.id=='0000'){
						  
						  var url=cutUrl()+"/api/course/insertSchoolInfo";
						  var mes='{"userId":"'+userId+'","fid":"'+fid+'","schoolName":"'+sc+'","department":"'+dp+'"}';
						 
							 $.ajax({
						         "dataType": 'json',
						         "type": "POST",
						         "url": url,
						         "data": mes,
						         "contentType":"application/json;charset=utf-8",
						         "success": function (data, textStatus, jqXHR){
						        	 var raw=JSON.stringify(data);
						        	 
						        	 raw=$.parseJSON(raw);
						        	 if(raw.error.id=="0000"){
						        		 
						        		 window.location="timeTableSetup.html";
						        		
						        		 localStorage.school=sc;
						        		 localStorage.depart=dp;
						        	 }else{
						        		 //alert(raw.error.message);
						        		 $.MsgBox.Alert('温馨提示',raw.error.message);
						        	 }
						        	 
						         }
							 })
							 
					  }else{
						  //alert(initRaw.error.message);
						  $.MsgBox.Alert('温馨提示',initRaw.error.message);
					  }
				  }
		  })
		  
		 
		 
	  }else{
		  var general=nsc+ndp;
		  if(general.length>0){
			  general=general.substring(0,general.length-1);
			  //alert(general);
			  $.MsgBox.Alert('温馨提示',general);
		  }
	  }
  }
  
  
 })
 
 
 var clearance=function(userId){
	  var url=cutUrl()+"/api/kbsz/clearCourseInfo";
	  var mes={"userId":userId};
	  $.ajax({
			  "dataType": 'json',
			  "type": "GET",
			  "url": url,
			  "data": mes,
			  "contentType":"application/json;charset=utf-8",
			  "success": function (data, textStatus, jqXHR){
				  console.log(JSON.stringify(data));
			  }
	  })
}