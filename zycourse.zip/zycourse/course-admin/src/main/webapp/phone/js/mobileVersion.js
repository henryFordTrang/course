/* 解析版本号(用户比较版本) 例: version:3.0.1.2 */ 
function dealVersion(version){
     var uaArr = version.split(".");
	 var ua = "";
	 for(var i=0;i<uaArr.length;i++){
		if(uaArr[i].length==1){
			ua += ("0"+uaArr[i]);
	 	}else if(uaArr[i].length==2){
		 	ua += uaArr[i];
	 	}
	 }
	 if(ua.length == 2){
	 	ua += "000000";
	 }else if(ua.length == 4){
	 	ua += "0000";
	 }else if(ua.length == 6){
		 ua += "00";
	 }
	 return ua;
 }
 
 /* 获取学习通版本号 */
 function getXxtVersion(){
     var ua="";
	 if(navigator.userAgent.indexOf("ChaoXingStudy") > -1){
	    ua = navigator.userAgent;
	    ua = ua.substring(ua.indexOf("ChaoXingStudy_")+14);
	    ua = ua.substring(ua.indexOf("_")+1);
	    ua = ua.substring(0,ua.indexOf("_")); 
     }
	 return ua;
 }
 
 /* ios版本,返回值为整数 */
 // var getIOSVersion = 
 function getIOSVersion(){
     var ua = navigator.userAgent.toLowerCase();
     if(ua.match(/(iphone|ipod);?/i)){
         return ua.match(/iphone os ([0-9]+)_/)[1];
     }else if(ua.match(/(ipad);?/i)){
         return (ua.match(/cpu os ([0-9]+)_/))[1];
     }
  }
 /* 区分安卓和ios */
 // var isIos = 
 function isIos(){
	 var ua = navigator.userAgent.toLowerCase();
	 if(ua.match(/(iphone|ipod|ipad);?/i)){
		 return true;
	 }else{}
	 return false;
 }
 // var isIphoneX = 
 function isIphoneX(){
		var isIphone=/iphone/gi.test(navigator.userAgent);
	    if(isIphone&& (screen.height == 812 && screen.width == 375)){
	    	return true;
	    }else{
	    	return false;
	    }
	}
 
//var isIphonePlus = 
 function isIphonePlus(){
		var isIphone=/iphone/gi.test(navigator.userAgent);
	    if(isIphone&& (screen.height == 736 && screen.width == 414)){
	    	return true;
	    }else{
	    	return false;
	    }
	}
 
 
 
 //比较版本号（当前版本，要比较的版本）
 function judgeVersion(curVersion,judgeVersion){
	 if(parseInt(dealVersion(curVersion))-parseInt(dealVersion(judgeVersion))<0){
		 return false;
	 }else{
		 return true;
	 }
	 
 }
 
 
 
 $(function(){
	 var isios=isIos();
	 if(isios){//是苹果手机
		 
		 window.confirm = function (message) {
	            var iframe = document.createElement("IFRAME");
	            iframe.style.display = "none";
	            iframe.setAttribute("src", 'data:text/plain,');
	            document.documentElement.appendChild(iframe);
	            var alertFrame = window.frames[0];
	            var result = alertFrame.window.confirm(message);
	            iframe.parentNode.removeChild(iframe);
	            return result;
	    };

		 
		 window.alert = function(name){
			  var iframe = document.createElement("IFRAME");
			  iframe.style.display="none";
			  iframe.setAttribute("src", 'data:text/plain,');
			  document.documentElement.appendChild(iframe);
			  window.frames[0].window.alert(name);
			  iframe.parentNode.removeChild(iframe);
			 };
			 
			 if(isIphoneX()){
				 //$('#container').css('height','12.74rem');
				 $('.top_menu').css('padding-top','0.35rem');
				 $('body').css('padding-top','0.35rem');
				 $('.menu_l').css('padding-top','0.35rem');
				 $('.menu_r').css('padding-top','0.35rem');
				 $('.itemHead').css('padding-top','0.35rem');
			 }else{
				
				 $('.top_menu').css('padding-top','0.25rem');
				 $('body').css('padding-top','0.25rem');
				 $('.menu_l').css('padding-top','0.25rem');
				 $('.menu_r').css('padding-top','0.25rem');
				 $('.itemHead').css('padding-top','0.25rem');
				 
			 }
	 	 
		 
		 
		 
		/* input[type="button"], input[type="submit"], input[type="reset"] {
			    -webkit-appearance: none;
			}
			textarea {  -webkit-appearance: none;}*/
		 
		 
	 }else{
		 if (window.history && window.history.pushState) {
		        $(window).on('popstate', function () {
		        window.history.pushState('forward', null, '#');
		        window.history.forward(1);
		        });
		    }
		        window.history.pushState('forward', null, '#'); //在IE中必须得有这两行
		        window.history.forward(1);
		 
		
	 }
})
 
 
