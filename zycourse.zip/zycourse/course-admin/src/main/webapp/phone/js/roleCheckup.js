function roleChecking(fid,uid,userName,school){
	
	
	 var mes1={"uid":uid,"fid":fid,"username":userName,"schoolName":school};

	 $.ajax({
         "dataType": 'json',
         "type": "GET",
         "async":false,
         "url": cutUrl()+"/api/auth/loginByChaoxing",
         "data": mes1,
         "contentType":"application/json;charset=utf-8",
         "success": function (data, textStatus, jqXHR){
        	 var raw=JSON.stringify(data);  
        	 
        	
        	 raw=$.parseJSON(raw);    
        	 localStorage.userId=raw.userId;
        	 if(raw.first_login=="NO"){
        		 
        		 termCheckup(raw.userId);
        		
        	 }else{
        		 classlengthInit(raw.userId);
        	 }
        	 
         }
	 })
	 
 }



var classlengthInit=function(userId){
	 var url=cutUrl()+"/api/course/initJcsj";
	 var set=[];
	 var chinese=['一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五'];
	 var starttime=['7:00','8:00','9:00','10:00','11:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00'];
	 var endtime=['7:45','8:45','9:45','10:45','11:45','13:45','14:45','15:45','16:45','17:45','18:45','19:45','20:45','21:45','22:45','23:45'];
	 
	 for(var i=0;i<15;i++){
		 var j=i+1;
		 var chineseSeries='第'+chinese[i]+'节';
		 var unit='{"id":"","jcdm":"'+j+'","jcmc":"'+chineseSeries+'","jckssj":"'+starttime[i]+'","jcjssj":"'+endtime[i]+'","userId":"'+userId+'"}';
		 set.push(unit);
	 }
	 var nap='{"id":"","jcdm":"0","jcmc":"午休","jckssj":"12:00","jcjssj":"13:00","userId":"'+userId+'"}';
	 set.push(nap);
	 set='['+set+']';
	 var mes='{"kcJcsjEntityList":'+set+'}';
		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "url": url,
	         "data": mes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	console.log(JSON.stringify(data)+'init');
	        	window.location='index.html';
	         }
		 })
	 
}

var resetCurrentWeek=function(userId){
	var resetUrl=cutUrl()+"/api/course/resetCurrentZs";
	var mes={"userId":userId};
	$.ajax({
        "dataType": 'json',
        "type": "GET",
        "async":false,
        "url": resetUrl,
        "data": mes,
        "contentType":"application/json;charset=utf-8",
        "success": function (data, textStatus, jqXHR){
        	var raw=JSON.stringify(data);
        	console.log(raw);
        	raw=$.parseJSON(raw);
        	
        }
	})
	
}


var termCheckup=function(userId){
	var mes={"userId":userId};
	
	$.ajax({
        "dataType": 'json',
        "type": "GET",
        "async":false,
        "url": cutUrl()+"/api/course/hasXnxq",
        "data": mes,
        "contentType":"application/json;charset=utf-8",
        "success": function (data, textStatus, jqXHR){
        	var raw=JSON.stringify(data);
        	console.log(raw+'term checkup');
        	raw=$.parseJSON(raw);
        	
        	if(raw.error.id=="0000"){
        		
        		if(raw.error.message==2){
        			window.location="blankterm.html";
        		}else if(raw.error.message==1){
        			resetCurrentWeek(userId);
        			window.location="term.html";
        		}
        	}else if(raw.error.id=="9999"){
        		alert("操作失败");
        	}
        	
        }
	})
}