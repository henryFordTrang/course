var reg=/[\u4e00-\u9fa5]/g;

$(function(){
     var length='';
     var bIfNull=true;
     var bNap=true;
     var bAllCls=true;
     var rawData='';
     var userId=localStorage.userId;
   	 var url=cutUrl()+"/api/kbsz/qryJcTime";
   	 var mes='{"userId":"'+userId+'"}';
   	 
   
   	 $('.menu_l').click(function(){

   		var modifyChek=updateCheck(rawData);
   		if(modifyChek){
   			$.MsgBox.Confirm("trang", "是否放弃时间设定",
   			function (){
   				
   				window.location="term.html";
   			},
   			function(){
   				return;
   			})

   		}else{
   			window.location="term.html";
   		}
   		

     })
     
     //清空课时
     $('#clearTime').click(function(){
    	 
    	 if($(this).css('color')=='rgb(147, 149, 163)'){
    		 return;
    	 }
    	 
    	 $('.fulscreen').show();
    	 $('.coverWr').show();
    	 var colorAll=false;
    	 var colorNap=false;
    	 $('.courA').children('em').each(function(){
    		 if($(this).text().length>0){
    			 colorAll=true;
    		 }
    	 })
    	 
    	 if($('#nap').find('em').text().length>0){
    		 colorNap=true;
    	 }

    	 
    	 if(!colorNap){
    		 $('#clearNap').css('color','#A4AAB3');
    	 }else{
    		 $('#clearNap').css('color','#FF6D6D');
    	 }
    	 if(!colorAll){
    		 $('#clearAll').css('color','#A4AAB3');
    	 }else{
    		 $('#clearAll').css('color','#FF6D6D');
    	 }
     })
     
     $('#clearCac').click(function(){
    	 
    	 $('.fulscreen').hide();
    	 $('.coverWr').hide();
     })
	 
     $('#clearNap').click(function(){
    	 
    	 $.MsgBox.Confirm("温馨提示", "确定清空午休时间吗", function () {
    		 $('#nap').find('em').text('');
        	 $('.fulscreen').hide();
        	 $('.coverWr').hide();
        	 
        	 var colorAll=false;
        	 $('.courA').children('em').each(function(){
        		 if($(this).text().length>0){
        			 colorAll=true;
        		 }
        	 })
        	 
        	 if(!colorAll){
        		 bAllCls=false; 
        	 }
        	 
        	 bNap=false;        	
         	if(!bAllCls&&!bNap){
         		$('#clearTime').css('color','rgb(164, 170, 179)');
         	}
         	
    	 },function () {
        	 return;
        	})

    	
     })
     
     $('#clearAll').click(function(){
    	 $.MsgBox.Confirm("温馨提示", "确定清空全部时间吗", function () {
    		 $('.line').each(function(){
        		 $(this).children('.liItem').children('.courA').children('em').text('');   		 
        	 })
        	 
        	 $('.fulscreen').hide();
        	 $('.coverWr').hide();
        	 
        	 var colorNap=false; 
        	 if($('#nap').find('em').text().length>0){
        		 colorNap=true;
        	 }
        	 
        	 if(!colorNap){
        		 bNap=false;
        	 }
        	 
        	 bAllCls=false;     	 	
             if(!bAllCls&&!bNap){
            	$('#clearTime').css('color','rgb(164, 170, 179)');
             }
             
    	 },function () {
        	
        	 return;       	 
        	})
    	 
     })
     
     
    var url1=cutUrl()+"/api/course/qryKbSettingsInfo";
	var mes1='{"userId":"'+userId+'"}';

		 $.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "url": url1,
	         "data": mes1,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	 var raw1=JSON.stringify(data);
	        	 
	        	 raw1=$.parseJSON(raw1);
	        	 length=raw1.kbSettingsInfo.jcMax;
	        	
	        	 length=parseInt(length)-1;
	        	 if(raw1.error.id=='0000'){
	 
	 
   		 $.ajax({
   	         "dataType": 'json',
   	         "type": "POST",
   	         "url": url,
   	         "data": mes,
   	         "contentType":"application/json;charset=utf-8",
   	         "success": function (data, textStatus, jqXHR){
   	        	 var raw=JSON.stringify(data);
   	        	 //console.log(raw+length)
   	        	 raw=$.parseJSON(raw);
   	        	 
   	        	 rawData=raw;
   	        	 var num=0;
   	        	 
   	        	 var amInit='7:10';
   	        	 var pmInit='14:00';
   	        	 
   	        	if(raw.list[12].jckssj.length>0){
  	        		 bIfNull=false;
  	        	 }
   	        	
   	        	 
   	        	 $.each(raw.list,function(i,dom){
					if(i>length){
						return;
					}
				
				
 				if(num<3){
 				num=i;
 				}else{
 				num=i+1;
 				}

 			var j=i+1;
 			var hiddenId=dom.id;
 			var x='id'+j;
 			var starttimeArr=[];
 			var endtimeArr=[];
 			if(dom.jckssj.replace(reg,'').length==0){
 				dom.jcjssj='';
 			}else{
 				bIfNull=false;
 			}
 
 			var clsStart=dom.jckssj;
 			var clsEnd=dom.jcjssj;
 			var display='';
 			if(clsStart.length>0){
 				display=clsStart+'-'+clsEnd;
 			}
 			
 			$('#wrapper').append("<li class='line'  id="+x+"><div class='liItem'><input type='hidden' class='idkeeper' value="+hiddenId+"><input type='hidden' class='serieskeeper' value="+j+"><span>第"+j+"节</span><a href='javascript:;' class='courA'><img src='../image/go.png' alt=''><em>"+display+"</em></a></div></li>");

 			//设置拨盘初始位置  当数据库有值的时候
 			var positOrg='7:30';
 			positOrg=positOrg.split(':');
 			var seriesOrg=new Date();
	 		seriesOrg.setHours(positOrg[0]);
	 		seriesOrg.setMinutes(positOrg[1]);
	 		var milOrg=Date.parse(seriesOrg);
	 		var gap='';
 			if(clsStart.length>0){
 				var positStart=dom.jckssj;
 	 			positStart=positStart.split(':');

 	 			var seriesStart=new Date();
 	 			seriesStart.setHours(positStart[0]);
 	 			seriesStart.setMinutes(positStart[1]); 			
 	 			
 	 			var milSer=Date.parse(seriesStart);
 	 			
 	 			gap=milSer-milOrg;
 	 			gap=gap/300000;
 			}else{
 				//设置拨盘初始值 当数据库没值的时候
 				
 				var clsIndex=dom.jcdm;
 				clsIndex=parseInt(clsIndex);
 				var initTime=amInit;
 				//var pmInitTime=pmInit;
 				initTime=initTime.split(':');
 				
 				if(clsIndex<6&&clsIndex>0){
 					var positInit=new Date();
 	 				positInit.setHours(initTime[0]);
 	 				positInit.setMinutes(initTime[1]); 	 				
 	 				var milInit=Date.parse(positInit); 	 				
 	 				milInit=parseInt(milInit)+clsIndex*3000000; 	 				
 	 				var updateInit=new Date(milInit).Format('hh:mm');
 	 				
 	 				
 				}else if(clsIndex>=6){
 					var positInit=new Date();
 	 				positInit.setHours(initTime[0]);
 	 				positInit.setMinutes(initTime[1]); 	
 	 				
 	 				var milInit=Date.parse(positInit);
 	 				
 	 				milInit=parseInt(milInit)+clsIndex*3000000+6600000;
 	 				
 	 				var updateInit=new Date(milInit).Format('hh:mm');
 	 				
 					
 				}else{
 					
 					
 				}
 				
 				gap=milInit-milOrg;
 	 			gap=gap/300000;
 				
 
 				
 			}
 			
 			
 			
 			
 			var mobileSelect3 = new MobileSelect({
			
		    trigger: '#'+x,
		    type:x,
		    org:x,
		    title: '设置课时',
		    wheels: [		   
		             	{data: window.general},
		               
		               
		              
		            ],
		    position:[gap,7,0,2,2], 
		    transitionEnd:function(indexArr, data,index){
		    	
		    	var forshow='';
		    	var starting=data[0].value;
		        var ending=data[1].value;
		        if(index==0){
		        	   
				        var splitup=data[0].value;
				        splitup=splitup.split(':');
				        //console.log(splitup)
				        var date=new Date();
				        date.setMinutes(splitup[1])
				        date.setHours(splitup[0]);		        
				        var date1=Date.parse(date)+900000;		       
				        var newDate=new Date(date1).Format('hh:mm');
				        forshow="课时设置为："+starting+'-'+newDate;
				        
		        	
		        }else{
		        	
		        	forshow='课时设置为：'+starting+'-'+ending;
		        	
		        }
		    	
		    	
		    	$('#henry'+x).text(forshow);
		    
		    },		    
		    callback:function(indexArr, data){
		    	var forShow=data[0].value+'-'+data[1].value;
		    	$('#'+x).find('em').text(forShow);
		    	$('#'+x).find('em').css('color','rgba(147,157,195,1)');
		    	$('#clearTime').css('color','#FF6D6D');
		    	bAllCls=true;
		        
		    }
			}); 
 	
   	        })
   	        
   	        $('#clearTime').show();
   	        	 
   	        if(bIfNull){
   	   	        $('#clearTime').css('color','rgba(147,149,163,1)');
   	   	        
   	   	        	
   	   	      }	 
   	        	 
   	        	//调用午休设置方法 
   	        	napset(raw.list[12].jcmc,raw.list[12].jckssj,raw.list[12].jcjssj,raw.list[12].id);
   	        	// console.log(raw.list[15].jcmc+' '+raw.list[15].jckssj+' '+raw.list[15].jcjssj+' '+raw.list[15].id);
   	         }
   		 }) 
   		 
   		 
   		 
   		 
   		 
   		 
   		 
   		 
	        	 }else{
	        		 
	        		//alert(raw1.error.message); 
	        		$.MsgBox.Alert('温馨提示',raw1.error.message);
	        	 }
	         }
	         })
   		 
   		 //点击完成
   		 var spaceArr=['-'];   	
   		 $('.menu_r').click(function(){
   			 
   			 var hasCourse=false;//判断午休时间是否有课
   			 var flowOrder=false;//判断上课时间是否冲突
   			 var noticeCourse='';
   			 var noticeOrder='';
   			 var nap=$('#nap').text();
   			 var topNotice;

   			 if(nap.replace(reg,'').length>0){
   				 //休息   判断午休时间是否有课
   				
   				nap=nap.split('-');
		    	var restSTime=parseInt(nap[0].replace(/[^0-9]/ig,""));//休息开始时间
		    	var restETime=parseInt(nap[1].replace(/[^0-9]/ig,""));//休息结束时间
		    	
		        $('#wrapper').children('.line').each(function(){
		        	//console.log($(this).children().children('.courA').children('em').text());
		        	var courseTime=$(this).children().children('.courA').children('em').text();//节次的时间段
		        	if(courseTime.length==0){
		        		return;
		        	}
		        	var courseSTime=parseInt(courseTime.split('-')[0].replace(/[^0-9]/ig,""));//开始时间
		        	var courseETime=parseInt(courseTime.split('-')[1].replace(/[^0-9]/ig,""));//结束时间
		        	//console.log(courseSTime+'<='+restSTime+'&&'+restSTime+'<'+courseETime+'||'+courseSTime+'<'+restETime+'&&'+restETime+'<'+courseETime+'||'+restSTime+'<'+courseETime+'&&'+restETime+'>'+courseETime)	        	
		        	if((courseSTime<=restSTime&&restSTime<courseETime)||(courseSTime<restETime&&restETime<courseETime)||(restSTime<courseETime&&restETime>courseETime)||(restSTime<courseSTime&&courseSTime<restETime)||(restSTime<courseETime&&courseETime<restETime)){
		        		hasCourse=true;
		        		
		        		noticeCourse='午休时间已有课程,';
		        	}
		        	
		        	
		        });
   				 
   				
		        //休息时间是否有课 判断end
   				 
 
   				 
   			 }
   			
   			 
   			 
   			 //判断课时是否冲突
   			var auditSet=[];
   			var idSet=[];
			 $('.courA').each(function(){
				 
				 var unitSet=$(this).text();
				 if(unitSet.length==0){
					 return;
				 }
				 unitSet=unitSet.split('-');				
				 auditSet.push(unitSet[0]);
				 auditSet.push(unitSet[1]);
				 var unitId=$(this).siblings('.serieskeeper').val();
				 idSet.push(unitId);
			 })
			 
			 var intSet=[];
			 $.each(auditSet,function(i,dom){
				 
				 var compare=dom.split(':');
				 compare=parseInt(compare[0]*60)+parseInt(compare[1]);
				 intSet.push(compare);
			 })
			
			 
			 var conflictSet=[];
			 for(var i=1;i<intSet.length;i++){
				 var j=i-1;
				
				 if(intSet[j]>intSet[i]){
					 conflictSet.push(i);
					
					 flowOrder=true;
					 //noticeOrder='上一节课的结束时间需小于下一节课的开始时间,'
				 }
				    				 
			 }
			 
			 
			 
			 if(flowOrder){
				 var conflictCls=parseInt(conflictSet[0])/2;
				 noticeOrder='第'+conflictCls+'节,下课时间不能大于下节课上课时间,'
			 }
			 
			 //课时冲突判断end
			
   			 
   			 if(!flowOrder&&!hasCourse){
   				var duraset=[];
   	        	$('.liItem').each(function(){
   	        		
   	        		
   	        		var course=$(this).children('span').text();   	        		  	        		   	        		
   	        		var classseries=$(this).children('.serieskeeper').val();//节次代码  	        		 	        		
   	        		var id=$(this).children('.idkeeper').val();//数据id
   	        		
   	        		var cnseries=$(this).children('span').text();//节次  
   	        		cnseries=cnseries.replace(reg,'');
   	        		cnseries=classConvert(cnseries);
   	        		
   	        		/*var starttime=beginwith[0];
   	        		starttime1=starttime.replace(reg,'');
   	        		
   	        		if(starttime1.length==1){
   	        			starttime1='null';
   	        		}
   	        		
   	        		if(classseries==0&&starttime1.replace(reg,'').length==0){
   	        			
   	        			starttime1='';
   	        			beginwith[1]='';
   	        			
   	        		}*/
   	        		
   	        		//节次开始和结束时间
   	        		var smBegin='';
   	        		var smEnd=''; 
   	        		var beginwith=$(this).children('a').children('em').text(); 
   	        		if(beginwith.length>0){
   	        			
   	        			beginwith=beginwith.split('-');
   	        			smBegin=beginwith[0];
   	        			smEnd=beginwith[1];
   	        		}
   	        		
   	        		var unit='{"id":"'+id+'","jcdm":"'+classseries+'","jcmc":"'+cnseries+'","jckssj":"'+smBegin+'","jcjssj":"'+smEnd+'","userId":"'+userId+'"}';
   	        		
   	        		duraset.push(unit);

   	        	})
   	        	
   	        	
   	        	
   	 
   	        	duraset='['+duraset+']';
   	        	var mes='{"kcJcsjEntityList":'+duraset+'}';
   	        	var url=cutUrl()+"/api/kbsz/settingCourseTime";
   	        	
   	        	
   	          		 $.ajax({
   	          	         "dataType": 'json',
   	          	         "type": "POST",
   	          	         "url": url,
   	          	         "data": mes,
   	          	         "contentType":"application/json;charset=utf-8",
   	          	         "success": function (data, textStatus, jqXHR){
   	          	        	 
   	          	        	 var raw=JSON.stringify(data);
   	          	        	 raw=$.parseJSON(raw);
   	          	        	 
   	          	        	 if(raw.error.id=='0000'){
   	          	        		window.location="term.html";
   	          	        	 }else{
   	          	        		//alert(raw.error.message);
   	          	        		$.MsgBox.Alert('温馨提示',raw.error.message);
   	          	        	 }
   	          	         }
   	          		 })
   	          		 
   			 }else{
   				 
   				//课时冲突提示
   				if(conflictSet.length>0){
   					
   					
   					$.each(conflictSet,function(i,dom){
   						var series=parseInt(dom)/2-1;
   						var realSeries=idSet[series];
   						$('.serieskeeper').each(function(){
   							if($(this).val()==realSeries){
   								$(this).siblings('.courA').children('em').css('color','#FF6D6D');
   							}
   						})
   					})
   					
   					clearTimeout(topNotice);
   					$('.top_menu2').removeClass('concTop').addClass('lowerTop');
   					setTimeout(function(){$('.top_menu2').removeClass('lowerTop').addClass('concTop');}, 3000);
   					
   				}
   				//午休时间冲突提示
   				if(hasCourse){
   					$('#nap').children('em').css('color','#FF6D6D');
   					clearTimeout(topNotice);
   					$('.top_menu2').removeClass('concTop').addClass('lowerTop');
   					setTimeout(function(){$('.top_menu2').removeClass('lowerTop').addClass('concTop');}, 3000);
   				}
   				 
   				 /*var general=noticeOrder+noticeCourse;
   				 general=general.substring(0,general.length-1);
   				 alert(general);*/
   				 
   			 }

   			 
   		 })
   		 
 
        //午休时间设置
     	var napset=function(jcmc,jckssj,jcjssj,id){
        	// var nonap='不休息';
     		 var napSta=[];
             var napEnd=[];
            // napSta.push(nonap);
             for(var o=0;o<8;o++){
            	 
            	 var unitNapS=new Date();
            	 var unitNapE=new Date();
            	 var para=o*15+45;
            	 var paraE=o*15+45;
            	 unitNapS.setHours(11);
            	 unitNapS.setMinutes(para);
            	 unitNapE.setHours(12);
            	 unitNapE.setMinutes(paraE);
            	 
            	 
            	 
            	 var stTrans=new Date(unitNapS).Format("hh:mm");
            	 var edTrans=new Date(unitNapE).Format("hh:mm");
            	 napSta.push(stTrans);
            	 napEnd.push(edTrans);
            	 
             }
             
             var forShow='';
             if(jckssj!=''){
            	 forShow=jckssj+'-'+jcjssj;
             }
            
            $('.timeUl').append("<li class='line' id='nap'><div class='liItem'><input type='hidden' class='idkeeper' value="+id+"><input type='hidden' class='serieskeeper' value='0'><span>午休</span><a href='javascript:;'><img src='../image/go.png' alt=''><em>"+forShow+"</em></a></div></li>");

            
             /*if(jckssj.replace(reg,'').length==0){
            	 jckssj='不休息';
            	 jcjssj='';
             }
            if(jckssj=="不休息"){
            	 $('.timeUl').append("<li class='line'><div class='liItem'><input type='hidden' class='idkeeper' value="+id+"><input type='hidden' class='serieskeeper' value='0'><span>午休</span><a href='javascript:;'id='nap'><img src='../image/go.png' alt=''><em>"+jckssj+"</em></a></div></li>"); 
            }else{
            	$('.timeUl').append("<li class='line'><div class='liItem'><input type='hidden' class='idkeeper' value="+id+"><input type='hidden' class='serieskeeper' value='0'><span>午休</span><a href='javascript:;'id='nap'><img src='../image/go.png' alt=''><em>"+jckssj+"-"+jcjssj+"</em></a></div></li>");
            }*/
           
            var fnPosS=0;
            var fnPosE=0;
            //设置拨盘初始位置  当数据库有值的时候
            if(jckssj.replace(reg,'').length>0){
            	
            	var positionS=jckssj;           
                var positionE=jcjssj;
                
                var positionO='';
                positionS=positionS.split(':');
                positionE=positionE.split(':');
                
                var positStart=new Date();
                var positEnd=new Date();
                var positOrg=new Date();
                
                positStart.setHours(positionS[0]);
                positStart.setMinutes(positionS[1]);
                positEnd.setHours(positionE[0]);
                positEnd.setMinutes(positionE[1]);
                positOrg.setHours('10');
                positOrg.setMinutes('00');
                
                var milS=Date.parse(positStart);
                var milE=Date.parse(positEnd);
                var milO=Date.parse(positOrg);
                
                fnPosS=parseInt(milS)-parseInt(milO);
                fnPosS=fnPosS/300000;
                
                fnPosE=parseInt(milE)-parseInt(milS);
                fnPosE=fnPosE/300000-1;
                
            }else{
            	//设着拨盘初始位置 当数据库没值的时候
            	
            	fnPosS=24;
            	fnPosE=23;
            }
            
 
            
         	 var mobileSelect3 = new MobileSelect({
    				
    			    trigger: '#nap',
    			    type:'dura',
    			    org:'nap',
    			    title: '设置午休时间',
    			    wheels: [
    			                
    			                {data: window.NapArr},
    			                
    			              
    			            ],
    			    position:[fnPosS, fnPosE, 5, 2, 2], 
    			    transitionEnd:function(indexArr, data,index){
    			    	//console.log(JSON.stringify(data)+' ---henry--'+index);
    			      
    			    	var forshow='';
    			    	var starting=data[0].value;
    			        var ending=data[1].value;
    			        var forbreak=starting.split(':');
    			        
    			        var date11=new Date();
    			        date11.setHours(forbreak[0]);
    			        date11.setMinutes(forbreak[1]);
    			        var increased=Date.parse(date11)+900000;
    			        var updateDate=new Date(increased).Format('hh:mm');
    			        
    			        //当滑动左边的滑动条
    			        $('#nap').find('em').css('color','rgba(147,157,195,1)');
    			        if(index==0){
    			        	    
    					        var splitup=data[0].value;
    					        splitup=splitup.split(':');
    					        var date=new Date();
    					        date.setMinutes(splitup[1])
    					        date.setHours(splitup[0]);		        
    					        var date1=Date.parse(date)+900000;		       
    					        var newDate=new Date(date1).Format('hh:mm');
    					        if(starting.replace(reg,'').length==0){
        			        		forshow='午休设置为:'+starting;
        			        		
        			        	}else{
        			        		forshow="午休设置为："+starting+'-'+newDate;
        			        	}
    					        
    			        	
    			        	
    			        }else{
    			        	//当滑动右边滑动条
    			        	if(starting.replace(reg,'').length==0){
    			        		forshow='午休设置为:'+starting;
    			        		
    			        	}else if(starting=='12:00'){
    			        		forshow='午休设置为：'+'12:00'+'-'+'12:30';
    			        		
    			        	}else{
    			        		forshow='午休设置为：'+starting+'-'+ending;
    			        		
    			        	}
    			        	
    			        }
    			    	
    			    	
    			    	$('#dura').text(forshow);
    			    	
    			    	
    			      

    			    },
    			    callback:function(indexArr, data){
    			        //console.log(data[0].value+' '+data[1].value);
    			        var forShow=data[0].value+'-'+data[1].value;
    			        $('#clearTime').css('color','#FF6D6D');
    			        bNap=true;
    			        $('#nap').find('em').text(forShow);
    			    }
    			});
     	} 
     	 
     	 
     	//午休设置 end 
    })
     //.......
         Date.prototype.Format = function (fmt) { 
        	    var o = {
        	        "M+": this.getMonth() + 1, //月份 
        	        "d+": this.getDate(), //日 
        	        "h+": this.getHours(), //小时 
        	        "m+": this.getMinutes(), //分 
        	        "s+": this.getSeconds(), //秒 
        	        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        	        "S": this.getMilliseconds() //毫秒 
        	    };
        	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        	    for (var k in o)
        	    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        	    return fmt;
        	}

        	//调用


	var classConvert=function(val){
		if(val==1){
			return '第一节';
		}else if(val==2){
			return '第二节';
		}else if(val==3){
			return '第三节';
		}else if(val==4){
			return '第四节';
		}else if(val==5){
			return '第五节';
		}else if(val==6){
			return '第六节';
		}else if(val==7){
			return '第七节';
		}else if(val==8){
			return '第八节';
		}else if(val==9){
			return '第九节';
		}else if(val==10){
			return '第十节';
		}else if(val==11){
			return '第十一节';
		}else if(val==12){
			return '第十二节';
		}else if(val==13){
			return '第十三节';
		}else if(val==14){
			return '第十四节';
		}else if(val==15){
			return '第十五节';
		}else if(val==''){
			return '午休';
		}
	}

	//判断是否有改动
	var updateCheck=function(raw){
				
		/*var duraset=[];
       	$('.liItem').each(function(){
       		var course=$(this).children('span').text();
       		var beginwith=$(this).children('a').children('em').text();
       		beginwith=beginwith.split('-');
       		var classseries=$(this).children('.serieskeeper').val();
       		var cnseries=$(this).children('span').text();
       		var id=$(this).children('.idkeeper').val();
       		
       		cnseries=cnseries.replace(reg,'');
       		cnseries=classConvert(cnseries);
       		
       		var starttime=beginwith[0];
       		starttime1=starttime.replace(reg,'');
       		
       		if(starttime1.length==1){
       			starttime1='null';
       		}
       		
       		if(classseries==0&&starttime1.replace(reg,'').length==0){
       			
       			starttime1='不休息';
       			beginwith[1]='不休息';
       			
       		}
       		var unit='{"id":"'+id+'","jcdm":"'+classseries+'","jcmc":"'+cnseries+'","jckssj":"'+starttime1+'","jcjssj":"'+beginwith[1]+'"}';
       		
       		duraset.push(unit);

       	})*/
       			
       			var duraset=[];
   	        	$('.liItem').each(function(){
   	        		
   	        		
   	        		var course=$(this).children('span').text();   	        		  	        		   	        		
   	        		var classseries=$(this).children('.serieskeeper').val();//节次代码  	        		 	        		
   	        		var id=$(this).children('.idkeeper').val();//数据id
   	        		
   	        		var cnseries=$(this).children('span').text();//节次  
   	        		cnseries=cnseries.replace(reg,'');
   	        		cnseries=classConvert(cnseries);
   	        		
   	        		
   	        		
   	        		//节次开始和结束时间
   	        		var smBegin='';
   	        		var smEnd=''; 
   	        		var beginwith=$(this).children('a').children('em').text(); 
   	        		if(beginwith.length>0){
   	        			
   	        			beginwith=beginwith.split('-');
   	        			smBegin=beginwith[0];
   	        			smEnd=beginwith[1];
   	        		}
   	        		var unit='{"id":"'+id+'","jcdm":"'+classseries+'","jcmc":"'+cnseries+'","jckssj":"'+smBegin+'","jcjssj":"'+smEnd+'"}';
   	        		//var unit='{"id":"'+id+'","jcdm":"'+classseries+'","jcmc":"'+cnseries+'","jckssj":"'+smBegin+'","jcjssj":"'+smEnd+'","userId":"'+userId+'"}';
   	        		
   	        		duraset.push(unit);

   	        	})
       	
       	var ifModify=false;
       	var length=parseInt(duraset.length)-1;
       	
       	$.each(duraset,function(i,dom){

       		var unit=$.parseJSON(dom);
       		if(i==length){
       			if(unit.jckssj!=raw.list[12].jckssj||unit.jcjssj!=raw.list[12].jcjssj){
           			
           			ifModify=true;
           			
           		}
       			
       		}else{
       			if(unit.jckssj!=raw.list[i].jckssj||unit.jcjssj!=raw.list[i].jcjssj){
           			
           			ifModify=true;
           			
           		}
       			
       		}
       		

       	})
       	
       	return ifModify;
		
	}
	
