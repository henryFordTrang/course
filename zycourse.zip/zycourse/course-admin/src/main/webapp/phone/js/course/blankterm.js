$(document).ready(function () {
		
	 	$('.center').prepend("<a href='javascript:;' id='newterm'><img class='imgtip' src='../image/noTerm.png' alt=''></a>"); 	 	 
	 	$('.top_menu').append("<span>课程表</span>");
	 	 
	 	if(isIphoneX()){
			 
			 $('#container').css('height','13rem');
		 }
	 	
	     var da=new Date();
	     da=da.getDay();
	     var monday=getMonday();
	     milm=Date.parse(monday);
		  var tuesday=milm+86400000*1;
		  var wenesday=milm+86400000*2;
		  var thirsday=milm+86400000*3;
		  var friday=milm+86400000*4;
		  var saturday=milm+86400000*5;
		  var sunday=milm+86400000*6;
		  monday=new Date(milm).Format("MM-dd");
		  tuesday=new Date(tuesday).Format("MM-dd");
		  wenesday=new Date(wenesday).Format("MM-dd");
		  thirsday=new Date(thirsday).Format("MM-dd");
		  friday=new Date(friday).Format("MM-dd");
		  saturday=new Date(saturday).Format("MM-dd");
		  sunday=new Date(sunday).Format("MM-dd");
		  
		 
		  
		  $('#td1').text(monday);
		  $('#td2').text(tuesday);
		  $('#td3').text(wenesday);
		  $('#td4').text(thirsday);
		  $('#td5').text(friday);
		  $('#td6').text(saturday);
		  $('#td7').text(sunday);
		  markCur();
		  
		  var fid=localStorage.fid;
			 var uid=localStorage.uid;
			 var userName=localStorage.userName;
			 var school=localStorage.school1;
			 var reg=/[\u4e00-\u9fa5]/g;
			 var userId='';
			// $('.table').attr("background","bg.jpg")
			 var mes1={"uid":uid,"fid":fid,"username":userName,"schoolName":school};
		  
		  
	   	  
	   	  $.ajax({
	         "dataType": 'json',
	         "type": "GET",
	         "async":false,
	         "url": cutUrl()+"/api/auth/loginByChaoxing",
	         "data": mes1,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	 var raw=JSON.stringify(data);  
	        	 raw=$.parseJSON(raw);
	        	 userId=raw.userId;
	        	 var spanurl=cutUrl()+"/api/kbsz/qryJcTime";
	   	   	     var spanmes='{"userId":"'+userId+'"}';
	        	 $.ajax({
	    	         "dataType": 'json',
	    	         "type": "POST",
	    	         "async":false,
	    	         "url": spanurl,
	    	         "data": spanmes,
	    	         "contentType":"application/json;charset=utf-8",
	    	         "success": function (data, textStatus, jqXHR){
	    	        	 var raw1=JSON.stringify(data);	    	        	
	    	        	 raw1=$.parseJSON(raw1);
	    	        	 $.each(raw1.list,function(i,dom){
	    	        		 //...
	    	        		 if(i==0){
	    	        			 $('#side1').children('p').text(dom.jckssj);
	    	        		 }else if(i==1){
	    	        			 $('#side2').children('p').text(dom.jckssj);
	    	        		 }else if(i==2){
	    	        			 $('#side3').children('p').text(dom.jckssj);
	    	        		 }else if(i==3){
	    	        			 $('#side4').children('p').text(dom.jckssj);
	    	        		 }else if(i==4){
	    	        			 $('#side5').children('p').text(dom.jckssj);
	    	        		 }else if(i==5){
	    	        			 $('#side6').children('p').text(dom.jckssj);
	    	        		 }else if(i==6){
	    	        			 $('#side7').children('p').text(dom.jckssj);
	    	        		 }else if(i==7){
	    	        			 $('#side8').children('p').text(dom.jckssj);
	    	        		 }else if(i==8){
	    	        			 $('#side9').children('p').text(dom.jckssj);
	    	        		 }else if(i==9){
	    	        			 $('#side2').children('p').text(dom.jckssj);
	    	        		 }
	    	        		 //...
	    	        		 
	    	        	 })
	    	        	 
	    	         }
	        	 })
	        	 
	         }
	   	  })
	         
	        var ofix1 = new oFixedTable('ofix1', document.getElementById('mytable'), {rows:1, cols:1});	 
	        
	    
	    //$('.top_menu').append("<div class='menu'><div class='courseUp'><em>第5周</em><a href='javascript:;' id='choose'><img src='../image/slideUp.png' alt=''></a><p class='menuP'>大二 第一学期</p></div></div>");
	 	//$('.center').prepend("<a href='javascript:;' id='newcourse'><img class='imgtip' src='../image/noCourse.png' alt=''></a>");
        $(document).click(function (e) {
            $(".courseTimeList").slideUp();
            $(".setList").slideUp();
            e.stopPropagation();
        });
        
        $('.menu_l').click(function(){
        	exit();
        	//window.location="initCourse.html";
        })
        $(".menu_r").click(function(e){
            $(this).next().slideToggle(500);
            e.stopPropagation();
        })
        
        $('#scan').click(function(){
        	barcode();
        })
        
        $('#share').click(function(){
        	window.location="shareTime.html";
        })
        $('#create').click(function(){
        	
        })
        
        $('#setup').click(function(){
        	window.location="timeTableSetup.html";
        })
        
        $('#newterm').click(function(){
        	window.location="createTerm.html";
        })
        
        $('#newcourse').click(function(){
        	window.location="newCourse.html";
        })
        
        $('#choose').click(function(){
        	materialConfirm('请选择周数','dsadsa',function(result){
        		var weekSeries='第'+$('.selected').text()+'周';
        		
        		$('.courseUp').children('em').html(weekSeries);
        	 })
        })
        
        $('.seatCharts-seat').each(function(){
        	$(this).click(function(){
        		$('.seatCharts-seat').addClass('available').removeClass('selected');
        		$(this).addClass('selected');
        		
        	})
        })
        
    });
 	
 	
 		try{
    		jsBridge.bind('CLIENT_BARCODE_SCANNER', function(object){
    			//alert("msg="+object.message);
    		});  
    	}catch(e){}

    	function barcode(){
    		
    		jsBridge.postNotification('CLIENT_BARCODE_SCANNER', {}) ;
    	}
    	
    	
    	
 //日期计算
		
		var calculationDate=function(orgCur,updateCur){
			//console.log('当前：'+orgCur+' ---Trang---'+'选取：'+updateCur);
			var monday=getMonday();
			var x=orgCur-updateCur;
			//console.log(x);
			//console.log('check the value of monday:'+monday);
			var orgMondayMil=Date.parse(monday);
			var gapMil=(updateCur-orgCur)*7*86400000;
			var realMondayMil=orgMondayMil+gapMil;
			var realMonday=new Date(realMondayMil).Format('yyyy-MM-dd');
			//console.log(realMonday+'   更新');
			//localStorage.realMonday=realMonday;
			return realMonday;
		}
		
		
		//获取星期一日期
		
		var getMonday=function(){
			var date=new Date();
		var weekDate=new Date().getDay();
		var weekGap=weekDate-1;
		date=date.Format('yyyy-MM-dd');
		var milvalue=Date.parse(date);
		var mondayMil=milvalue-weekGap*86400000;
		
		var x=new Date(milvalue).Format('yyyy-MM-dd');
		var y=new Date(mondayMil).Format('yyyy-MM-dd');
		
		
		return y;
		
		}
		
		
		// 标志当前时间
		var markCur=function(){
			var liveDate=new Date().getDay();
		  if(liveDate==1){
			  textColor('#td1');
		  }else if(liveDate==2){
			  textColor('#td2');
		  }else if(liveDate==3){
			  textColor('#td3');
		  }else if(liveDate==4){
			  textColor('#td4');
		  }else if(liveDate==5){
			  textColor('#td5');
		  }else if(liveDate==6){
			  textColor('#td6');
		  }else if(liveDate==7){
			  textColor('#td7');
		  }
		}
		
		//文本变色
		var textColor=function(id){
			$(id).css('color','#ff7886');
			$(id).siblings('em').css('color','#ff7886');
			//$(id).parent('td').css('border-top','solid 0.07rem #ff7886')
			//var url="url('../image/topmarker.png')"
			//$(id).parent('td').css('background-image',url);
			//$(id).parent('td').css('background-size','cover');
		}
		
		
		
		//设置日期格式
   	 Date.prototype.Format = function (fmt) { 
    	    var o = {
    	        "M+": this.getMonth() + 1, //月份 
    	        "d+": this.getDate(), //日 
    	        "h+": this.getHours(), //小时 
    	        "m+": this.getMinutes(), //分 
    	        "s+": this.getSeconds(), //秒 
    	        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
    	        "S": this.getMilliseconds() //毫秒 
    	    };
    	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    	    for (var k in o)
    	    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    	    return fmt;
    	}