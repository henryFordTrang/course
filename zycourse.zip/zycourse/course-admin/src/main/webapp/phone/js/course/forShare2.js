var schoolName='';
var userName='';
var reg=/[\u4e00-\u9fa5]/g;

	function GetRequest() {
	    var url = location.search; //获取url中"?"符后的字串
	    var theRequest = new Object();
	    if (url.indexOf("?") != -1) {
	        var str = url.substr(1);
	        strs = str.split("&");
	        for(var i = 0; i < strs.length; i ++) {
	            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
	        }
	    }
	    return theRequest;
	}
	
	function unique1(array){ 
		var n = []; //一个新的临时数组 
		//遍历当前数组 
		for(var i = 0; i < array.length; i++){ 
		//如果当前数组的第i已经保存进了临时数组，那么跳过， 
		//否则把当前项push到临时数组里面 
		if (n.indexOf(array[i]) == -1) n.push(array[i]); 
		} 
		return n; 
		}

	function compare(property){
	    return function(a,b){
	        var value1 = a[property];
	        var value2 = b[property];
	        return value1 - value2;
	    }
	}
	
	var sortting=function(timeSpan){
		var resetArr=[];
     	var unitCheck='';
    	$.each(timeSpan,function(i,dom){
    		var dating=new Date();
    		var rawspaning=dom.jckssj;
    		
    		if(rawspaning.replace(reg,'').length==0){
    			rawspaning='00:00';
    		}
    		rawspaning=rawspaning.split(':');
    		dating.setHours(rawspaning[0]);
    		dating.setMinutes(rawspaning[1]);
    		
    		var maturespan=Date.parse(dating);
    		
    		
    		unitCheck+='{'+'"'+'id'+'"'+':'+'"'+dom.id+'"'+','+'"'+'jcmc'+'"'+':'+'"'+dom.jcmc+'"'+','+'"'+'jcdm'+'"'+':'+'"'+dom.jcdm+'"'+','+'"'+'jckssj'+'"'+':'+'"'+maturespan+'"'+','+'"'+'jcjssj'+'"'+':'+'"'+dom.jcjssj+'"'+'}'+',';
    		
    		 resetArr.push(dom);
    		 if(i==3){
    			 resetArr.push(timeSpan[12]);
    		 }
    		 
    	 })		
    	
    	unitCheck=unitCheck.substring(0,unitCheck.length-1);
    	unitCheck='['+unitCheck+']';
    	
    	
    	unitCheck=$.parseJSON(unitCheck)
    	unitCheck.sort(compare('jckssj'));
    	
    	return unitCheck;
	}


	function isBrowser() {
	    var userAgent = navigator.userAgent;
	   
	    //学习通
	    if(userAgent.match(/chaoxing/i) == 'chaoxing'||userAgent.match(/ChaoXing/i) == 'ChaoXing') {
	        return "chaoxing";
	    }
	    //微信内置浏览器
	    if(userAgent.match(/MicroMessenger/i) == 'MicroMessenger') {
	        return "MicroMessenger";
	    }
	    //QQ内置浏览器
	    else if(userAgent.match(/QQ/i) == 'QQ') {
	        return "QQ";
	    }
	    //Chrome
	    else if(userAgent.match(/Chrome/i) == 'Chrome') {
	        return "Chrome";
	    }
	    //Opera
	    else if(userAgent.match(/Opera/i) == 'Opera') {
	        return "Opera";
	    }
	    //Firefox
	    else if(userAgent.match(/Firefox/i) == 'Firefox') {
	        return "Firefox";
	    }
	    //Safari
	    else if(userAgent.match(/Safari/i) == 'Safari') {
	        return "Safari";
	    }
	    //IE
	    else if(!!window.ActiveXObject || "ActiveXObject" in window) {
	        return "IE";
	    }
	    else {
	        return "未定义:"+userAgent;
	    }
	}


$(document).ready(function () {
	
	
	 var reg=/[\u4e00-\u9fa5]/g;	 	 
	/* var str=decodeURI(location.href);
	 var urlName=str.split('&');
	 var getName=urlName[3].split('=');*/
	
	 var Request = new Object();
	 Request = GetRequest();
	 
	 var fid=Request.fid;
	 var uid=Request.uid;
	 var userId=Request.userId;
	 var userName=Request.userName;
	 var school=Request.school;
	 
	 var pic='http://photo.chaoxing.com/p/'+uid+'_80';
	 
	 $('.leftImg').attr('src',pic);
	 //$('.lP1').text(getName[1]);
	 
	 var browser=isBrowser();
	 var isIphone=isIos();
	
	 
	 
	 if(isIphone){
		
		 if(browser=="Safari"){
			
			 $('.coverDiv1').hide();
		 }else if(browser=="chaoxing"){
			 
			 $('.coverDiv1').hide();
		 }else{
			 
			 $('.coverDiv1').show();
		 }
		
	 }else{
		 if(browser=="MicroMessenger"){
			$('.coverDiv2').show();
				
		 }else{
			$('.coverDiv2').hide();
		 } 
	 }
	 
	 
	 var ifNapping=false;
	 var weekshift='';
	 var currentD='';
	 $('body').css('padding-top','0rem')
	 
	 
	 $.ajax({
     		"dataType": 'json',
     		"type": "GET",
     		"async":false,
    		"url": cutUrl()+"/api/course/getUserCourseInfo",
     		"data": {"userId":userId},
     		"contentType":"application/json;charset=utf-8",
     		"success": function (data, textStatus, jqXHR){
     			var raw1=JSON.stringify(data);
     			console.log(raw1)
     			$('#mfyA').addClass('concealing');
     			$('#wrapper1').addClass('concealing');
     			$('#choosediv').addClass('concealing');
				
     			raw1=$.parseJSON(raw1);
     			$('.lP1').text(raw1.userName);
     			
     			
     			
     			if(raw1.error.id=='0000'){
     				
     				var schoolName=raw1.schoolName;
         			var department=raw1.department;
         			var getTerm=raw1.hasXq;
         			var clsList=raw1.hasCourse;
         			currentD=raw1.currentZs;
         			curWeek=raw1.currentZs;
         			
         			//weekGenerate(currentD);
         			
         			if(schoolName!=null&&schoolName!=''&&department!=null&&department!=''){//有院校信息的情况下，判断是否有学期
     					if(getTerm==1){//已有学期的情况下，判断是否已有课程
     						
     						if(clsList==1){//有院校，学期，课程的情况，展示课程信息

		        	        	
		        	        	 var adyear=raw1.xn;
	     			        	 var rgyear=raw1.rxny;
	     			        	 var termseries=raw1.xq;
	     			        	 adyear=adyear.split('-');
	     			        	 adyear=adyear[0];
	     			        	 rgyear=rgyear.substring(0,4);
	     			        	 var opening=new Date(raw1.kxsj).Format('yyyy');
	     			        	 var gradeInfo=termCal(opening,rgyear,termseries);
	     			        	 $('.menuP').text(gradeInfo);
	     			        	 $('.courseUp').children('em').text('第'+currentD+'周');
	     			        	 $('.lP2').text(gradeInfo)
	     			        	 var weekStart=raw1.weekStart;
	     			        	 weekshift=raw1.weekStart;
	     			        	 
	     			        	if(weekStart>1){
	     			        		 weekStart=weekStart-1;
	     			        		 for(var w=0;w<7;w++){	        			 
	     				        		 weekStart++;
	     				        		 if(weekStart>7){
	     				        			 weekStart=weekStart-7;
	     				        		 }
	     				        		 var weekId='tdP'+weekStart;
	     				        		 var cnws=SectionToChinese(weekStart);
	     				        		 if(cnws=='七'){
	     			        				 cnws='日';
	     			        			 }
	     				        		 $('.table').children('thead').children('tr').append("<td class='firstTd' width=1.2rem><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
	     				        	 }
	     			        	 }else{
	     			        		 for(var w=0;w<7;w++){
	     			        			 var weekId='tdP'+weekStart;
	     			        			 var cnws=SectionToChinese(weekStart);
	     			        			 if(cnws=='七'){
	     			        				 cnws='日';
	     			        			 }
	     			        			 $('.table').children('thead').children('tr').append("<td class='firstTd' width=1.2rem><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
	     			        			 weekStart++;
	     			        		 }
	     			        		 
	     			        	 } 
	     			        	
	     			        	$('.table').children('thead').children('tr').eq(0).children('td').eq(0).css('background-image','url("../image/divide1.png")');
	     			        	$('.table').children('thead').children('tr').eq(0).children('td').eq(0).css('background-size','cover');
	     			        	var max=raw1.jcMax;
	     			        	var timeSpan=raw1.list;   
	     			        	
     							var resetArr=sortting(timeSpan);
     							
		        	        	/*$.each(timeSpan,function(i,dom){
		        	        		 resetArr.push(dom);
		        	        		 if(i==3){
		        	        			 resetArr.push(timeSpan[12]);
		        	        		 }
		        	        		 
		        	        	 })		        	        	 		        	        	
		        	        	 
		        	        	resetArr=resetArr.slice(0,resetArr.length-1);*/	
		        	        	var checkNapIn=raw1.list[12].jckssj;
		        	        	checkNapIn=checkNapIn.replace(reg,'');
		        	        	var trueIndex=0;
	     			        	if(checkNapIn.length!=0){
	     			        		
		        	        		 //in case 有午休
		        	        		 ifNapping=true;
		        	        		 
		        	        		 var indexing=0;
		        	        		 
		        	        		 $.each(resetArr,function(i,dom){
		        	        			 indexing++;
		        	        			
		        	        			 if(dom.jcdm==0){
		        	        				 trueIndex=indexing;
		        	        			 }
		        	        		 })
		        	        		 trueIndex=trueIndex-1;
		        	        		// console.log('有午休'+trueIndex)
		        	        		 
		        	        		 $.each(resetArr,function(i,dom){	
			        	        		//console.log(dom);
		        	        			
		        	        			
		        	        			 var series=dom.jcmc;
		        	        			 var reg=/[\u4e00-\u9fa5]/g;
		        	        			 series=classConvert(series);
		        	        			 var trmark='mark'+i;
		        	        			 
		        	        			 if(i<trueIndex){
		        	        				 if(i>=max){
				        	        			 return;
				        	        		 } 	
		        	        			 }else{
		        	        				 if(i>max){
				        	        			 return;
				        	        		 } 	
		        	        			 }
		        	        			
			        	        		
		        	        			 
		        	        			 var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
			        	        		
			        	        		 if(dom.jcmc=='午休'){
			        	        			 //$('.table').children('tbody').append("<tr class='restTr'><td class='firstTd'>"+dom.jcmc+"<p class='time'>"+dom.jckssj+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
			        	        			 $('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'>"+trulyStart+"</p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
			        	        		 }else{
			        	        			 $('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
			        	        		 }
			        	        		 
			        	        		       	        		
		        	        	 }) 

		        	        		 
		        	        		 
		        	        	 }else{
		        	        		
		        	        		 //in case 没有午休
		        	        		 ifNapping=false;
		        	        		 resetArr.remove(resetArr[0])	        	        		
		        	        		 $.each(resetArr,function(i,dom){	
				        	        		
			        	        			 var series=dom.jcmc;
			        	        			 
			        	        			 series=classConvert(series);
			        	        			/* var reg=/[\u4e00-\u9fa5]/g;
			        	        			 series=series.replace(reg,'');*/
			        	        			 
			        	        			 var trmark='mark'+i;		        	        		
				        	        		  if(i>=max){
				        	        			 return;
				        	        		 } 	
				        	        		  
				        	        		
				        	        		 var trulyStart=new Date(dom.jckssj*1000/1000).Format('hh:mm');
				        	        		
				        	        		$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+trulyStart+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
				        	        		 
				        	        		 
				        	        		       	        		
			        	        	 }) 

		        	        	 }
	     			        	
	     			        	
	     			        	
		        	        	//课程数据展示
     							newLoading(userId,currentD,weekshift,ifNapping,trueIndex);
		        	        	
     							
     							
     						}else{//已有学期但是没课程的时候跳转到 nocourseTerm.html页面
     							window.location='noCourseTerm.html';
     						}
 
     						
     					}else if(getTerm==2){//还没学期的时候跳转到新建学期页面
     						
     						window.location='blankterm.html';
     					}
         				
     				}else{//院校信息不齐全，跳转到建立院校信息页面
     					window.location='index.html';
     				}
     				
     			}else{
     				window.location='index.html';
     				//alert(raw1.error.message);
     			}

     			
     		}
    		})
    		
    		
    		
	 
	 

            		
     
    
	 

    
  
    
    $('#copy').click(function(){
    	/*if(confirm('确定要复制课表吗')){
    		
    		if(isBrowser()=='chaoxing'){
    			arouse(userId);
    			
    		}else{
    			launchStudy1(userId);
    		}
    		
    		
    	}else{
    		window.history.back(-1); 
    	}*/
    	
    	
    	$.MsgBox.Confirm("温馨提示", "确定要复制课表吗", function () {
    		if(isBrowser()=='chaoxing'){
    			arouse(userId);
    			
    		}else{
    			launchStudy1(userId);
    		}
    		
    		
    	}, function () {
    		
    		window.history.back(-1); 
    		
    		
    	})
    })
	
      	
    });


	function launchStudy1(userId) {
		
		
		var host=window.location.host;
    	var title=userName+'课表';
    	var activityUrl='http://'+host+'/zycourse/phone/html/copy.html?userId='+userId;
		
    	
		
		//打开的时候显示的标题
		// var title=encodeURIComponent('123');
		 var url=encodeURIComponent(activityUrl);
		
		 //带标题传
		// url="chaoxingshareback://url="+url+"&title="+title+"&sharebacktype=1";
		 url="chaoxingshareback://url="+url+"&sharebacktype=1";
		
		
		
		
		window.location.href=url;
		
			
			 
	   setTimeout(function() { 
	  	 if (!document.webkitHidden) { window.location = 'https://apps.chaoxing.com/'; } 
	  	 }, 50);
	
	} 
	
	
	function arouse(userId){
		var host=window.location.host;
    	var title=userName+'课表';
    	var url='http://'+host+'/zycourse/phone/html/copy.html?userId='+userId;
    	jsBridge.postNotification('CLIENT_OPEN_URL', {'title':'123', 'loadType':'1'  ,'webUrl':url,'toolbarType':'2'});
		//jsBridge.postNotification('CLIENT_OPEN_URL', {'title':'123', 'loadType':'0'  ,'webUrl':url#INNER});
		
		
	}
	
	function encodeUtf8(text) {
	    const code = encodeURIComponent(text);
	    const bytes = [];
	    for (var i = 0; i < code.length; i++) {
	        const c = code.charAt(i);
	        if (c === '%') {
	            const hex = code.charAt(i + 1) + code.charAt(i + 2);
	            const hexVal = parseInt(hex, 16);
	            bytes.push(hexVal);
	            i += 2;
	        } else bytes.push(c.charCodeAt(0));
	    }
	    return bytes;
	}

	 
 
 
 	//封装的方法


/* //根据入学年月和当前时间判断学期
	var termCal=function(adyear,rgyear,series){
		adyear=parseInt(adyear);
		rgyear=parseInt(rgyear);
		var gap=adyear-rgyear+1;
		if(series==2){
			gap=gap+1;
		}
		
		gap=SectionToChinese(gap);
		series=SectionToChinese(series);
		
		return '大'+gap+' '+'第'+series+'学期';
	}*/
	
	var termCal=function(adyear,rgyear,series){
			console.log(adyear+' ---- '+rgyear+' --- '+series)
			adyear=parseInt(adyear);
			rgyear=parseInt(rgyear);
			
			
			var gap=adyear-rgyear;
			if(series==1){
				gap=gap+1;
			}
			
			console.log(gap);
			var feedback='';
			if(gap<1||gap>5){
				feedback='第'+series+'学期';
			}else{
				
				gap=SectionToChinese(gap);
	 			series=SectionToChinese(series);
	 			feedback='大'+gap+' '+'第'+series+'学期';
			}
			
			
			
			
			
			
			
			return feedback;
		}
	
	/*//根据入学年月和当前时间判断学期
	var termCal=function(adyear,rgyear,series){
		
		adyear=parseInt(adyear);
		rgyear=parseInt(rgyear);
		var gap=adyear-rgyear;
		if(series==1){
			gap=gap+1;
		}
		
		
		if(gap<1||gap>5){
			gap=10;
		}
		
		gap=SectionToChinese(gap);
		series=SectionToChinese(series);
		
		return '大'+gap+' '+'第'+series+'学期';
	}*/
	
	
	//分享图片
	var sendPic=function(base64){
		var url=cutUrl()+"/api/course/GetPictureUrl";
		
		$.ajax({
			  "dataType": 'json',
			  "type": "POST",
			  "url": url,
			  "data": base64,
			  "contentType":"application/json;charset=utf-8",
			  "success": function (data, textStatus, jqXHR){
				  var raw=JSON.stringify(data);
				  raw=$.parseJSON(raw);
				  transfer(raw.url);
				 // window.location="shareTime.html";
			  }
		})
	}
	
	
	/*//分享
	
		function launchStudy() {
			
			 
			 window.location.href="chaoxingshareback://url=http://192.168.10.197:8080/zycourse/phone/html/term.html&title=%henry&sharebacktype=1";
				
				 
		     setTimeout(function() { 
		    	 if (!document.webkitHidden) { window.location = 'https://apps.chaoxing.com/'; } 
		    	 }, 50);

		} */
        

	
	//分享end
	
	//转发图片
	
	var transfer=function(activityUrl){
		var hostPath1=window.location.host;
		var resUid=localStorage.uid;
		var title=$('#user').val();
		title=title+"课表";
		
		
        /*var content = {
            "resTitle": title,
            "resUrl": activityUrl,
            "resLogo": 'http://dev.bp.zcloudtechs.cn/resource/oApiphoto/20180816142033157.jpg',
            "resUid": resUid,
            "toolbarType": 2
        };*/
		
		var icon="http://"+hostPath1+"/"+cutUrl()+"/phone/image/rose.png";
		
		var content = {
	            "resTitle": title,
	            "resUrl": activityUrl,
	            "resLogo": icon,
	            "resUid": resUid,
	            "toolbarType": 2
	        };
        if (resUid != null && resUid != '' && activityUrl != null && activityUrl != '') {
            jsBridge.postNotification("CLIENT_TRANSFER_INFO", {"cataid": 100000015, "content": content});
        }
        
        //setTimeout('gettingBack()',1500);
        
        
	}
	
	var gettingBack=function(){
		if(confirm('返回上一页')){
			window.location="shareTime.html";
		}else{
			window.location="term.html";
		}
	}
	
 	//生成图片
 	var print=function(){
    var w = $("#canv").width();
    //var h = $("#canv").height();
   
    
    w=document.documentElement.clientWidth;//可见区域宽度
   // h=document.documentElement.clientHeight;//可见区域高度
    var h=window.screen.height;
   

		//要将 canvas 的宽高设置成容器宽高的 2 倍
		
		var canvas = document.createElement("canvas");
		
		 canvas.width = w * 2; canvas.height = h * 2; 
		
		canvas.style.width = w + "px"; 
		
		canvas.style.height = h + "px";
		
		var context = canvas.getContext("2d"); 
		
		//然后将画布缩放，将图像放大两倍画到画布上
		
		context.scale(2,2);
		html2canvas($("#canv") ,{
		 onrendered: function(canvas){ 
		var dataUrl = canvas.toDataURL(); 
		//document.body.innerHTML=""; 
		var newImg = document.createElement("img");
		 newImg.src = dataUrl;			
		 dataUrl=dataUrl.split(',');	
		
		 var mes1='{"picture":"'+dataUrl[1]+'","schoolName":"'+schoolName+'","userName":"'+userName+'"}';
		
		 sendPic(mes1);
		
		 } }); } 
      
      //....initial Checkup
      
     /* //根据入学年月和当前时间判断学期
 		var termCal=function(adyear,rgyear,series){
 			adyear=parseInt(adyear);
 			rgyear=parseInt(rgyear);
 			var gap=adyear-rgyear+1;
 			if(series==2){
 				gap=gap+1;
 			}
 			
 			gap=SectionToChinese(gap);
 			series=SectionToChinese(series);
 			
 			return '大'+gap+' '+'第'+series+'学期';
 		}*/
      
      
 		//设置日期格式
   	 Date.prototype.Format = function (fmt) { 
    	    var o = {
    	        "M+": this.getMonth() + 1, //月份 
    	        "d+": this.getDate(), //日 
    	        "h+": this.getHours(), //小时 
    	        "m+": this.getMinutes(), //分 
    	        "s+": this.getSeconds(), //秒 
    	        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
    	        "S": this.getMilliseconds() //毫秒 
    	    };
    	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    	    for (var k in o)
    	    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    	    return fmt;
    	}
      
      
 		//中文节次转阿拉伯数字节次
		var classConvert=function(week){
			if(week=='第一节'){
				return 1;
			}else if(week=='第二节'){
				return 2;
			}else if(week=='第三节'){
				return 3;
			}else if(week=='第四节'){
				return 4;
			}else if(week=='第五节'){
				return 5;
			}else if(week=='第六节'){
				return 6;
			}else if(week=='第七节'){
				return 7;
			}else if(week=='第八节'){
				return 8;
			}else if(week=='第九节'){
				return 9;
			}else if(week=='第十节'){
				return 10;
			}else if(week=='第十一节'){
				return 11;
			}else if(week=='第十二节'){
				return 12;
			}else if(week=='第十三节'){
				return 13;
			}else if(week=='第十四节'){
				return 14;
			}else if(week=='第十五节'){
				return 15;
			}
		}
      
      
      
 		//中文数字转阿拉伯数字
   	 var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
        var chnUnitSection = ["","万","亿","万亿","亿亿"];
        var chnUnitChar = ["","十","百","千"];

        function SectionToChinese(section){
            var strIns = '', chnStr = '';
            var unitPos = 0;
            var zero = true;
            while(section > 0){
                var v = section % 10;
                if(v === 0){
                    if(!zero){
                        zero = true;
                        chnStr = chnNumChar[v] + chnStr;
                    }
                }else{
                    zero = false;
                    strIns = chnNumChar[v];
                    strIns += chnUnitChar[unitPos];
                    chnStr = strIns + chnStr;
                }
                unitPos++;
                section = Math.floor(section / 10);
            }
            return chnStr;
        }
        
        
       	 Array.prototype.indexOf = function (val) {
       		    for (var i = 0; i < this.length; i++) {
       		        if (this[i] == val) return i;
       		    }
       		    return -1;
       		};

       		Array.prototype.remove = function (val) {
       		    var index = this.indexOf(val);
       		    if (index > -1) {
       		        this.splice(index, 1);
       		    }
       		};
       		
       		
       		
       		
       
       		
       		
       							   
       		var newLoading=function(userId,zc,weekshift,ifNapping,napIndex){
       		    
    	   	   	var url=cutUrl()+"/api/course/qryCourseList";
    		    var mes='{"userId":"'+userId+'","zc":"'+zc+'"}';

    		        	        	 $.ajax({
    	         					  "dataType": 'json',
    	         					  "type": "POST",
    	         					  "url": url,
    	         					  "data": mes,
    	         					  "contentType":"application/json;charset=utf-8",
    	         					  "success": function (data, textStatus, jqXHR){
    	         						 //$('.table').children('tbody').children('tr').eq(0).children('td').eq(3).css('background-color','yellow');
    	         						  var raw2=JSON.stringify(data);
    	         						  //console.log(raw2);
    	         						  raw2=$.parseJSON(raw2);
    	         						  //var monday=raw2.mondayDate;
    	         						 // console.log(raw2);
    	         						  var monday1=getMonday();
    	         						  milm=Date.parse(monday1);
    	         						  weekshift=parseInt(weekshift);
	   	         						  var monday='';
	   	         						  var tuesday='';
	   	         						  var wenesday='';
	   	         						  var thirsday='';
	   	         						  var friday='';
	   	         						  var saturday='';
	   	         						  var sunday='';
	   	         						  var cur=new Date().getDay();	         						  
	   	         						  var today=new Date();  	         						  
	       								  var tmilm=Date.parse(today);    								  	         						  
	   	         						  if(weekshift>1&&weekshift<7){
	   	         							  
	   		         						  
	   		         						  var getSun=getSunday();
	   		         						  var sunMil=Date.parse(getSun);
	   		         						  var priorSun=getPriorSun();
	   		         						  var priorSunMil=Date.parse(priorSun);
   		         						  
   		         						 
   		         						  	  if(weekshift<=cur){
   		         						  		if(weekshift==2){
   			         								  
   			         								  tuesday=sunMil-86400000*5;
   			         								  wenesday=sunMil-86400000*4;
   					         						  thirsday=sunMil-86400000*3;
   					         						  friday=sunMil-86400000*2;
   					         						  saturday=sunMil-86400000*1;
   					         						  sunday=sunMil;
   					         						  monday=sunMil+86400000*1;
   			         								  
   			         							  }else if(weekshift==3){
   			         								  
   			         								  wenesday=sunMil-86400000*4;
   					         						  thirsday=sunMil-86400000*3;
   					         						  friday=sunMil-86400000*2;
   					         						  saturday=sunMil-86400000*1;
   					         						  sunday=sunMil;
   					         						  monday=sunMil+86400000*1;
   			         								  tuesday=sunMil+86400000*2;
   			         								  
   			         							  }else if(weekshift==4){
   			         								 
   					         						  thirsday=sunMil-86400000*3;
   					         						  friday=sunMil-86400000*2;
   					         						  saturday=sunMil-86400000*1;
   					         						  sunday=sunMil;
   					         						  monday=sunMil+86400000*1;
   			         								  tuesday=sunMil+86400000*2;
   			         								  wenesday=sunMil+86400000*3;
   			         								  
   			         							  }else if(weekshift==5){
   			         								  
   					         						  friday=sunMil-86400000*2;
   					         						  saturday=sunMil-86400000*1;
   					         						  sunday=sunMil;
   					         						  monday=sunMil+86400000*1;
   			         								  tuesday=sunMil+86400000*2;
   			         								  wenesday=sunMil+86400000*3;
   					         						  thirsday=sunMil+86400000*4;
   			         								  
   			         							  }else if(weekshift==6){
   			         								  
   					         						  saturday=sunMil-86400000*1;
   					         						  sunday=sunMil;
   					         						  monday=sunMil+86400000*1;
   			         								  tuesday=sunMil+86400000*2;
   			         								  wenesday=sunMil+86400000*3;
   					         						  thirsday=sunMil+86400000*4;
   					         						  friday=sunMil+86400000*5;
   			         								  
   			         							  }
   		         						  	  }else{
   		         						  		if(weekshift==2){
   			         								  
   			         								  tuesday=priorSunMil-86400000*5;
   			         								  wenesday=priorSunMil-86400000*4;
   					         						  thirsday=priorSunMil-86400000*3;
   					         						  friday=priorSunMil-86400000*2;
   					         						  saturday=priorSunMil-86400000*1;
   					         						  sunday=priorSunMil;
   					         						  monday=priorSunMil+86400000*1;
   			         								  
   			         							  }else if(weekshift==3){
   			         								  
   			         								  wenesday=priorSunMil-86400000*4;
   					         						  thirsday=priorSunMil-86400000*3;
   					         						  friday=priorSunMil-86400000*2;
   					         						  saturday=priorSunMil-86400000*1;
   					         						  sunday=priorSunMil;
   					         						  monday=priorSunMil+86400000*1;
   			         								  tuesday=priorSunMil+86400000*2;
   			         								  
   			         							  }else if(weekshift==4){
   			         								 
   					         						  thirsday=priorSunMil-86400000*3;
   					         						  friday=priorSunMil-86400000*2;
   					         						  saturday=priorSunMil-86400000*1;
   					         						  sunday=priorSunMil;
   					         						  monday=priorSunMil+86400000*1;
   			         								  tuesday=priorSunMil+86400000*2;
   			         								  wenesday=priorSunMil+86400000*3;
   			         								  
   			         							  }else if(weekshift==5){
   			         								  
   					         						  friday=priorSunMil-86400000*2;
   					         						  saturday=priorSunMil-86400000*1;
   					         						  sunday=priorSunMil;
   					         						  monday=priorSunMil+86400000*1;
   			         								  tuesday=priorSunMil+86400000*2;
   			         								  wenesday=priorSunMil+86400000*3;
   					         						  thirsday=priorSunMil+86400000*4;
   			         								  
   			         							  }else if(weekshift==6){
   			         								  
   					         						  saturday=priorSunMil-86400000*1;
   					         						  sunday=priorSunMil;
   					         						  monday=priorSunMil+86400000*1;
   			         								  tuesday=priorSunMil+86400000*2;
   			         								  wenesday=priorSunMil+86400000*3;
   					         						  thirsday=priorSunMil+86400000*4;
   					         						  friday=priorSunMil+86400000*5;
   			         								  
   			         							  }
   		         						  	  }

   		         						  
   	         						  }else if(weekshift==7){//每周起始日为星期天
   	         							  
   	         							  if(cur==7){
   	         								  
   	         								  monday=tmilm+86400000*1;
   		         							  tuesday=tmilm+86400000*2;
   			         						  wenesday=tmilm+86400000*3;
   			         						  thirsday=tmilm+86400000*4;
   			         						  friday=tmilm+86400000*5;
   			         						  saturday=tmilm+86400000*6;
   			         						  sunday=tmilm;
   	         							  }else{
   	         								  monday=milm;
   		         							  tuesday=milm+86400000*1;
   			         						  wenesday=milm+86400000*2;
   			         						  thirsday=milm+86400000*3;
   			         						  friday=milm+86400000*4;
   			         						  saturday=milm+86400000*5;
   			         						  sunday=milm-86400000; 
   	         							  }
   	         							  
   	         							  
   	         						  }else{//每周起始日为星期一
   	         							  monday=milm;
   	         							  tuesday=milm+86400000*1;
   		         						  wenesday=milm+86400000*2;
   		         						  thirsday=milm+86400000*3;
   		         						  friday=milm+86400000*4;
   		         						  saturday=milm+86400000*5;
   		         						  sunday=milm+86400000*6;
   	         							  
   	         						  }
	   	         						  
	   	         						  
    	         						  monday=new Date(monday).Format("MM-dd");
    	         						  tuesday=new Date(tuesday).Format("MM-dd");
    	         						  wenesday=new Date(wenesday).Format("MM-dd");
    	         						  thirsday=new Date(thirsday).Format("MM-dd");
    	         						  friday=new Date(friday).Format("MM-dd");
    	         						  saturday=new Date(saturday).Format("MM-dd");
    	         						  sunday=new Date(sunday).Format("MM-dd");
    	         						  $('#tdP1').text(monday);
    	         						  $('#tdP2').text(tuesday);
    	         						  $('#tdP3').text(wenesday);
    	         						  $('#tdP4').text(thirsday);
    	         						  $('#tdP5').text(friday);
    	         						  $('#tdP6').text(saturday);
    	         						  $('#tdP7').text(sunday);
    	         						 
    	         						  //markCur();
    	         						  //课程小图标
    	         						
    	         						  
    	         						 $.each(raw2.weeklist,function(i,dom){
    	         							
    	         							  var thid='trang'+dom.zc;
    	         							  var theadrow=dom.xqs;
    	         							  var theadcol=dom.jcdm;
    	         							  
    	         							  theadcol=theadcol.split(',');
    	         							  $.each(theadcol,function(t,doc){
    	         								  if(dom.zc==zc){
    	         									 $('#'+thid).children('tbody').children('tr').eq(theadcol[t]-1).children('td').eq(theadrow-1).css('background','#FF6D6D')
    	         								  }else{
    	         									 $('#'+thid).children('tbody').children('tr').eq(theadcol[t]-1).children('td').eq(theadrow-1).css('background','#7693FF') 
    	         								  }
    	         								 
    	         							  })
    	         							  
    	         							 
    	         						  })
    	         						  
    	         						  
    	         						  
    	        	 				   	  $.each(raw2.list,function(i,dom){
    	        	 				   		 
    	        	 				   		  
    	        	 				   		 
    	        	 				   		 var row=dom.xqs;
    	        	 				   		 var col=dom.jcdm;
    	        	 				   		 
    	        	 				   		 var colArr= new Array(); //定义一数组 
    	        	 				   		 colArr=col.split(',');

    	        	 				   		 row=parseInt(row);
    	        	 				   		 weekshift=parseInt(weekshift);
    	        	 				   		 
    	        	 				   		 row=7-(weekshift-row)+1;
    	        	 				   		
    	        	 				   		 if(row>7){
    	        	 				   			 row=row-7;
    	        	 				   		 } 
    	        	 				   		 
    	        	 				   		 var topId='trang'+zc;
    	        	 				   		 for(var m=0;m<colArr.length;m++){
    	        	 				   			 var colIndex=colArr[m]-1;
    	        	 				   			
    	        	 				   			 if(ifNapping){
    	        	 				   			 if(colIndex>napIndex-1){            	 				   			 
    	             	 				   			colIndex=colArr[m];             	 				   		                 	 				   			
    	             	 				   			} 
    	        	 				   			 }
    	        	 				   			 
    	        	 				   			 
    	        	 				   			 
    	        	 				   			 //----
    	        	 				   			var trueClasIndex=colArr[0]-1;
    		        	 				   		 var span0=parseInt(colArr.length)-1;
    		        	 				   		 var span1=parseInt(colArr[0]);
    		        	 				   		 var span2=parseInt(napIndex);
    		        	 				   		 var oneside=span0+span1;
    		        	 				   		 
    		        	 				   		//var tdClass='meg'+dom.color;
			        	 				   		
			        	 				   		//$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
			        	 				   		//$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass(tdClass);
    		        	 				   		 
    		        	 				   		 if(oneside<=parseInt(napIndex)||parseInt(napIndex)==0){
    		        	 				   			// console.log("早上以内")
    		        	 				   		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
    		        	 				   		 	
    		        	 				   			if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
    		        	 				   				
    		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
    		        	 				   			}else{
    		        	 				   				
    		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
    		        	 				   			}
    		        	 				   			
    		        	 				   		    		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).attr('rowspan',colArr.length)
    			        	 				   		 
    		        	 				   		    
    			        	 				   		for(var m=1;m<colArr.length;m++){
    		        	 				   				
    		        	 				   				$('.table').children('tbody').children('tr').eq(colArr[m]-1).children('td').eq(row).hide();//隐藏节次后几节
    		        	 				   			}
    		        	 				   		    		
    		        	 				   		 }else{
    		        	 				   			 
    		        	 				   			 if(span1>span2){
    		        	 				   				
    		        	 				   				// console.log('aftermoon', row)
    		        	 				   				 
    		        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).addClass('ok');
    		             	 				   		 	
    			             	 				   		if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
    			             	 				   			$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
    			             	 				   		}else{
    			             	 				   			$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
    			             	 				   		}
    		         	 				   		 		$('.table').children('tbody').children('tr').eq(colArr[0]).children('td').eq(row).attr("rowspan",parseInt(colArr.length));
    		         	 				   		 		for(var m=1;m<colArr.length;m++){
    		         	 				   		 			
    		         	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[m]).children('td').eq(row).hide();//隐藏节次后几节
    		         	 				   		 		}
    		         	 				   		 		

    			        	 				   		

    		        	 				   			 }else{
    		        	 				   				 
    		        	 				   				 console.log('morning to afternoon')
    		        	 				   				$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).addClass('ok');
    		        	 				   				if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
    		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>@"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
    		        	 				   				}else{
    		        	 				   					$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><input type='hidden' value="+dom.color+" class='color'>");
    		        	 				   				}
    		            	 				   		 	
    		        	 				   		 		//console.log(parseInt(colArr[0])+"==="+parseInt(napIndex)+"==="+parseInt(colArr[colArr.length-1])+"==="+parseInt(napIndex));	
    		        	 				   		 		$('.table').children('tbody').children('tr').eq(colArr[0]-1).children('td').eq(row).attr("rowspan",parseInt(colArr.length)+1);
    		        	 				   		 		
    		        	 				   		 		for(var m=1;m<colArr.length;m++){
    		        	 				   		 			
    		        	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[m]-1).children('td').eq(row).hide();//隐藏节次后几节
    		        	 				   		 		}
    		        	 				   		 			$('.table').children('tbody').children('tr').eq(colArr[colArr.length-1]).children('td').eq(row).hide();//隐藏

    		        	 				   							        	 				   			
    		        	 				   			 }
    		        	 				   			 
    		        	 				   			
    		        	 				   			 
    		        	 				   		 }     	 				   			 	        	 				   			
    	        	 				   			
    	        	 				   			
    	        	 				   		 	
    	        	 				   		 }	        	 				   		 
    	        	 				   		
    	        	 				   	  })
    	        	 				   	  
    	        	 				   	  
    	        	 				   	  
    	        	 				   	   $('.ok').each(function(){
    	        	 				   		   
    	        	 				   		if($(this).attr('rowspan')>1){
		        	 				   			if($(this).children('.cn').text().length+$(this).children('.room').text().length<24){
    		        	 				   			$(this).children('.cn').css('white-space','normal')
    		        	 				   			$(this).children('.room').css('white-space','normal')
    		        	 				   			$(this).children('.cn').css('display','block')
    		        	 				   			$(this).children('.room').css('display','block')
		        	 				   			}else{
    		        	 				   			$(this).children('.cn').css('-webkit-line-clamp','3')
    		        	 				   			$(this).children('.room').css('-webkit-line-clamp','3')
		        	 				   			}
		        	 				   			
		        	 				   			
		        	 				   		}
    	        	 				   		
    	        	 				   	var coloring=$(this).children('.color').val();
		        	 				   	var colorClass='meg'+coloring;
		        	 				   	$(this).addClass(colorClass)
    	        	 				   		   				
    	        	 				   		/*var lecture=$(this).children('.cn').text();
    	        	 				   		if(lecture.indexOf('语文')>-1||lecture.indexOf('体育')>-1||lecture.indexOf('导论')>-1||lecture.indexOf('实验')>-1||lecture.indexOf('系统')>-1||lecture.indexOf('代数')>-1){
     				   		   					$(this).addClass('meg'+0);
     				   		   				}else if(lecture.indexOf('数学')>-1||lecture.indexOf('社会')>-1||lecture.indexOf('电子')>-1||lecture.indexOf('医学')>-1||lecture.indexOf('工程')>-1||lecture.indexOf('哲学')>-1){
     				   		   					$(this).addClass('meg'+1);
     				   		   				}else if(lecture.indexOf('管理')>-1||lecture.indexOf('概论')>-1||lecture.indexOf('力学')>-1||lecture.indexOf('护理')>-1||lecture.indexOf('网络')>-1||lecture.indexOf('商务')>-1){
     				   		   					$(this).addClass('meg'+2);
     				   		   				}else if(lecture.indexOf('市场')>-1||lecture.indexOf('文化')>-1||lecture.indexOf('制图')>-1||lecture.indexOf('生物')>-1||lecture.indexOf('结构')>-1||lecture.indexOf('精读')>-1){
     				   		   					$(this).addClass('meg'+3);
     				   		   				}else if(lecture.indexOf('机械')>-1||lecture.indexOf('艺术')>-1||lecture.indexOf('统计')>-1||lecture.indexOf('健康')>-1||lecture.indexOf('软件')>-1||lecture.indexOf('世界')>-1){
     				   		   					$(this).addClass('meg'+4);
     				   		   				}else if(lecture.indexOf('设计')>-1||lecture.indexOf('日语')>-1||lecture.indexOf('物理')>-1||lecture.indexOf('信息')>-1||lecture.indexOf('应用')>-1||lecture.indexOf('足球')>-1){
     				   		   					$(this).addClass('meg'+5);
     				   		   				}else if(lecture.indexOf('医药')>-1||lecture.indexOf('英语')>-1||lecture.indexOf('分析')>-1||lecture.indexOf('理论')>-1||lecture.indexOf('实践')>-1||lecture.indexOf('篮球')>-1){
     				   		   					$(this).addClass('meg'+6);
     				   		   				}else if(lecture.indexOf('口腔')>-1||lecture.indexOf('经济')>-1||lecture.indexOf('口语')>-1||lecture.indexOf('导论')>-1||lecture.indexOf('光')>-1||lecture.indexOf('政治')>-1){
     				   		   					$(this).addClass('meg'+7);
     				   		   				}else if(lecture.indexOf('计算机')>-1||lecture.indexOf('数据')>-1||lecture.indexOf('有机')>-1||lecture.indexOf('生理')>-1||lecture.indexOf('材料')>-1||lecture.indexOf('营销')>-1){
     				   		   					$(this).addClass('meg'+8);
     				   		   				}else if(lecture.indexOf('会计')>-1||lecture.indexOf('基础')>-1||lecture.indexOf('积分')>-1||lecture.indexOf('思想')>-1||lecture.indexOf('电器')>-1||lecture.indexOf('金融')>-1){
     				   		   					$(this).addClass('meg'+9);
     				   		   				}else if(lecture.indexOf('财务')>-1||lecture.indexOf('设计')>-1||lecture.indexOf('原理')>-1||lecture.indexOf('马克思')>-1||lecture.indexOf('欣赏')>-1||lecture.indexOf('动力')>-1){
     				   		   					$(this).addClass('meg'+10);
     				   		   				}else{
     				   		   					$(this).addClass('color'+10);
     				   		   				}*/
    	        	 				   		
    	        	 				   	/*var lecture=$(this).children('.cn').text();
	        	 				   		if(lecture.indexOf('语文')>-1||lecture.indexOf('古代')>-1||lecture.indexOf('传播')>-1||lecture.indexOf('采访')>-1||lecture.indexOf('实用')>-1||lecture.indexOf('几何')>-1||lecture.indexOf('模型')>-1||lecture.indexOf('技术')>-1||lecture.indexOf('成本')>-1||lecture.indexOf('医药')>-1){
					   		   					$(this).addClass('meg'+0);
					   		   				}else if(lecture.indexOf('语言')>-1||lecture.indexOf('近代')>-1||lecture.indexOf('大众')>-1||lecture.indexOf('报纸')>-1||lecture.indexOf('翻译')>-1||lecture.indexOf('函数')>-1||lecture.indexOf('政治')>-1||lecture.indexOf('理论')>-1||lecture.indexOf('原理')>-1||lecture.indexOf('统计')>-1){
					   		   					$(this).addClass('meg'+1);
					   		   				}else if(lecture.indexOf('汉语')>-1||lecture.indexOf('现代')>-1||lecture.indexOf('采访')>-1||lecture.indexOf('制作')>-1||lecture.indexOf('精读')>-1||lecture.indexOf('概率')>-1||lecture.indexOf('体育')>-1||lecture.indexOf('数字')>-1||lecture.indexOf('结构')>-1||lecture.indexOf('信号')>-1){
					   		   					$(this).addClass('meg'+2);
					   		   				}else if(lecture.indexOf('文学')>-1||lecture.indexOf('中华')>-1||lecture.indexOf('电视')>-1||lecture.indexOf('文案')>-1||lecture.indexOf('打字')>-1||lecture.indexOf('模型')>-1||lecture.indexOf('实验')>-1||lecture.indexOf('生化')>-1||lecture.indexOf('系统')>-1||lecture.indexOf('货币')>-1){
					   		   					$(this).addClass('meg'+3);
					   		   				}else if(lecture.indexOf('写作')>-1||lecture.indexOf('世界')>-1||lecture.indexOf('编辑')>-1||lecture.indexOf('美术')>-1||lecture.indexOf('语法')>-1||lecture.indexOf('电子')>-1||lecture.indexOf('工程')>-1||lecture.indexOf('动物')>-1||lecture.indexOf('通信')>-1||lecture.indexOf('思想')>-1){
					   		   					$(this).addClass('meg'+4);
					   		   				}else if(lecture.indexOf('英美')>-1||lecture.indexOf('考古')>-1||lecture.indexOf('事业')>-1||lecture.indexOf('信息')>-1||lecture.indexOf('金融')>-1||lecture.indexOf('网络')>-1||lecture.indexOf('制图')>-1||lecture.indexOf('生理')>-1||lecture.indexOf('软件')>-1||lecture.indexOf('原理')>-1){
					   		   					$(this).addClass('meg'+5);
					   		   				}else if(lecture.indexOf('应用')>-1||lecture.indexOf('历史')>-1||lecture.indexOf('广播')>-1||lecture.indexOf('平面')>-1||lecture.indexOf('商务')>-1||lecture.indexOf('设计')>-1||lecture.indexOf('机械')>-1||lecture.indexOf('植物')>-1||lecture.indexOf('技术')>-1||lecture.indexOf('安全')>-1){
					   		   					$(this).addClass('meg'+6);
					   		   				}else if(lecture.indexOf('文化')>-1||lecture.indexOf('地理')>-1||lecture.indexOf('新闻')>-1||lecture.indexOf('广告')>-1||lecture.indexOf('外贸')>-1||lecture.indexOf('日语')>-1||lecture.indexOf('工业')>-1||lecture.indexOf('仪器')>-1||lecture.indexOf('电路')>-1||lecture.indexOf('土木')>-1){
					   		   					$(this).addClass('meg'+7);
					   		   				}else if(lecture.indexOf('文献')>-1||lecture.indexOf('文选')>-1||lecture.indexOf('电视')>-1||lecture.indexOf('市场')>-1||lecture.indexOf('行政')>-1||lecture.indexOf('营销')>-1||lecture.indexOf('模拟')>-1||lecture.indexOf('遗传')>-1||lecture.indexOf('数字')>-1||lecture.indexOf('主义')>-1){
					   		   					$(this).addClass('meg'+8);
					   		   				}else if(lecture.indexOf('美学')>-1||lecture.indexOf('史学')>-1||lecture.indexOf('报刊')>-1||lecture.indexOf('思想')>-1||lecture.indexOf('外语')>-1||lecture.indexOf('管理')>-1||lecture.indexOf('材料')>-1||lecture.indexOf('生态')>-1||lecture.indexOf('java')>-1||lecture.indexOf('人体')>-1){
					   		   					$(this).addClass('meg'+9);
					   		   				}else if(lecture.indexOf('应用')>-1||lecture.indexOf('中外')>-1||lecture.indexOf('听力')>-1||lecture.indexOf('综合')>-1||lecture.indexOf('计算机')>-1||lecture.indexOf('数学')>-1||lecture.indexOf('食品')>-1||lecture.indexOf('质量')>-1||lecture.indexOf('经济')>-1||lecture.indexOf('科学')>-1){
					   		   					$(this).addClass('meg'+10);
					   		   				}else if(lecture.indexOf('基础')>-1||lecture.indexOf('关系')>-1||lecture.indexOf('训练')>-1||lecture.indexOf('泛读')>-1||lecture.indexOf('信息')>-1||lecture.indexOf('物理')>-1||lecture.indexOf('卫生')>-1||lecture.indexOf('环境')>-1||lecture.indexOf('会计')>-1||lecture.indexOf('病理')>-1){
					   		   					$(this).addClass('meg'+11);
					   		   				}else if(lecture.indexOf('概论')>-1||lecture.indexOf('国际')>-1||lecture.indexOf('外国')>-1||lecture.indexOf('语音')>-1||lecture.indexOf('分析')>-1||lecture.indexOf('化学')>-1||lecture.indexOf('细胞')>-1||lecture.indexOf('导论')>-1||lecture.indexOf('财务')>-1||lecture.indexOf('临床')>-1){
					   		   					$(this).addClass('meg'+12);
					   		   				}else if(lecture.indexOf('口语')>-1||lecture.indexOf('中外')>-1||lecture.indexOf('写作')>-1||lecture.indexOf('英文')>-1||lecture.indexOf('代数')>-1||lecture.indexOf('生物')>-1||lecture.indexOf('分子')>-1||lecture.indexOf('数据')>-1||lecture.indexOf('咨询')>-1||lecture.indexOf('药理')>-1){
					   		   					$(this).addClass('meg'+13);
					   		   				}else{
					   		   					$(this).addClass('meg'+14);
					   		   				}*/
	        	 				   		
    	        	 				   		/*var x=randomNum(0,10);
		        	 				   		$(this).addClass('meg'+x);*/
            		        	 				   		
            		        	 				   			/*if($(this).children('.cn').text()=='语文'||$(this).children('.cn').text()=='大学语文'||$(this).children('.cn').text()=='Chinese'){
            		        	 				   				$(this).addClass('meg'+1);
            		        	 				   			}else if($(this).children('.cn').text()=='英语'||$(this).children('.cn').text()=='大学英语'||$(this).children('.cn').text()=='English'){
            		        	 				   			$(this).addClass('meg'+2);
            		        	 				   			}else if($(this).children('.cn').text()=='生物'||$(this).children('.cn').text()=='Biology'){
            		        	 				   				$(this).addClass('meg'+3);
            		        	 				   			}else if($(this).children('.cn').text()=='体育'||$(this).children('.cn').text()=='PE'){
            		        	 				   				$(this).addClass('meg'+4);
            		        	 				   			}else if($(this).children('.cn').text()=='物理'||$(this).children('.cn').text()=='高能物理'||$(this).children('.cn').text()=='天体物理'||$(this).children('.cn').text()=='核物理'||$(this).children('.cn').text()=='Physic'){
            		        	 				   				$(this).addClass('meg'+5);
            		        	 				   			}
            		        	 				   			else if($(this).children('.cn').text()=='生物'){
            		    	 				   					$(this).addClass('color'+6);
            		    	 				   				}
            		        	 				   			else if($(this).children('.cn').text()=='化学'||$(this).children('.cn').text()=='Chemistry'||$(this).children('.cn').text()=='无机化学'||$(this).children('.cn').text()=='有机化学'){
            			 				   						$(this).addClass('meg'+7);
            			 				   					}
            		        	 				   			else if($(this).children('.cn').text()=='地理'||$(this).children('.cn').text()=='中国地理'||$(this).children('.cn').text()=='中国国家地理'||$(this).children('.cn').text()=='世界地理'||$(this).children('.cn').text()=='Geography'){
            			 				   						$(this).addClass('meg'+8);
            			 				   					}else if($(this).children('.cn').text()=='数学'||$(this).children('.cn').text()=='高等数学'||$(this).children('.cn').text()=='Math'){
            			 				   						$(this).addClass('meg'+9);
            			 				   					}else if($(this).children('.cn').text()=='音乐'||$(this).children('.cn').text()=='Music'){
            			 				   						$(this).addClass('meg'+10);
            			 				   					}else if($(this).children('.cn').text()=='政治'||$(this).children('.cn').text()=='Political'){
            			 				   						$(this).addClass('meg'+11);
            			 				   					}else if($(this).children('.cn').text()=='历史'||$(this).children('.cn').text()=='中国历史'||$(this).children('.cn').text()=='世界历史'||$(this).children('.cn').text()=='History'){
            			 				   						$(this).addClass('color'+12);
            			 				   					}else{
            			 				   						$(this).addClass('color'+19);
            			 				   					}*/
            		        	 				   			
            			 				   					
            		        	 				   			
            		        	 				   		 })
    	        	 				   	  
    	        	 				   	  
    	        	 				   	  
    	        	 				   		 
    	        	 				   		
    	        	 				   		 
    	        	 				   		 //非当前周
    	         						 $.each(raw2.kcList,function(i,dom){
    	        	 				   		 
    	        	 				   		 var row=dom.xqs;
    	        	 				   		 var col=dom.jcdm;
    	        	 				   		 
    	        	 				   		 var colArr= new Array(); //定义一数组 
    	        	 				   		 colArr=col.split(',');

    	        	 				   		 row=parseInt(row);
    	        	 				   		 weekshift=parseInt(weekshift);
    	        	 				   		 
    	        	 				   		 row=7-(weekshift-row)+1;
    	        	 				   		
    	        	 				   		 if(row>7){
    	        	 				   			 row=row-7;
    	        	 				   		 } 
    	        	 				   		 
    	        	 				   		 var topId='trang'+zc;
    	        	 				   		 for(var m=0;m<colArr.length;m++){
    	        	 				   			 var colIndex=colArr[m]-1;
    	        	 				   			
    	        	 				   			 if(ifNapping){
    	        	 				   			 if(colIndex>napIndex-1){            	 				   			 
    	             	 				   			colIndex=colArr[m];             	 				   		                 	 				   			
    	             	 				   			} 
    	        	 				   			 }
    	        	 				   			
    	        	 				   			var resident=$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).attr('class');
    	        	 				   			
    	        	 				   			if(resident!=undefined){
    	        	 				   				return;
    	        	 				   			}
    	        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).addClass('notCurrent');
    		        	 				   		if(dom.room!=''&&dom.room!=null&&dom.room!='null'){
    		        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='teacher'>[非本周]</span><span class='cn'>"+dom.courseName+"</span><input type='hidden' class='noneId' value="+dom.id+"><input type='hidden' class='noneIndex' value="+colIndex+"><input type='hidden' class='noneweek' value="+dom.xqs+"><span class='room'>@"+dom.room+"</span>");
    		        	 				   		}else{
    		        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='teacher'>[非本周]</span><span class='cn'>"+dom.courseName+"</span><input type='hidden' class='noneId' value="+dom.id+"><input type='hidden' class='noneIndex' value="+colIndex+"><input type='hidden' class='noneweek' value="+dom.xqs+"><span class='room'>"+dom.room+"</span>");
    		        	 				   		}
    	        	 				   			
    	        	 				   		    
    	        	 				   		 	
    	        	 				   		 }	        	 				   		 
    	        	 				   		
    	        	 				   	  })
    	        	 				   	  
    	        	 				   	  $('.notCurrent').each(function(){
    	        	 				   		  $(this).css('background','#CDCED7')
    	        	 				   	  })
    	        	 				   	  var otherset=[];
    	         						 var strotherset='';
    	        	 				   	  $('.notCurrent').each(function(){
    	        	 				   		  if($(this).css('display')!='none'){
    	        	 				   			  var noneweek=$(this).children('.noneweek').val();
    		        	 				   		  var noneId=$(this).children('.noneId').val();
    		        	 				   		  var noneIndex=$(this).children('.noneIndex').val();
    		        	 				   		  console.log('星期：'+noneweek+' 节次：'+noneIndex+' 课程id:'+noneId);
    		        	 				   		  
    		        	 				   		strotherset+='{'+'"'+'week'+'"'+':'+'"'+noneweek+'"'+','+'"'+'series'+'"'+':'+'"'+noneIndex+'"'+','+'"'+'id'+'"'+':'+'"'+noneId+'"'+'}'+',';
    		        	 				   		otherset.push(noneId)
    	        	 				   		  }
    	        	 				   		  
    	        	 				   		 
    	        	 				   		  
    	        	 				   	  })
    	        	 				   	  strotherset=strotherset.substring(0,strotherset.length-1);
    	        	 				   	  strotherset='['+strotherset+']';
    	        	 				   	  strotherset=$.parseJSON(strotherset);
    	        	 				   
    	        	 				   	  
    	        	 				   	 
    	        	 				   	  var thao='';
    	        	 				   	  var vivian=[];
    	        	 				   	  for(i=0;i<unique1(otherset).length;i++){
    	        	 				   		  
    	        	 				   		  var clsstr=[];
    	        	 				   		  var wk='';
    	        	 				   		  
    	        	 				   		  for(var j=0;j<strotherset.length;j++){
    	        	 				   			  
    	        	 				   			  if(unique1(otherset)[i]==strotherset[j].id){
    	        	 				   				clsstr.push(strotherset[j].series);
    	        	 				   				wk=strotherset[j].week;
	    	        	 				   			wk=7-(weekshift-wk)+1;
		    	        	 				   		
			   	        	 				   		 if(wk>7){
			   	        	 				   			 wk=wk-7;
			   	        	 				   		 } 
    	        	 				   			  }
    	        	 				   			  
    	        	 				   		  }
    	        	 				   		  
    	        	 				   		  
    	        	 				   		  
    	        	 				   		  //...........................start
    	        	 				   		 if(parseInt(clsstr[0])+parseInt(clsstr.length)<=parseInt(napIndex)||parseInt(napIndex)==0){
    		        	 				   			 console.log("早上以内")
    		        	 				   		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
    		        	 				   		 	
    		        	 				   			
    		        	 				   				
    		        	 				   					$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
    		        	 				   				
    		        	 				   			
    		        	 				   		    		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr('rowspan',clsstr.length)
    			        	 				   		 
    		        	 				   		    
    			        	 				   		for(var m=1;m<clsstr.length;m++){
    		        	 				   				
    		        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
    		        	 				   			}
    		        	 				   		    		
    		        	 				   		 }else{
    		        	 				   			 
    		        	 				   			 if(parseInt(clsstr[0])>parseInt(napIndex)){
    		        	 				   				
    		        	 				   				// console.log('aftermoon', row)
    		        	 				   				 
    		        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
    		             	 				   		 	$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
    		         	 				   		 		
    		         	 				   		 		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr("rowspan",parseInt(clsstr.length));
    		         	 				   		 		for(var m=1;m<clsstr.length;m++){
    		         	 				   		 			//console.log(colArr[m]-1+"   "+row);
    		         	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
    		         	 				   		 		}
    		         	 				   		 		// $('.table').children('tbody').children('tr').eq(colArr[colArr.length-1]).children('td').eq(row).hide();//隐藏

    			        	 				   		

    		        	 				   			 }else{
    		        	 				   				
    		        	 				   				// console.log('morning to afternoon')
    		        	 				   				$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).addClass('meg');
    		            	 				   		 	$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).append("<span class='cn'></span><span class='room'></span>");
    		        	 				   		 		//console.log(parseInt(colArr[0])+"==="+parseInt(napIndex)+"==="+parseInt(colArr[colArr.length-1])+"==="+parseInt(napIndex));	
    		        	 				   		 		$('.table').children('tbody').children('tr').eq(clsstr[0]).children('td').eq(wk).attr("rowspan",parseInt(clsstr.length)+1);
    		        	 				   		 		
    		        	 				   		 		for(var m=1;m<clsstr.length;m++){
    		        	 				   		 			
    		        	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[m]).children('td').eq(wk).hide();//隐藏节次后几节
    		        	 				   		 		}
    		        	 				   		 			$('.table').children('tbody').children('tr').eq(clsstr[clsstr.length-1]+1).children('td').eq(wk).hide();//隐藏

    		        	 				   							        	 				   			
    		        	 				   			 }
    		        	 				   			 
    		        	 				   			
    		        	 				   			 
    		        	 				   		 } 
    	        	 				   		  
    	        	 				   		  //....................end
    	        	 				   	  }
    	        	 				   	  
    	        	 				   	  

    	        	 				   	  
    	         						  //非当前end	 
    	        	 				   	  
    	        	 					  
			        	 				   	$('.notCurrent').each(function(){
		        	 				   			/*if($(this).attr('rowspan')>1){
		        	 				   				$(this).children('.cn').css('-webkit-line-clamp','2')
		        	 				   			}else{
		        	 				   				$(this).children('.cn').css('-webkit-line-clamp','1')
		        	 				   			}*/
			        	 				   		
			        	 				   	if($(this).attr('rowspan')>1){
		        	 				   			if($(this).children('.cn').text().length+$(this).children('.room').text().length<20){
    		        	 				   			$(this).children('.cn').css('white-space','normal')
    		        	 				   			$(this).children('.room').css('white-space','normal')
    		        	 				   			$(this).children('.cn').css('display','block')
    		        	 				   			$(this).children('.room').css('display','block')
		        	 				   			}else{
    		        	 				   			$(this).children('.cn').css('-webkit-line-clamp','3')
    		        	 				   			$(this).children('.room').css('-webkit-line-clamp','3')
		        	 				   			}
		        	 				   			
		        	 				   			
		        	 				   		}else{
		        	 				   			if($(this).children('.room').text().length==0){
		        	 				   				$(this).children('.cn').css('-webkit-line-clamp','2')
		        	 				   			}else{
		        	 				   				$(this).children('.cn').css('-webkit-line-clamp','1')
		        	 				   			}
		        	 				   		    
		        	 				   		}
		        	 				   			
			        	 				   		/*if($(this).attr('rowspan')>1){
		        	 				   				$(this).children('.cn').css('-webkit-line-clamp','3');
		        	 				   				$(this).children('.room').css('-webkit-line-clamp','2');
		        	 				   			}else{
		        	 				   				$(this).children('.cn').css('-webkit-line-clamp','1');
		        	 				   				$(this).children('.room').css('-webkit-line-clamp','1');					
		        	 				   			}*/
		        	 				   			
		        	 				   		}) 	  
			        	 				   	  
    	         						  
    	        	 				   		
    	        	 				   		
    	        	 				   		 
    	        	 				   		 
    	        	 				   		 
    	        	 				   	/*  $('td').each(function(){ */
    	        	 				   		 $('.table').children('tbody').children('tr').children('td').each(function(){
    	        	 				   		 $(this).click(function(){
    	        	 				   			
    	        	 				   			
    	        	 				   			$('td').removeClass("addTd");
    	        	 				   			$('td').children('.addImgA').remove();
    	        	 				   			
    	        	 				   			var row=$(this).parent().prevAll().length+1; 
    	   	 				   			 		var col=$(this).prevAll().length;
    	   	 				   			 		
    	   	 				   			 		if(ifNapping){
    			   	 				   			 	if(row==napIndex+1||col==0){
    		   	 				   				 		return;
    		   	 				   			 		}
    	   	 				   			 		}else{
    	   	 				   			 			if(col==0){
    	   	 				   			 				return;
    	   	 				   			 			}
    	   	 				   			 		}
    	   	 				   			 		
    	   	 				   			 		
    	   	 				   			 		if(ifNapping&&row>napIndex){
    	   	 				   						row=row-1;
    	   	 				   			 		}
    	   	 				   					var rawstr=$('.table').children('thead').children('tr').children('td').eq(col).text();
    		 				   			 		rawstr=rawstr.substring(0,2);
    		 				   			 		rawstr=interpret(rawstr);
    	        	 				   			
    	        	 				   			var lesson=$(this).children('.cn').text();
    	        	 				   			var teacher=$(this).children('.teacher').text(); 
    	        	 				   			var paraArr=[];
    	        	 				   			paraArr.push(lesson);
    	        	 				   			paraArr.push(row);
    	        	 				   			paraArr.push(rawstr);
    	        	 				   			localStorage.paraArr=paraArr;
    	        	 				   			if(lesson.length>0){
    	        	 				   				
    	        	 				   				
    	        	 				   			
    	        	 				   				localStorage.lesson=lesson;
    	        	 				   				
    	        	 				   				
    	        	 				   				window.location='courseDetail.html';
    	        	 				   				
    	        	 				   				
    	        	 				   			}else{
    	        	 				   			 
    	        	 				   			 
    	        	 				   			
    	        	 				   			$(this).addClass("addTd");
    	        	 				   			$(this).append("<a href='javascript:;' class='addImgA'><img src='../image/addCourse.png' alt=''></a>");
    	        	 				   			$('.addImgA').click(function(){
    	        	 				   				localStorage.row=row;
    	        	 				   				localStorage.rawstr=rawstr;
    	        	 				   				window.location='singleCourse.html';
    	        	 				   			})
    	        	 				           
    	        	 				   			 
    	        	 				   			}
    	        	 				   			
    	        	 				   		 })
    	        	 				   	 })
    	        	 
    	         					  }
    		 						  }) 
    		        	        
    		 						 
    		}
       		
       		

       		
 
    	
    	
       		
       		
       		function unique1(array){ 
       			var n = []; //一个新的临时数组 
       			//遍历当前数组 
       			for(var i = 0; i < array.length; i++){ 
       			//如果当前数组的第i已经保存进了临时数组，那么跳过， 
       			//否则把当前项push到临时数组里面 
       			if (n.indexOf(array[i]) == -1) n.push(array[i]); 
       			} 
       			return n; 
       			}
    	
       		var markCur=function(){
					var liveDate=new Date().getDay();
				  if(liveDate==1){
					  textColor('#tdP1');
				  }else if(liveDate==2){
					  textColor('#tdP2');
				  }else if(liveDate==3){
					  textColor('#tdP3');
				  }else if(liveDate==4){
					  textColor('#tdP4');
				  }else if(liveDate==5){
					  textColor('#tdP5');
				  }else if(liveDate==6){
					  textColor('#tdP6');
				  }else if(liveDate==7){
					  textColor('#tdP7');
				  }
				}
    	
    	//获取星期一日期
			
			var getMonday=function(){
				var date=new Date();
			var weekDate=new Date().getDay();
			var weekGap=weekDate-1;
			date=date.Format('yyyy-MM-dd');
			var milvalue=Date.parse(date);
			var mondayMil=milvalue-weekGap*86400000;
			
			var x=new Date(milvalue).Format('yyyy-MM-dd');
			var y=new Date(mondayMil).Format('yyyy-MM-dd');
			
			
			return y;
			
			}
			
			
			//获取星期一日期
				
				var getMonday=function(){
					var date=new Date();
				var weekDate=new Date().getDay();
				
				var weekGap=weekDate-1;
				
				date=date.Format('yyyy-MM-dd');
				var milvalue=Date.parse(date);
				var mondayMil=milvalue-weekGap*86400000;
				
				var x=new Date(milvalue).Format('yyyy-MM-dd');
				var y=new Date(mondayMil).Format('yyyy-MM-dd');
				
				
				return y;
				
				}
				
				
				
				//根据星期一计算星期天日期
				
				var calculateSun=function(monday){
					var rawMonday=Date.parse(monday);
				var milSun=rawMonday+86400000*6;
				var y=new Date(milSun).Format('yyyy-MM-dd');
				return y;
				
				}
				
				//根据星期一计算上一个星期天日期
				
				var calculatePriorSun=function(monday){
					
					var rawMonday=Date.parse(monday);
				var milSun=rawMonday-86400000;
				var y=new Date(milSun).Format('yyyy-MM-dd');
				return y;
				
				}
				
				
				
				
				//获取星期天日期
				
				var getSunday=function(){
					var date=new Date();
				var weekDate=new Date().getDay();
				
				var weekGap=7-weekDate;
				
				date=date.Format('yyyy-MM-dd');
				var milvalue=Date.parse(date);
				var mondayMil=milvalue+weekGap*86400000;
				
				var x=new Date(milvalue).Format('yyyy-MM-dd');
				var y=new Date(mondayMil).Format('yyyy-MM-dd');
				
				
				return y;
				
				}
				
				//获取上周天日期
				
				var getPriorSun=function(){
					var date=new Date();
				var weekDate=new Date().getDay();
				
				var weekGap=7-weekDate;
				
				date=date.Format('yyyy-MM-dd');
				var milvalue=Date.parse(date);
				var mondayMil=milvalue+weekGap*86400000;
				mondayMil=mondayMil-86400000*7;
				var x=new Date(milvalue).Format('yyyy-MM-dd');
				var y=new Date(mondayMil).Format('yyyy-MM-dd');
				
				
				return y;
				
				}
    	
    	
    
        
        
       