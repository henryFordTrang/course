var objuserId="";
//var launchStudyAndSignIn=function() { window.location = "cxstudy://cxstudy/login?fid=xxx&fidType=xxx&token=xxx"; setTimeout(function() { if (!document.webkitHidden) { window.location = 'https://apps.chaoxing.com/'; } }, 50); }
function launchStudy() { window.location = "cxstudy://"; setTimeout(function() { if (!document.webkitHidden) { window.location = 'https://apps.chaoxing.com/'; } }, 1000); } 

function GetQueryString(name){
	var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if(r!=null)return  unescape(r[2]);
	return null;
	}	
objuserId=GetQueryString("userId");


   	   var ua = ""
	   function get_broswer_info(){
	 	
      ua = navigator.userAgent.toLowerCase();
      
        if(ua.indexOf("chaoxingstudy")>-1){//是否为学习通扫码

				var userId=localStorage.userId;				
				var uid=localStorage.uid;				
				var fid=localStorage.fid;				
				var schoolName=localStorage.school1;				
				var username=localStorage.userName;
				//alert(localStorage.c);
				//alert(localStorage.userId+"  "+localStorage.uid+" "+localStorage.fid+" "+localStorage.school1+" "+localStorage.userName)
				
				var copymes='{"userId":"'+userId+'","uid":"'+uid+'","fid":"'+fid+'","schoolName":"'+schoolName+'","username":"'+username+'","copyObjectUserId":"'+objuserId+'"}';
				var host=window.location.host;
				var url="http://"+host+cutUrl()+"/api/course/copyCourseInfo";
				
				
				$.ajax({
			         "dataType": 'json',
			         "type": "POST",
			         "async":false,
			         "url": cutUrl()+"/api/course/copyCourseInfo",
			         "data": copymes,
			         "contentType":"application/json;charset=utf-8",
			         "success": function (data, textStatus, jqXHR){
			        	 var raw=JSON.stringify(data);
			        	 
			        	 var currentWeek=localStorage.currentWeek;    			        	 
			        	 raw=$.parseJSON(raw);
			        	 //alert(raw.error.message);
			        	 $.MsgBox.Alert('温馨提示',raw.error.message);
			        	 if(raw.error.id=='0000'){
			        		 //window.location='newCourse.html';
			        		 window.location='term.html';
			        		 
			        	 }
			        	 
			        	 
			         }
				 })
				
			
        }else{
      	  
        	
        	launchStudy1(objuserId);
      	 // return;
         // window.location.href = "https://appswh.chaoxing.com/app/quiz/main?appId=1000";//跳转到学习通界面


        }
    } 
 $(function(){

   get_broswer_info();  
/*  $('#save').click(function(){
    $(this).toggleClass("unInput").toggleClass("input");
  })
  
  
  $('#save').click(function(){
	 
	  launchStudy();
  })*/
    


 
 
 
 })  
  
    
     var launchStudy2=function() {
    	
    	 window.location = 'intent://lanuch#Intent;scheme=cxstudy;package=com.chaoxin g.mobile;S.browser_fallback_url=https%3A%2F%2Fapp.chaoxing. com;end;'; 
    	 } 
 
 
 function launchStudy1(userId) {
		var userName=localStorage.userName;
		
	var host=window.location.host;
		
 	var title=userName+'课表';
 	
 	var activityUrl='http://'+host+'/zycourse/phone/html/copy.html?userId='+userId;
	
 	
 	
		
		//打开的时候显示的标题
		// var title=encodeURIComponent('123');
		 var url=encodeURIComponent(activityUrl);
		
		 //带标题传
		// url="chaoxingshareback://url="+url+"&title="+title+"&sharebacktype=1";
		 url="chaoxingshareback://url="+url+"&sharebacktype=1";
		
		 
		
		
		window.location.href=url;
		
			
			 
	   setTimeout(function() { 
	  	 if (!document.webkitHidden) { window.location = 'https://apps.chaoxing.com/'; } 
	  	 }, 50);
	
	} 
     
     
     
     
     