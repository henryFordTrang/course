$(function(){
	  var fid=localStorage.fid;
	  var uid=localStorage.uid;	  
	  var school=localStorage.school1;
	  var userId=localStorage.userId;
	  var couse=localStorage.breakdownCourse;
	  
	  
	  //底下 创建课程按钮不被顶起
	  var clientHeight = document.documentElement.clientHeight || document.body.clientHeight; $(window).on('resize', function () {
		    var nowClientHeight = document.documentElement.clientHeight || document.body.clientHeight;
		    if (clientHeight > nowClientHeight) {
		    	
		       $('.submit2').css('display','none');
		    }
		    else {
		    	
		    	$('.submit2').css('display','block');
		    } });
	  
	 
	  var courseUrl=cutUrl()+"/api/course/qryKcDetailsByCourseName";
	  var courseMes='{"userId":"'+userId+'","courseName":"'+couse+'","js":"","xnxqId":""}';
		 
		$.ajax({
	        "dataType": 'json',
	        "type": "POST",
	        "async":false,
	        "url": courseUrl,
	        "data": courseMes,
	        "contentType":"application/json;charset=utf-8",
	        "success": function (data, textStatus, jqXHR){
	        	var raw=JSON.stringify(data);
	        	console.log(raw);
	        	raw=$.parseJSON(raw);
	        	if(raw.error.id=='0000'){
	        		var count=0;
	        		
	        		//查找自己的课程
	        		var duplic=[];
	        		$.each(raw.kcDetailsList,function(i,dom){
	        			if(dom.userId==userId){
	        				duplic.push(dom);
	        			}
	        		})
	        		
	        		
	        		
	        		//查找别人的，跟自己不一样的课程
	        		var extraE=[];
	        		var indexSex=[];
	        		$.each(raw.kcDetailsList,function(i,dom){
	        			
	        			$.each(duplic,function(j,dom1){
	        				
	        				if(dom.xqs==dom1.xqs&&dom.jcdm==dom1.jcdm&&dom.zc==dom1.zc&&dom.userId!=userId){
	        					console.log(dom,dom1)
	        					extraE.push(dom);
	        					indexSex.push(i);
	        				}
	        			})
	        		})
	        		
	        		//别人的，跟自己不一样的课程
	        	
	        		var forshow=[];
	        		$.each(raw.kcDetailsList,function(i,dom){
	        			var valaible=true;
	        			
	        			$.each(extraE,function(j,dom1){
	        				
	        				if(parseInt(dom.id)==parseInt(dom1.id)){
	        					valaible=false;
	        				}
	        			})
	        			
	        			if(valaible){
	        				forshow.push(dom);
	        			}
	        		})
	        		
	        		
	        		
	        		$.each(forshow,function(i,dom){
	        			count++;
	        				        				        			
	        			var index='idA'+dom.id;
	        			var index1='idB'+dom.id;
	        			var index2='idC'+dom.id;
	        			var weekList=[];
		        		var clsList=[];

		        		var combineWeek=dom.zc;
		        		combineWeek=combineWeek.split(',');
		        		$.each(combineWeek,function(x,dom1){
		        			weekList.push(dom1);
		        		})
		        		
		        		var combineCls=dom.jcdm;
		        		combineCls=combineCls.split(',');
		        		$.each(combineCls,function(y,dom2){
		        			clsList.push(dom2);
		        		})
		        		
		        		var cnWeek=dataSet(weekList);
		        		var cnCls=dataSet(clsList);
		        		var isExist=false;
		        		
		        		
		        		
		        		if($('.duplicate').length>0){
		        			
			        		$('.duplicate').each(function(){
			        			
			        			if($(this).val()==dom.userId||$(this).siblings('.dupliTea').val()==dom.js){
			        				
			        				isExist=true;
			        				
			        				
			        			}else{
			        				isExist=false;
			        				
			        			}
			        		})
			        		
			        		
			        		
			        		if(!isExist){
			        			
			        			var showTime=cnWeek+'周,周'+dom.xqs+' '+cnCls+'节';
			        			$('.addCourseDiv').append('<a href="javascript:;"><div class="rcmCourse" id="'+index+'"></div><input type="hidden" class="duplicate" value="'+dom.userId+'" name=""><input type="hidden" class="dupliTea" value="'+dom.js+'" name=""></a>');
			        			$('#'+index).append('<p class="rcmCourseName">'+dom.courseName+'</p>');
			        			if(userId==dom.userId){
			        				
			        				$('#'+index).append('<a href="javascript:;" class="setCourseA"><div class="setCourse delC"><span class="courseEm">删除</span></div></a>');
			        			}else{
			        				$('#'+index).append('<a href="javascript:;" class="setCourseA"><div class="setCourse addC"><span class="courseEm">添加到课表</span></div></a>');
			        			}
			        			$('#'+index).append('<div class="rcmItem"><img src="../image/teacher.png" alt=""><span>老师：</span><span>'+dom.js+'</span></div>');
			        			$('#'+index).append('<div class="durationItem time'+dom.userId+'" id="'+index1+'"></div>');
			        			$('#'+index1).append('<div class="duraL"><img src="../image/courseT.png" alt=""><span>时间：</span></div>');
			        			$('#'+index1).append('<div class="duraR"><ul><li class="duraBreak"><span>'+showTime+'</span></li></ul></div>');
			        			$('#'+index1).children('.duraR').append('<input type="hidden" class="listIndx" value="'+i+'" name=""><input type="hidden" class="delIndex" value="'+dom.id+'" name="">');
			        		}else{
			        			console.log(999+'.time'+dom.userId)
			        			var showTime=cnWeek+'周,周'+dom.xqs+' '+cnCls+'节';
			        			$('.time'+dom.userId).append('<div class="duraR" style="margin-left: 1.35rem;"><input type="hidden" class="listIndx" value="'+i+'" name=""><input type="hidden" class="delIndex" value="'+dom.id+'" name=""><ul><li class="duraBreak"><span>'+showTime+'</span></li></ul></div>');
			        			
			        		}
	        		   }else{
	        			  
	        			   var showTime=cnWeek+'周,周'+dom.xqs+' '+cnCls+'节';
		        			$('.addCourseDiv').append('<a href="javascript:;"><div class="rcmCourse" id="'+index+'"></div><input type="hidden" class="duplicate" value="'+dom.userId+'" name=""><input type="hidden" class="dupliTea" value="'+dom.js+'" name=""></a>');
		        			$('#'+index).append('<p class="rcmCourseName">'+dom.courseName+'</p>');
		        			if(userId==dom.userId){
		        				
		        				$('#'+index).append('<a href="javascript:;" class="setCourseA"><div class="setCourse delC"><span class="courseEm">删除</span></div></a>');
		        			}else{
		        				
		        				$('#'+index).append('<a href="javascript:;" class="setCourseA"><div class="setCourse addC"><span class="courseEm">添加到课表</span></div></a>');
		        			}
		        			$('#'+index).append('<div class="rcmItem"><img src="../image/teacher.png" alt=""><span>老师：</span><span>'+dom.js+'</span></div>');
		        			$('#'+index).append('<div class="durationItem time'+dom.userId+'" id="'+index1+'"></div>');
		        			$('#'+index1).append('<div class="duraL"><img src="../image/courseT.png" alt=""><span>时间：</span></div>');
		        			$('#'+index1).append('<div class="duraR"><ul><li class="duraBreak"><span>'+showTime+'</span></li></ul></div>');
		        			$('#'+index1).children('.duraR').append('<input type="hidden" class="listIndx" value="'+dom.id+'" name=""><input type="hidden" class="delIndex" value="'+dom.id+'" name="">');  
	        		   }
		        		

	        			
	        			$('#'+index).click(function(e){
	        				
	        				
	        				localStorage.recommandCo=JSON.stringify(raw.kcDetailsList);
	        				
	        				var listIndex=[];
	        				$('#'+index).find('.listIndx').each(function(){
	        					
	        					listIndex.push($(this).val());
	        				})
	        				
	        				localStorage.cosListIndex=listIndex;
	        				
	        				var delIndexList=[];
	        				$('#'+index).find('.delIndex').each(function(){
	        					delIndexList.push($(this).val());
	        				})
	        				localStorage.delIndexList=delIndexList;
	        				
	        				
	        				if(userId==dom.userId){
	        					window.location='recomCoDel.html';	
	        				}else{
	        					window.location='recomCoAdd.html';	
	        				}
	        				        				
	        				e.stopPropagation();
	        				
	        			})
	        			
	        			
	        			
	        			//点击添加或删除课程
	        			if(userId==dom.userId){
	        				$('#'+index).find('.delC').click(function(e){
	        					var deleteS=[];	        		   			
	        					var listIndex=[];
		        				$('#'+index).find('.delIndex').each(function(){
		        					
		        					deleteS.push($(this).val());
		        					
		        				})
		        				
	        						        		   			
	        					var delurl=cutUrl()+"/api/course/deleteCourses";
	        					deleteS='['+deleteS+']';
	        					var delmes='{"idList":'+deleteS+'}';
	        					
	        					
	        					
	        					
	        					delRecommand(delurl,delmes);
	        					e.stopPropagation();
	        				})
	        			}else{
	        				$('#'+index).find('.addC').click(function(e){
	        					
	        					var listIndex=[];
	        					var finalIndex=0;
	        					var isFinal=false;
		        				/*$('#'+index).find('.listIndx').each(function(){
		        					finalIndex++;
		        					var url=cutUrl()+"/api/course/insertKcDetails";
		        					//var unitmes='{"userId":"'+userId+'","js":"'+raw.kcDetailsList[$(this).val()].js+'","room":"'+raw.kcDetailsList[$(this).val()].room+'","jcdm":"'+raw.kcDetailsList[$(this).val()].jcdm+'","courseName":"'+raw.kcDetailsList[$(this).val()].courseName+'","courseId":"","status":"","zc":"'+raw.kcDetailsList[$(this).val()].zc+'","xqs":"'+raw.kcDetailsList[$(this).val()].xqs+'"}';
		        					var unitmes='{"userId":"'+userId+'","js":"'+raw.kcDetailsList[$(this).val()].js+'","room":"'+raw.kcDetailsList[$(this).val()].room+'","jcdm":"'+raw.kcDetailsList[$(this).val()].jcdm+'","courseName":"'+raw.kcDetailsList[$(this).val()].courseName+'","courseId":"","status":"","zc":"'+raw.kcDetailsList[$(this).val()].zc+'","xqs":"'+raw.kcDetailsList[$(this).val()].xqs+'"}';
		        					unitmes='['+unitmes+']';
		        					var mes='{"list":'+unitmes+'}';
		        					
		        					if($('#'+index).find('.listIndx').length==finalIndex){
		        						isFinal=true;
		        					}
		        					addRecommand(url,mes,isFinal);
		        					e.stopPropagation();
		        					
		        				})*/
		        				
	        					var idSet=[];
	        					var addCoSet=[];
	        					
	        					
		        				$('#'+index).find('.delIndex').each(function(){
		        					idSet.push($(this).val());	
		        				})
		        				
		        				
		        				$.each(raw.kcDetailsList,function(i,dom){
		        					var select=false;
		        					$.each(idSet,function(j,dom1){
		        						if(dom1==dom.id){
		        							select=true;
		        						}
		        					})
		        					
		        					if(select){
		        						addCoSet.push(dom);
		        					}
		        				})
		        				
		        				
		        				$.each(addCoSet,function(i,dom){
		        					finalIndex++;
		        					var url=cutUrl()+"/api/course/insertKcDetails";
		        					//var unitmes='{"userId":"'+userId+'","js":"'+raw.kcDetailsList[$(this).val()].js+'","room":"'+raw.kcDetailsList[$(this).val()].room+'","jcdm":"'+raw.kcDetailsList[$(this).val()].jcdm+'","courseName":"'+raw.kcDetailsList[$(this).val()].courseName+'","courseId":"","status":"","zc":"'+raw.kcDetailsList[$(this).val()].zc+'","xqs":"'+raw.kcDetailsList[$(this).val()].xqs+'"}';
		        					var unitmes='{"userId":"'+userId+'","js":"'+dom.js+'","room":"'+dom.room+'","jcdm":"'+dom.jcdm+'","courseName":"'+dom.courseName+'","courseId":"","status":"","zc":"'+dom.zc+'","xqs":"'+dom.xqs+'"}';
		        					unitmes='['+unitmes+']';
		        					var mes='{"list":'+unitmes+'}';
		        					
		        					if($('#'+index).find('.delIndex').length==finalIndex){
		        						isFinal=true;
		        					}
		        					addRecommand(url,mes,isFinal);
		        					e.stopPropagation();
		        					
		        				})
		        				
		        				
	        				})
	        				
	        				
	        			}
	        			
	        			
	        		})
	        		
	        		
	        	}else{
	        		//alert(raw.error.message);
	        		$.MsgBox.Alert('温馨提示',raw.error.message);
	        	}
	        	
	        }
		})
	  
	
	
	$('.menu_l').click(function(){
		window.location="addCourse.html";
		localStorage.removeItem('breakdownCourse');
	})
	
})


var addRecommand=function(url,mes,index){
	console.log(mes);
	$.ajax({
        "dataType": 'json',
        "type": "POST",
        "url": url,
        "data": mes,
        "contentType":"application/json;charset=utf-8",
        "success": function (data, textStatus, jqXHR){
        	
        	var raw=JSON.stringify(data);  
        	console.log(raw);
        	raw=$.parseJSON(raw);
        	if(raw.error.id=='0000'){
        		if(index){
        			window.location='term.html';
        		}
        		
        	}else{
        		if(index){
        			//alert(raw.error.message);
        			$.MsgBox.Alert('温馨提示',raw.error.message);
        		}
        		
        	}
        	
        }
	})
	
}


var delRecommand=function(url,mes){
	
	$.MsgBox.Confirm("温馨提示", "确认在课表中删除此课程吗?", function () {
   			

			$.ajax({
 			"dataType": 'json',
 			"type": "POST",
 			"url": url,
 			"data": mes,
 			"contentType":"application/json;charset=utf-8",
 			"success": function (data, textStatus, jqXHR){
 				var raw=JSON.stringify(data); 				
 				raw=$.parseJSON(raw);
 				if(raw.error.id=="0000"){
 					
 					window.location="term.html";
 				}else{
 					//alert(raw.error.message);
 					$.MsgBox.Alert('温馨提示',raw.error.message);
 				}
 			}
			})
   		  
   	  }, function () {
   		  
   		  return;
   		  
   	  })
	
}

//连续的数字用'-'相连
 var dataSet=function(chooseArr){
	             var arrInfo="";
	   			 for(var x=0;x<chooseArr.length;x++){
	   				 arrInfo+=chooseArr[x]+',';
	   			 }
	   			 arrInfo=arrInfo.substring(0,arrInfo.length-1);
	   			
	   			 var infoArr=arrInfo.split(",");
	   			    var rres="";
	   			    var res=fn(infoArr);
	   			    for (var i = 0; i < res.length; i++) {
	   			        var item=res[i];
	   			        if(item.length==1){
	   			            rres+=item[0]+",";
	   			        }else{
	   			            rres+=item[0]+"-"+item[item.length-1]+",";
	   			        }
	   			        
	   			    }
	   			    rres=rres.substring(0,rres.length-1);
	   			    return rres;
            }


var fn=function(arr){
	   var result = [],
	       i = 0;
	   result[i] = [arr[0]];
	   arr.reduce(function(prev, cur){
	     cur-prev === 1 ? result[i].push(cur) : result[++i] = [cur];
	     return cur;
	   });
	  // console.log(result);
	   return result;
	 }