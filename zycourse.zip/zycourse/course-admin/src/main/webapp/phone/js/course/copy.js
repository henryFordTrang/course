var schoolName='';
var userName='';


function GetRequest() {
    var url = location.search; //获取url中"?"符后的字串
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for(var i = 0; i < strs.length; i ++) {
            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}


$(document).ready(function () {
	
	
	
	jsBridge.postNotification("CLIENT_LOGIN", {"accountKey":""});	
	
	jsBridge.bind("CLIENT_LOGIN_STATUS");
	

	 concealing(); 
	
	 var reg=/[\u4e00-\u9fa5]/g;	 	 
	 var Request = new Object();
	 Request = GetRequest();
	
	 //var fid=Request.fid;
	 //var uid=Request.uid;
	 var para=Request.userId;
	 
	 //var userName=Request.userName;
	 //var school=Request.school;
	 var userId=localStorage.userId;
	 var uid=localStorage.uid;
	 
	 var fid=localStorage.fid;
	 var userName=localStorage.userName;
	 
	 var school=localStorage.school1;
	 
	 
	 
	 //var copymes='{"userId":"'+userId+'","uid":"'+uid+'","fid":"'+fid+'","schoolName":"'+school+'","username":"'+userName+'","copyObjectUserId":"'+para+'"}';
	  var copymes='{"uid":"'+uid+'","fid":"'+fid+'","schoolName":"'+school+'","username":"'+userName+'","copyObjectUserId":"'+para+'"}';
	 //var copymes='{"uid":"'+uid+'","fid":"'+fid+'","copyObjectUserId":"'+para+'"}';
	
	 
		$.ajax({
	         "dataType": 'json',
	         "type": "POST",
	         "async":false,
	         "url": cutUrl()+"/api/course/copyCourseInfo",
	         "data": copymes,
	         "contentType":"application/json;charset=utf-8",
	         "success": function (data, textStatus, jqXHR){
	        	
	        	 var raw=JSON.stringify(data);
	        	
	        	  			        	 
	        	 raw=$.parseJSON(raw);
	        	 
	        	 
	        	
	        		
	         		window.location="term.html";
	        		
	        		 
	        	
	        	 
	        	 
	         }
		 })
     
    
	 

    
  
    
   
	
      	
    });



	
	
	 
 

    	
    	
        
        
       