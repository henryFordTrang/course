var clickCtrl=false;
$(document).ready(function () {
	
	if(isIphoneX()){
		 
		 $('#container').css('height','13rem');
	 }
	
	 var fid=localStorage.fid;
	 var uid=localStorage.uid;
	 var userName=localStorage.userName;
	 var school=localStorage.school1;
	 var reg=/[\u4e00-\u9fa5]/g;
	 var userId=localStorage.userId;
	 
        		 
        		 $.ajax({
              		"dataType": 'json',
              		"type": "GET",
              		"async":false,
             		"url": cutUrl()+"/api/course/getUserCourseInfo",
              		"data": {"userId":userId},
              		"contentType":"application/json;charset=utf-8",
              		"success": function (data, textStatus, jqXHR){
              			var raw1=JSON.stringify(data);             			
              			raw1=$.parseJSON(raw1);
              			if(raw1.error.id=='0000'){
              				weekGenerate(raw1.currentZs);
              				loading(userId,raw1.currentZs);
              				
              			}else{
              				//alert(raw1.error.message);
              				$.MsgBox.Alert('温馨提示',raw1.error.message);
              			}
              		}
        		 })
        		
        	


        $(document).click(function (e) {
        	
        	/*if($('.menu_r').children('img').attr('class')=='swichturn'){
        		$('.menu_r').children('img').removeClass('swichturn');
        	}*/
        	
            $(".courseTimeList").slideUp();
            $(".setList").slideUp();
            e.stopPropagation();
        });
        
        $('.menu_l').click(function(){
        	exit();
        })
        $(".menu_r").click(function(e){
        	//$(this).children('img').toggleClass('swichturn');
            $(this).next().slideToggle(500);
            e.stopPropagation();
        })
        
        $('#scan').click(function(){
        	barcode();
        })
        
        $('#share').click(function(){
        	window.location="shareTime.html";
        })
        $('#create').click(function(){
        	window.location="addCourse.html";
        })
        
        $('#setup').click(function(){
        	window.location="timeTableSetup.html";
        })
        
        $('#newterm').click(function(){
        	window.location="createTerm.html";
        })
        
        $('#newcourse').click(function(){
        	window.location="addCourse.html";
        })
       
        var ifvisible=false;
     
        $('#choose').click(function(){
 			 $(this).children('img').toggleClass('swithturn')
        	$('#newcourse').children('img').toggleClass('showup');
 			
 			//$('#coverw').toggleClass('showup')
 			$('#mfyA').toggleClass('revealing');
  			$('#wrapper1').toggleClass('revealing');
  			$('#choosediv').toggleClass('revealing');
        	 
        	
        })
        
        $('.seatCharts-seat').each(function(){
        	$(this).click(function(){
        		$('.seatCharts-seat').addClass('available').removeClass('selected');
        		$(this).addClass('selected');
        		
        	})
        })
        
         var weekbegin=['第1周','第2周','第3周','第4周','第5周','第6周','第7周','第8周','第9周','第10周','第11周','第12周','第13周','第14周','第15周','第16周','第17周','第18周','第19周','第20周','第21周','第22周','第23周','第24周','第25周'];
      	 var mobileSelect3 = new MobileSelect({
      			
      		    trigger: '#mfyA',
      		    type:'beginwith',
      		    title: '设置当前周',
      		    wheels: [
      		                {data: weekbegin},
      	
      		            ],
      		    position:[2, 2, 2, 2, 2], 
      		    transitionEnd:function(indexArr, data){
      		    	$('.title').text('设置当前周为：'+data)
      		    },
      		    callback:function(indexArr, data){
      		    	
      		     
      		        var chooseW=data[0].replace(reg,'');      		        
      		       // currentWeek(userId,chooseW);
      		        currentWeek(userId,chooseW);
      		        $('.clearfix').empty();
      		        weekGenerate(chooseW);
      		       
      		        weekListener(userId);
      		       
      		      
      		    }
      		});
        
     
        
      	weekListener(userId);
      
        
    });
 
 
 
 	//封装的方法
 
 		//星期添加监听
 		
 		
 			var weekListener=function(userId){
 			
 			
 			$('.narrowTab').each(function(){
 	        	$(this).click(function(){
 	        		$('.narrowTab').children('tbody').children('tr').children('td').css('background','#ECEEF5');
 	        		var fetchweek=$(this).siblings('.weekP').text();
 	        		
 	        		var reg=/[\u4e00-\u9fa5]/g;
 	        		fetchweek=fetchweek.replace(reg,'');
 	        		console.log('remove')
 	        		$('#ofix1_tb_header').remove();
 	        		$('#ofix1_tb_left').remove();
 	        		$('#ofix1_tb_top_left').remove();
 	        		console.log('finish remove')
 	        		if(clickCtrl){
 	        			return;
 	        		}
 	        		clickCtrl=true;
 	        		
 	        		$('.table').children('thead').children('tr').empty();
 	        		$('.table').children('thead').children('tr').append("<td class='firstTd' style='width: 1rem;'><p class='tdHeadP1'>日期</p><p class='tdHeadP2'>时间</p></td>"); 	        		
 	        		$('.table').children('tbody').empty();
 	        		var realM=calculationDate(curWeek,fetchweek);
 	        		
 	        		loading(userId,fetchweek,realM);
 	        		
 	        		$('.currweekbg').removeClass('currweekbg');
 	        		$(this).parents('li').removeClass('weekbg').addClass('currweekbg');
 	        		
 	        		
 	        	})
 	        	
 	       
 	        })
 		}
 		
 		
 
 	  /* //根据入学年月和当前时间判断学期
 		var termCal=function(adyear,rgyear,series){
 			adyear=parseInt(adyear);
 			rgyear=parseInt(rgyear);
 			var gap=adyear-rgyear+1;
 			if(series==2){
 				gap=gap+1;
 			}
 			
 			gap=SectionToChinese(gap);
 			series=SectionToChinese(series);
 			
 			return '大'+gap+' '+'第'+series+'学期';
 		}*/
 			
 			
 			var termCal=function(adyear,rgyear,series){
 	 			console.log('学年：'+adyear+' 入学时间：'+rgyear+' 学期'+series)
 	 			adyear=parseInt(adyear);
 	 			rgyear=parseInt(rgyear);
 	 			console.log('学年：'+adyear+' 入学时间：'+rgyear+' 学期'+series)
 	 			
 	 			var gap=adyear-rgyear;
 	 			if(series==1){
 	 				gap=gap+1;
 	 			}
 	 			
 	 			console.log(gap);
 	 			var feedback='';
 	 			if(gap<1||gap>5){
 	 				feedback='第'+series+'学期';
 	 			}else{
 	 				
 	 				gap=SectionToChinese(gap);
 	 	 			series=SectionToChinese(series);
 	 	 			feedback='大'+gap+' '+'第'+series+'学期';
 	 			}
 	 			
 	 			
 	 			
 	 			
 	 			
 	 			
 	 			
 	 			return feedback;
 	 		}
 			
 			
 			/*//根据入学年月和当前时间判断学期
 			var termCal=function(adyear,rgyear,series){
 				
 				adyear=parseInt(adyear);
 				rgyear=parseInt(rgyear);
 				var gap=adyear-rgyear;
 				if(series==1){
 					gap=gap+1;
 				}
 				
 				
 				if(gap<1||gap>5){
 					gap=10;
 				}
 				
 				gap=SectionToChinese(gap);
 				series=SectionToChinese(series);
 				
 				return '大'+gap+' '+'第'+series+'学期';
 			}*/
 	
 		
 		var isIos=function(){
			 var ua = navigator.userAgent.toLowerCase();
			 if(ua.match(/(iphone|ipod|ipad);?/i)){
				 return true;
			 }else{}
			 return false;
		 }
 	   
 	   
 		 //扫码 复制课表信息
 		
 		try{
    		jsBridge.bind('CLIENT_BARCODE_SCANNER', function(object){
    			var version=isIos();
    			
    			
  				var para=object.message;
    			para=para.split('=');
    			para=para[1];
    			
    			if(!version){
    				
    				var cfm=confirm('是否复制课件');
    				
    				if(!cfm){
    					
    					return;
    				}
    			}
    			
    			
    				var userId=localStorage.userId;
    				var uid=localStorage.uid;
    				var fid=localStorage.fid;
    				var schoolName=localStorage.school1;
    				var username=localStorage.userName;
    				
    				var copymes='{"userId":"'+userId+'","uid":"'+uid+'","fid":"'+fid+'","schoolName":"'+schoolName+'","username":"'+username+'","copyObjectUserId":"'+para+'"}';
    				
    				$.ajax({
    			         "dataType": 'json',
    			         "type": "POST",
    			         "async":false,
    			         "url": cutUrl()+"/api/course/copyCourseInfo",
    			         "data": copymes,
    			         "contentType":"application/json;charset=utf-8",
    			         "success": function (data, textStatus, jqXHR){
    			        	
    			        	 var raw=JSON.stringify(data);
    			        	
    			        	 var currentWeek=localStorage.currentWeek;    			        	 
    			        	 raw=$.parseJSON(raw);
    			        	 if(raw.error.id=='0000'){
    			        		 window.location='term.html';
    			        		
    			        		 
    			        	 }
    			        	 
    			        	 
    			         }
    				 })
    				
    			
    		});  
    	}catch(e){}

    	function barcode(){
    		
    		jsBridge.postNotification('CLIENT_BARCODE_SCANNER', {}) ;
    	}
    	
 		
 	   
 	 
    	
    	
    	//设置日期格式
    	 Date.prototype.Format = function (fmt) { 
     	    var o = {
     	        "M+": this.getMonth() + 1, //月份 
     	        "d+": this.getDate(), //日 
     	        "h+": this.getHours(), //小时 
     	        "m+": this.getMinutes(), //分 
     	        "s+": this.getSeconds(), //秒 
     	        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
     	        "S": this.getMilliseconds() //毫秒 
     	    };
     	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
     	    for (var k in o)
     	    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
     	    return fmt;
     	}
 		
    	
    	
    	//中文数字转阿拉伯数字
    	 var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
         var chnUnitSection = ["","万","亿","万亿","亿亿"];
         var chnUnitChar = ["","十","百","千"];

         function SectionToChinese(section){
             var strIns = '', chnStr = '';
             var unitPos = 0;
             var zero = true;
             while(section > 0){
                 var v = section % 10;
                 if(v === 0){
                     if(!zero){
                         zero = true;
                         chnStr = chnNumChar[v] + chnStr;
                     }
                 }else{
                     zero = false;
                     strIns = chnNumChar[v];
                     strIns += chnUnitChar[unitPos];
                     chnStr = strIns + chnStr;
                 }
                 unitPos++;
                 section = Math.floor(section / 10);
             }
             return chnStr;
         }
         
         
        	 Array.prototype.indexOf = function (val) {
        		    for (var i = 0; i < this.length; i++) {
        		        if (this[i] == val) return i;
        		    }
        		    return -1;
        		};

        		Array.prototype.remove = function (val) {
        		    var index = this.indexOf(val);
        		    if (index > -1) {
        		        this.splice(index, 1);
        		    }
        		};
        
        		
        		
 				//中文周 转阿拉伯文周
        		var interpret=function(week){
        			if(week=='周一'){
        				return 1;
        			}else if(week=='周二'){
        				return 2;
        			}else if(week=='周三'){
        				return 3;
        			}else if(week=='周四'){
        				return 4;
        			}else if(week=='周五'){
        				return 5;
        			}else if(week=='周六'){
        				return 6;
        			}else if(week=='周日'||week=='周天'){
        				return 7;
        			}
        		}
        		
 				//中文节次转阿拉伯数字节次
        		var classConvert=function(week){
        			if(week=='第一节'){
        				return 1;
        			}else if(week=='第二节'){
        				return 2;
        			}else if(week=='第三节'){
        				return 3;
        			}else if(week=='第四节'){
        				return 4;
        			}else if(week=='第五节'){
        				return 5;
        			}else if(week=='第六节'){
        				return 6;
        			}else if(week=='第七节'){
        				return 7;
        			}else if(week=='第八节'){
        				return 8;
        			}else if(week=='第九节'){
        				return 9;
        			}else if(week=='第十节'){
        				return 10;
        			}else if(week=='第十一节'){
        				return 11;
        			}else if(week=='第十二节'){
        				return 12;
        			}else if(week=='第十三节'){
        				return 13;
        			}else if(week=='第十四节'){
        				return 14;
        			}else if(week=='第十五节'){
        				return 15;
        			}
        		}
        		
        		
        		
        		//页面加载
        		var loading=function(userId,zc,monday){
        			
        			$('#ofix1_tb_header').remove();
 	        		$('#ofix1_tb_left').remove();
 	        		$('#ofix1_tb_top_left').remove();
        			
        			
        			
        			$('.mfyA').addClass('concealing');
         			$('#wrapper1').addClass('concealing');
         			$('#choosediv').addClass('concealing');
         			
        			   var reg=/[\u4e00-\u9fa5]/g;
        			   var paraurl=cutUrl()+"/api/course/qryKbSettingsInfo";
        			   var parames='{"userId":"'+userId+'"}';

        		  	   var spanurl=cutUrl()+"/api/kbsz/qryJcTime";
        		   	   var spanmes='{"userId":"'+userId+'"}';
        		   	   
        		   	   var url=cutUrl()+"/api/course/qryCourseList";
        			   var mes='{"userId":"'+userId+'","zc":"'+zc+'"}';
        			   
        				 $.ajax({
        			         "dataType": 'json',
        			         "type": "POST",
        			         "url": paraurl,
        			         "data": parames,
        			         "contentType":"application/json;charset=utf-8",
        			         "success": function (data, textStatus, jqXHR){
        			        	 var raw=JSON.stringify(data);
        			        	 
        			        	
        			        	 raw=$.parseJSON(raw);
        			        	 var adyear=raw.kbSettingsInfo.xn;
        			        	 var rgyear=raw.kbSettingsInfo.rxny;
        			        	 var termseries=raw.kbSettingsInfo.xq;
        			        	 var currentW=raw.kbSettingsInfo.dqzs;
        			        	 curWeek=raw.kbSettingsInfo.dqzs;
        			        	
        			        	 adyear=adyear.split('-');
        			        	 adyear=adyear[0];
        			        	 rgyear=rgyear.substring(0,4);
        			        	 var gradeInfo=termCal(raw.kbSettingsInfo.kxsj,rgyear,termseries);
        			        	 $('.menuP').text(gradeInfo);
        			        	 $('.courseUp').children('em').text('第'+raw.kbSettingsInfo.dqzs+'周');
        			        	 var weekStart=raw.kbSettingsInfo.weekStart;
        			        	 var weekshift=raw.kbSettingsInfo.weekStart;
        			        	 if(weekStart>1){
        			        		 weekStart=weekStart-1;
        			        		 for(var w=0;w<7;w++){	        			 
        				        		 weekStart++;
        				        		 if(weekStart>7){
        				        			 weekStart=weekStart-7;
        				        		 }
        				        		 var weekId='tdP'+weekStart;
        				        		 var cnws=SectionToChinese(weekStart);
        				        		 if(cnws=='七'){
        			        				 cnws='日';
        			        			 }
        				        		 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
        				        	 }
        			        	 }else{
        			        		 for(var w=0;w<7;w++){
        			        			 var weekId='tdP'+weekStart;
        			        			 var cnws=SectionToChinese(weekStart);
        			        			 if(cnws=='七'){
        			        				 cnws='日';
        			        			 }
        			        			 $('.table').children('thead').children('tr').append("<td class='firstTd'><em>周"+cnws+"</em><p class='tdP' id="+weekId+"></p></td>");
        			        			 weekStart++;
        			        		 }
        			        		 
        			        	 }
        			        	 $('body').show();
        			        	
        			        	 var max=raw.kbSettingsInfo.jcMax;
        			        	 var ifNapping=false;
        			     	
        			        		 $.ajax({
        			        	         "dataType": 'json',
        			        	         "type": "POST",
        			        	         "url": spanurl,
        			        	         "data": spanmes,
        			        	         "contentType":"application/json;charset=utf-8",
        			        	         "success": function (data, textStatus, jqXHR){
        			        	        	 var raw1=JSON.stringify(data);
        			        	        	 console.log(raw1);
        			        	        	 raw1=$.parseJSON(raw1);
        			        	        	 var resetList=raw1.list;
        			        	        	 var resetArr=[];
        			        	        	
        			        	        	 $.each(resetList,function(i,dom){
        			        	        		 resetArr.push(dom);
        			        	        		 if(i==3){
        			        	        			 resetArr.push(resetList[12]);
        			        	        		 }
        			        	        		 
        			        	        	 })
        			        	        	 
        			        	        	 
        			        	        	 resetArr=resetArr.slice(0,resetArr.length-1);	
        			        	        	 
        			        	        	 var checkNapIn=raw1.list[12].jckssj;
        				        	         checkNapIn=checkNapIn.replace(reg,'');
        			        	        	 //console.log(raw1.list[15].jckssj+' '+raw1.list[15].jckssj.length);
        			        	        	 if(raw1.list[12].jckssj!=null&&raw1.list[12].jckssj!=''&&raw1.list[12].jckssj.length>0&&checkNapIn.length>0){
        			        	        		 //in case 有午休
        			        	        		ifNapping=true;
        			        	        		 $.each(resetArr,function(i,dom){	
        				        	        		//console.log(dom);
        			        	        			 var series=dom.jcmc;
        			        	        			 var reg=/[\u4e00-\u9fa5]/g;
        			        	        			 series=classConvert(series);
        			        	        			 var trmark='mark'+i;
        			        	        			 
        			        	        			 if(i<4){
        			        	        				 if(i>=max){
            				        	        			 return;
            				        	        		 } 	
        			        	        			 }else{
        			        	        				 if(i>max){
            				        	        			 return;
            				        	        		 } 	
        			        	        			 }
        			        	        			
        			        	        			 
        				        	        		  console.log(dom.jcmc)
        				        	        		
        				        	        		 if(dom.jcmc=='午休'){
        				        	        			 //$('.table').children('tbody').append("<tr class='restTr'><td class='firstTd'>"+dom.jcmc+"<p class='time'>"+dom.jckssj+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
        				        	        			 $('.table').children('tbody').append("<tr class='restTr'><td class='firstTd napping'>"+dom.jcmc+"<p class='time'>"+dom.jckssj+"</p></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td><td class='napping'></td></tr>");
        				        	        		 }else{
        				        	        			 $('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+dom.jckssj+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
        				        	        		 }
        				        	        		 
        				        	        		       	        		
        			        	        	 }) 

        			        	        		 
        			        	        		 
        			        	        	 }else{
        			        	        		 //in case 没有午休
        			        	        		ifNapping=false;
        			        	        		 resetArr.remove(resetArr[4])	        	        		
        			        	        		 $.each(resetArr,function(i,dom){	
        					        	        		//console.log(dom);
        				        	        			 var series=dom.jcmc;
        				        	        			 var reg=/[\u4e00-\u9fa5]/g;
        				        	        			 series=classConvert(series)
        				        	        			 //series=series.replace(reg,'');
        				        	        			 var trmark='mark'+i;		        	        		
        					        	        		  if(i>=max){
        					        	        			 return;
        					        	        		 } 	
        					        	        		console.log(dom.jcmc)  
        					        	        		 
        					        	        		$('.table').children('tbody').append("<tr class="+trmark+"><td class='firstTd'>"+series+"<p class='time'>"+dom.jckssj+"</p></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"); 
        					        	        		 
        					        	        		 
        					        	        		       	        		
        				        	        	 }) 

        			        	        	 }
        			        	        	 
        			        	        	 var ofix1 = new oFixedTable('ofix1', document.getElementById('mytable'), {rows:1, cols:1});

        			        	        	 
        			        	        	 //....
        			        	        	 
        			        	        	 $.ajax({
        		         					  "dataType": 'json',
        		         					  "type": "POST",
        		         					  "url": url,
        		         					  "data": mes,
        		         					  "contentType":"application/json;charset=utf-8",
        		         					  "success": function (data, textStatus, jqXHR){
        		         						 //$('.table').children('tbody').children('tr').eq(0).children('td').eq(3).css('background-color','yellow');
        		         						  var raw2=JSON.stringify(data);
        		         						  clickCtrl=false;
        		         						  raw2=$.parseJSON(raw2);
        		         						
        		         						  
        		         						  if(monday==undefined){
        		         							  monday=getMonday();
        		         						  }
        		         						  
        		         						  milm=Date.parse(monday);
        		         						  var tuesday=milm+86400000*1;
        		         						  var wenesday=milm+86400000*2;
        		         						  var thirsday=milm+86400000*3;
        		         						  var friday=milm+86400000*4;
        		         						  var saturday=milm+86400000*5;
        		         						  var sunday=milm+86400000*6;
        		         						  monday=new Date(milm).Format("MM-dd");
        		         						  tuesday=new Date(tuesday).Format("MM-dd");
        		         						  wenesday=new Date(wenesday).Format("MM-dd");
        		         						  thirsday=new Date(thirsday).Format("MM-dd");
        		         						  friday=new Date(friday).Format("MM-dd");
        		         						  saturday=new Date(saturday).Format("MM-dd");
        		         						  sunday=new Date(sunday).Format("MM-dd");
        		         						  
        		         						 
        		         						  
        		         						  $('#tdP1').text(monday);
        		         						  $('#tdP2').text(tuesday);
        		         						  $('#tdP3').text(wenesday);
        		         						  $('#tdP4').text(thirsday);
        		         						  $('#tdP5').text(friday);
        		         						  $('#tdP6').text(saturday);
        		         						  $('#tdP7').text(sunday);
        		         						  
        		         						  if(curWeek==zc){
        		         							 markCur();
        		         						  }
        		         						 
        		         						 

        		        	 				   	  $.each(raw2.list,function(i,dom){
        		        	 				   		
        		        	 				   		 var row=dom.xqs;
        		        	 				   		 var col=dom.jcdm;
        		        	 				   		 
        		        	 				   		 var colArr= new Array(); //定义一数组 
        		        	 				   		 colArr=col.split(',');

        		        	 				   		 row=parseInt(row);
        		        	 				   		 weekshift=parseInt(weekshift);
        		        	 				   		 
        		        	 				   		 row=7-(weekshift-row)+1;
        		        	 				   		
        		        	 				   		 if(row>7){
        		        	 				   			 row=row-7;
        		        	 				   		 } 
        		        	 				   		 
        		        	 				   		 var topId='trang'+zc;
        		        	 				   		 for(var m=0;m<colArr.length;m++){
        		        	 				   			 var colIndex=colArr[m]-1;
        		        	 				   			
        		        	 				   			 if(ifNapping){
        		        	 				   			 if(colIndex>3){            	 				   			 
        		             	 				   			colIndex=colArr[m];             	 				   		                 	 				   			
        		             	 				   			} 
        		        	 				   			 }
        		        	 				   			
        		        	 				   			
        		        	 				   			$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).addClass('ok');
        		        	 				   		 	$('.table').children('tbody').children('tr').eq(colIndex).children('td').eq(row).append("<span class='cn'>"+dom.courseName+"</span><span class='room'>"+dom.room+"</span><span class='teacher'>"+dom.js+"</span>");
        		        	 				   		    if(curWeek==zc){
        		        	 				   		    $('#'+topId).children('tbody').children('tr').eq(colIndex).children('td').eq(row-1).css('background','red');
        		        	 				   		    }else{
        		        	 				   		    $('#'+topId).children('tbody').children('tr').eq(colIndex).children('td').eq(row-1).css('background','violet');
        		        	 				   		    }
        		        	 				   		 	
        		        	 				   		 }
        		        	 				   		
        		        	 				   	  })
        		        	 				   	  
        		        	 				   	
        		        	 				   	  
        		        	 				   	   $('.ok').each(function(){
        		        	 				   		
        		        	 				   			if($(this).children('.cn').text()=='语文'){
        		        	 				   				$(this).addClass('color'+1);
        		        	 				   			}else if($(this).children('.cn').text()=='英语'){
        		        	 				   			$(this).addClass('color'+2);
        		        	 				   			}else if($(this).children('.cn').text()=='生物'){
        		        	 				   				$(this).addClass('color'+3);
        		        	 				   			}else if($(this).children('.cn').text()=='体育'){
        		        	 				   				$(this).addClass('color'+4);
        		        	 				   			}else if($(this).children('.cn').text()=='物理'){
        		        	 				   				$(this).addClass('color'+5);
        		        	 				   			}
        		        	 				   			else if($(this).children('.cn').text()=='生物'){
        		    	 				   					$(this).addClass('color'+6);
        		    	 				   				}
        		        	 				   			else if($(this).children('.cn').text()=='化学'){
        			 				   						$(this).addClass('color'+7);
        			 				   					}
        		        	 				   			else if($(this).children('.cn').text()=='地理'){
        			 				   						$(this).addClass('color'+8);
        			 				   					}else if($(this).children('.cn').text()=='数学'){
        			 				   						$(this).addClass('color'+9);
        			 				   					}else if($(this).children('.cn').text()=='音乐'){
        			 				   						$(this).addClass('color'+10);
        			 				   					}else if($(this).children('.cn').text()=='政治'){
        			 				   						$(this).addClass('color'+11);
        			 				   					}else if($(this).children('.cn').text()=='历史'){
        			 				   						$(this).addClass('color'+12);
        			 				   					}else{
        			 				   						$(this).addClass('color'+19);
        			 				   					}
        		        	 				   			
        			 				   					
        		        	 				   			
        		        	 				   		 })
        		        	 				   		 
        		        	 				   		
        		        	 				   		 
        		        	 				   	
        		        	 				   		 $('.table').children('tbody').children('tr').children('td').each(function(){
        		        	 				   		 $(this).click(function(){
        		        	 				   			$('td').removeClass("addTd");
        		        	 				   			$('td').children('.addImgA').remove();
        		        	 				   			
        		        	 				   			var row=$(this).parent().prevAll().length+1; 
        		   	 				   			 		var col=$(this).prevAll().length;
                		   	 				   			if(ifNapping){
             			   	 				   			 	if(row==5||col==0){
             			   	 				   			 		if(row==5){
             			   	 				   			 			return;
             			   	 				   			 		}else if(col==0){
             			   	 				   			 			window.location="clsDuraLiveSet.html";
             			   	 				   			 			return;
             			   	 				   			 		}
             		   	 				   				 		
             		   	 				   			 		}
             	   	 				   			 		}else{
             	   	 				   			 			if(col==0){
             	   	 				   			 				window.location="clsDuraLiveSet.html";
             	   	 				   			 				return;
             	   	 				   			 			}
             	   	 				   			 		}
        		   	 				   			 		if(ifNapping&&row>4){
        		   	 				   						row=row-1;
        		   	 				   			 		}
        		   	 				   					var rawstr=$('.table').children('thead').children('tr').children('td').eq(col).text();
        			 				   			 		rawstr=rawstr.substring(0,2);
        			 				   			 		rawstr=interpret(rawstr);
        		        	 				   			
        		        	 				   			var lesson=$(this).children('.cn').text();
        		        	 				   			var teacher=$(this).children('.teacher').text(); 
        		        	 				   			var paraArr=[];
        		        	 				   			paraArr.push(lesson);
        		        	 				   			paraArr.push(row);
        		        	 				   			paraArr.push(rawstr);
        		        	 				   			localStorage.paraArr=paraArr;
        		        	 				   			if(lesson.length>0){
        		        	 				   				
        		        	 				   				
        		        	 				   			
        		        	 				   				localStorage.lesson=lesson;
        		        	 				   				
        		        	 				   				
        		        	 				   				window.location='courseDetail.html';
        		        	 				   				
        		        	 				   				
        		        	 				   			}else{
        		        	 				   			 
        		        	 				   			 
        		        	 				   			
        		        	 				   			$(this).addClass("addTd");
        		        	 				   			$(this).append("<a href='javascript:;' class='addImgA'><img src='../image/addCourse.png' alt=''></a>");
        		        	 				   			$('.addImgA').click(function(){
        		        	 				   				localStorage.row=row;
        		        	 				   				localStorage.rawstr=rawstr;
        		        	 				   				window.location='singleCourse.html';
        		        	 				   			})
        		        	 				           	/* $(document).off('click','.addImgA'); //解除监听 
        		        	 			                $(document).on('click','.addImgA', function() {//a标签点击
        		        	 			                	
        		        	 			                }) */
        		        	 				   			 
        		        	 				   			}
        		        	 				   			
        		        	 				   		 })
        		        	 				   	 })
        		        	 
        		         					  }
        			 						  }) 
        			        	        	 //....
        			        	         }
        			        		 })
        			        	 
        			        		 
        			        		 $('.coverDiv').hide();
        			        		 
        			         }
        				 })
        		}
        		
        		
        				 
     
      // 重置当前周
      var currentWeek=function(userId,currentZs){
    	 
    	  var url=cutUrl()+"/api/kbsz/settingCurrentZs";
 		  var mes={"userId":userId,"currentZs":currentZs};
    	  $.ajax({
				  "dataType": 'json',
				  "type": "GET",
				  "url": url,
				  "data": mes,
				  "contentType":"application/json;charset=utf-8",
				  "success": function (data, textStatus, jqXHR){
					  var raw=JSON.stringify(data);
					 
					  raw=$.parseJSON(raw);
					  if(raw.error.id=='0000'){
						  $('.table').children('thead').children('tr').empty();
			        	  $('.table').children('thead').children('tr').append("<td class='firstTd' style='width: 1rem;'><p class='tdHeadP1'>日期</p><p class='tdHeadP2'>时间</p></td>");			        		
			        	  $('.table').children('tbody').empty();
			        	
						  loading(userId,currentZs);
					  }else{
						  //alert(raw.error.message);
						  $.MsgBox.Alert('温馨提示',raw.error.message);
					  }
					  
				  }
    	  })
    	  
      }
      
      //生成表头
      var weekGenerate=function(series){
    	      
    	  for(var t=1;t<26;t++){  		  
    	  		if(series==t){
    	  			$('.clearfix').append("<li class='currweekbg'><a href='javascript:;' class='weekA'><p class='weekP nowWeek'>第"+t+"周</p><table class='narrowTab'><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table><p class='nowWeekP'>当前周</p></a></li>");
    	  		}else{
    	  			$('.clearfix').append("<li><a href='javascript:;' class='weekA'><p class='weekP'>第"+t+"周</p><table class='narrowTab'><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table><p class='nowWeekP'></p></a></li>");
    	  		}
    			
    		}
    	  $('.wrapper').navbarscroll();
    	 
    	  
      }
   
      
     
    
    	
    	
//日期计算
		
		var calculationDate=function(orgCur,updateCur){
			//console.log('当前：'+orgCur+' ---Trang---'+'选取：'+updateCur);
			var monday=getMonday();
			var x=orgCur-updateCur;
			//console.log(x);
			//console.log('check the value of monday:'+monday);
			var orgMondayMil=Date.parse(monday);
			var gapMil=(updateCur-orgCur)*7*86400000;
			var realMondayMil=orgMondayMil+gapMil;
			var realMonday=new Date(realMondayMil).Format('yyyy-MM-dd');
			//console.log(realMonday+'   更新');
			//localStorage.realMonday=realMonday;
			return realMonday;
		}
		
		
		//获取星期一日期
		
		var getMonday=function(){
			var date=new Date();
		var weekDate=new Date().getDay();
		var weekGap=weekDate-1;
		date=date.Format('yyyy-MM-dd');
		var milvalue=Date.parse(date);
		var mondayMil=milvalue-weekGap*86400000;
		
		var x=new Date(milvalue).Format('yyyy-MM-dd');
		var y=new Date(mondayMil).Format('yyyy-MM-dd');
		
		
		return y;
		
		}
		
		
		// 标志当前时间
		var markCur=function(){
			var liveDate=new Date().getDay();
		  if(liveDate==1){
			  textColor('#tdP1');
		  }else if(liveDate==2){
			  textColor('#tdP2');
		  }else if(liveDate==3){
			  textColor('#tdP3');
		  }else if(liveDate==4){
			  textColor('#tdP4');
		  }else if(liveDate==5){
			  textColor('#tdP5');
		  }else if(liveDate==6){
			  textColor('#tdP6');
		  }else if(liveDate==7){
			  textColor('#tdP7');
		  }
		}
		
		//文本变色
		var textColor=function(id){
			$(id).css('color','#ff7886');
			$(id).siblings('em').css('color','#ff7886');
			//$(id).parent('td').css('border-top','solid 0.07rem #ff7886')
			
			//var url="url('../image/topmarker.png')"
			//$(id).parent('td').css('background-image',url);
			//$(id).parent('td').css('background-size','cover');
			
		}
		
		