$(function () {
    $("#jqGrid").jqGrid({
        url: '../areatable/list',
        datatype: "json",
        colModel: [
			{label: 'areaId', name: 'areaId', index: 'area_id', key: true, hidden: true},
			{label: '', name: 'areaCode', index: 'area_code', width: 80},
			{label: '', name: 'parentCode', index: 'parent_code', width: 80},
			{label: '', name: 'areaName', index: 'area_name', width: 80},
			{label: '', name: 'pingyin', index: 'pingyin', width: 80}],
		viewrecords: true,
        height: 385,
        rowNum: 10,
        rowList: [10, 30, 50],
        rownumbers: true,
        rownumWidth: 25,
        autowidth: true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader: {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames: {
            page: "page",
            rows: "limit",
            order: "order"
        },
        gridComplete: function () {
            $("#jqGrid").closest(".ui-jqgrid-bdiv").css({"overflow-x": "hidden"});
        }
    });
});

let vm = new Vue({
	el: '#rrapp',
	data: {
        showList: true,
        title: null,
		areaTable: {},
		ruleValidate: {
			name: [
				{required: true, message: '名称不能为空', trigger: 'blur'}
			]
		},
		q: {
		    name: ''
		}
	},
	methods: {
		query: function () {
			vm.reload();
		},
		add: function () {
			vm.showList = false;
			vm.title = "新增";
			vm.areaTable = {};
		},
		update: function (event) {
            let areaId = getSelectedRow();
			if (areaId == null) {
				return;
			}
			vm.showList = false;
            vm.title = "修改";

            vm.getInfo(areaId)
		},
		saveOrUpdate: function (event) {
            let url = vm.areaTable.areaId == null ? "../areatable/save" : "../areatable/update";
			$.ajax({
				type: "POST",
			    url: url,
			    contentType: "application/json",
			    data: JSON.stringify(vm.areaTable),
                success: function (r) {
                    if (r.code === 0) {
                        alert('操作成功', function (index) {
                            vm.reload();
                        });
                    } else {
                        alert(r.msg);
                    }
                }
			});
		},
		del: function (event) {
            let areaIds = getSelectedRows();
			if (areaIds == null){
				return;
			}

			confirm('确定要删除选中的记录？', function () {
				$.ajax({
					type: "POST",
				    url: "../areatable/delete",
				    contentType: "application/json",
				    data: JSON.stringify(areaIds),
				    success: function (r) {
						if (r.code == 0) {
							alert('操作成功', function (index) {
								$("#jqGrid").trigger("reloadGrid");
							});
						} else {
							alert(r.msg);
						}
					}
				});
			});
		},
		getInfo: function(areaId){
			$.get("../areatable/info/"+areaId, function (r) {
                vm.areaTable = r.areaTable;
            });
		},
		reload: function (event) {
			vm.showList = true;
            let page = $("#jqGrid").jqGrid('getGridParam', 'page');
			$("#jqGrid").jqGrid('setGridParam', {
                postData: {'name': vm.q.name},
                page: page
            }).trigger("reloadGrid");
            vm.handleReset('formValidate');
		},
        handleSubmit: function (name) {
            handleSubmitValidate(this, name, function () {
                vm.saveOrUpdate()
            });
        },
        handleReset: function (name) {
            handleResetForm(this, name);
        }
	}
});